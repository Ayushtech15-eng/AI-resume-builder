# AI Resume Builder — Frontend

A React (Vite) frontend for the AI Resume Builder platform. Talks to the
Express/MongoDB backend you already have running and covers every module:
auth, profile/education/experience/projects/skills, the resume builder with
version management, AI content generation, the ATS analyzer, job matching,
cover letters, templates, subscriptions, notifications, and an admin panel.

## Stack

- **React 18** + **Vite** (dev server + build)
- **React Router v6** for routing, with protected/admin route guards
- **Tailwind CSS** with a small custom design system (see `tailwind.config.js`)
- **react-hook-form** for forms
- **axios** for the API layer, with a JWT interceptor + global 401 handling
- **lucide-react** for icons

## Getting started

```bash
cd ai-resume-builder-frontend
npm install
cp .env.example .env
```

Set the API URL in `.env` to wherever your backend is running:

```env
VITE_API_URL=http://localhost:5000/api
```

Then:

```bash
npm run dev
```

Open `http://localhost:5173`. Make sure the backend is running first (and that
its `CLIENT_URL` env var includes `http://localhost:5173` so CORS allows it —
check the backend's `.env`).

## How auth works here

The backend returns a JWT both as an httpOnly cookie and in the response
body. This frontend uses the **body token**, stored in `localStorage` and
sent as `Authorization: Bearer <token>` on every request (see
`src/api/axiosClient.js`). This sidesteps cross-port cookie/SameSite issues
between the Vite dev server (5173) and the API (5000) during local
development. A 401 response anywhere automatically clears the session and
the next render redirects to `/login` via `ProtectedRoute`.

## Project structure

```
src/
  api/            One file per backend resource (auth, profile, resumes, ai,
                   ats, jobMatch, coverLetters, subscriptions, notifications,
                   admin, pdf, templates...) - thin axios wrappers, nothing else
  context/         AuthContext (session), ToastContext (toast notifications)
  components/
    layout/        AppLayout, Sidebar, Topbar (authenticated chrome),
                     PublicLayout (landing/auth chrome)
    common/         Button, Input, TextArea, Select, Card, Modal, Badge,
                     Spinner, EmptyState, ScoreGauge, ScanLoader,
                     ProtectedRoute, AdminRoute
  pages/
    public/         Landing, Login, Register, BrandPanel
    *.jsx           One page per module (Dashboard, ProfilePage, EducationPage,
                     ExperiencePage, ProjectsPage, SkillsPage, ResumesListPage,
                     ResumeEditorPage, TemplatesPage, AtsAnalyzerPage,
                     JobMatchPage, CoverLettersPage, SubscriptionPage,
                     NotificationsPage, AdminPage, NotFound)
```

## Design notes

The visual system leans on the actual subject — a resume getting scanned by
an ATS — rather than a generic dashboard look:

- **Type:** Fraunces (display/headings) + Inter (UI/body) + JetBrains Mono
  (scores, keyword chips, anything "machine-read") — loaded from Google
  Fonts in `index.html`.
- **Color:** a near-white paper background, near-black ink text, and a
  single indigo accent (`tailwind.config.js` → `colors`), with signal-green /
  amber / crimson reserved for ATS score states.
- **Signature motif:** a thin "scan beam" sweeping over content (`.scan-beam`
  in `src/index.css`, and the `ScanLoader` / `ScoreGauge` components) — used
  on the landing hero and ATS Analyzer loading state, and nowhere else, so it
  stays a signature rather than wallpaper.
- Every score visual (`ScoreGauge`) is a hand-built SVG, not a charting
  library, so it can carry the mono-digit "instrument readout" feel
  consistently everywhere it appears (Dashboard, ATS Analyzer, Job Match).

## Talking to AI features

Every AI-powered action (summary/objective generation, experience rewrites,
project descriptions, skill recommendations, cover letters) shows a toast
telling you whether it came from `"openai"` or the backend's offline
`"fallback"` mode — so you always know which one you're looking at. No
frontend changes are needed when you add a real `OPENAI_API_KEY` to the
backend; the responses just get better.

## What's simplified / not wired up

- **Payments:** `SubscriptionPage`'s upgrade button calls the backend's
  `/subscriptions/upgrade` directly with a placeholder `paymentRef` — there's
  no real Razorpay/Stripe checkout here. Swap in a real checkout flow before
  charging anyone.
- **Portfolio Generator** (Module 13 in the original spec) has no page yet —
  add it the same way as any other module: an `api/portfolio.js` file plus a
  `PortfolioPage.jsx`, once the backend route exists.
- Delete confirmations use `window.confirm()` for simplicity rather than a
  custom modal — fine for a v1, easy to swap later.
