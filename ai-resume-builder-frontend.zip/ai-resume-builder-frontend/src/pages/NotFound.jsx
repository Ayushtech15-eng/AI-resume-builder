import { Link } from 'react-router-dom';
import { ScanLine } from 'lucide-react';

const NotFound = () => (
  <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
    <ScanLine size={28} className="text-mist mb-4" />
    <h1 className="font-display text-3xl text-ink mb-2">Page not found</h1>
    <p className="text-ink-soft mb-6">Nothing scanned a match for this URL.</p>
    <Link to="/" className="text-indigo-deep font-medium hover:underline text-sm">
      Back to home
    </Link>
  </div>
);

export default NotFound;
