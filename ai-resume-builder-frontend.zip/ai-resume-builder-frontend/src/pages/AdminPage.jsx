import { useEffect, useState } from 'react';
import { Users, FileText, Sparkles, Mail, Crown, Search } from 'lucide-react';
import * as adminApi from '../api/admin';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Input from '../components/common/Input';
import Select from '../components/common/Select';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';

const StatCard = ({ icon: Icon, label, value }) => (
  <Card className="p-4 flex items-center gap-3">
    <div className="w-9 h-9 rounded-lg bg-indigo-soft flex items-center justify-center shrink-0">
      <Icon size={16} className="text-indigo-deep" />
    </div>
    <div>
      <p className="font-mono text-lg text-ink leading-none">{value}</p>
      <p className="text-xs text-ink-soft mt-0.5">{label}</p>
    </div>
  </Card>
);

const AdminPage = () => {
  const toast = useToast();
  const [analytics, setAnalytics] = useState(null);
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const loadUsers = async (q = '') => {
    try {
      const { data } = await adminApi.getUsers(q ? { search: q } : {});
      setUsers(data.users);
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await adminApi.getAnalytics();
        setAnalytics(data.analytics);
        await loadUsers();
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const onSearch = (e) => {
    e.preventDefault();
    loadUsers(search);
  };

  const changeRole = async (id, role) => {
    try {
      const { data } = await adminApi.updateUserRole(id, role);
      setUsers((prev) => prev.map((u) => (u._id === id ? data.user : u)));
      toast.success('Role updated.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const toggleActive = async (id) => {
    try {
      const { data } = await adminApi.toggleUserActive(id);
      setUsers((prev) => prev.map((u) => (u._id === id ? data.user : u)));
      toast.success(data.user.isActive ? 'User reactivated.' : 'User deactivated.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading analytics…" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Users} label="Total users" value={analytics.totalUsers} />
        <StatCard icon={FileText} label="Resumes generated" value={analytics.totalResumes} />
        <StatCard icon={Sparkles} label="ATS reports run" value={analytics.totalAtsReportsGenerated} />
        <StatCard icon={Mail} label="Cover letters" value={analytics.totalCoverLettersGenerated} />
      </div>

      <div className="grid sm:grid-cols-2 gap-5">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-1">
            <Crown size={15} className="text-amber" />
            <h3 className="font-display text-base text-ink">Premium users</h3>
          </div>
          <p className="font-mono text-2xl text-ink mt-2">{analytics.premiumUsers}</p>
          {analytics.averageAtsScore != null && (
            <p className="text-xs text-ink-soft mt-3">
              Average ATS score across all scans: <span className="font-mono">{analytics.averageAtsScore}/100</span>
            </p>
          )}
        </Card>
        <Card className="p-5">
          <h3 className="font-display text-base text-ink mb-3">Most popular templates</h3>
          <div className="space-y-1.5">
            {analytics.mostPopularTemplates?.length ? (
              analytics.mostPopularTemplates.map((t) => (
                <div key={t._id} className="flex justify-between text-sm">
                  <span className="text-ink-soft">{t.name}</span>
                  <span className="font-mono text-ink">{t.usageCount}</span>
                </div>
              ))
            ) : (
              <p className="text-sm text-ink-soft">No usage recorded yet.</p>
            )}
          </div>
        </Card>
      </div>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <h3 className="font-display text-base text-ink">Users</h3>
          <form onSubmit={onSearch} className="flex gap-2">
            <Input placeholder="Search name or email…" value={search} onChange={(e) => setSearch(e.target.value)} className="w-56" />
            <button type="submit" className="p-2.5 border border-mist rounded-lg text-ink-soft hover:text-ink hover:bg-paper-dim">
              <Search size={15} />
            </button>
          </form>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-ink-soft border-b border-mist">
                <th className="py-2 pr-4">Name</th>
                <th className="py-2 pr-4">Email</th>
                <th className="py-2 pr-4">Role</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2"></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u._id} className="border-b border-mist/60">
                  <td className="py-2.5 pr-4 text-ink">{u.name}</td>
                  <td className="py-2.5 pr-4 text-ink-soft">{u.email}</td>
                  <td className="py-2.5 pr-4">
                    <Select value={u.role} onChange={(e) => changeRole(u._id, e.target.value)} className="!py-1 !pr-7 text-xs">
                      <option value="jobseeker">jobseeker</option>
                      <option value="recruiter">recruiter</option>
                      <option value="admin">admin</option>
                    </Select>
                  </td>
                  <td className="py-2.5 pr-4">
                    <Badge tone={u.isActive ? 'success' : 'danger'}>{u.isActive ? 'Active' : 'Deactivated'}</Badge>
                  </td>
                  <td className="py-2.5">
                    <button onClick={() => toggleActive(u._id)} className="text-xs font-medium text-indigo-deep hover:underline">
                      {u.isActive ? 'Deactivate' : 'Reactivate'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdminPage;
