import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { GraduationCap, Plus, Pencil, Trash2 } from 'lucide-react';
import * as educationApi from '../api/education';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Modal from '../components/common/Modal';
import EmptyState from '../components/common/EmptyState';
import Spinner from '../components/common/Spinner';

const EducationPage = () => {
  const toast = useToast();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm();

  const load = async () => {
    try {
      const { data } = await educationApi.getEducation();
      setRecords(data.education);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const openCreate = () => {
    setEditing(null);
    reset({ university: '', degree: '', branch: '', cgpa: '', percentage: '', startYear: '', endYear: '', isOngoing: false });
    setModalOpen(true);
  };

  const openEdit = (record) => {
    setEditing(record);
    reset(record);
    setModalOpen(true);
  };

  const onSubmit = async (values) => {
    const payload = {
      ...values,
      cgpa: values.cgpa ? Number(values.cgpa) : undefined,
      percentage: values.percentage ? Number(values.percentage) : undefined,
      startYear: Number(values.startYear),
      endYear: values.endYear ? Number(values.endYear) : undefined,
    };
    try {
      if (editing) {
        await educationApi.updateEducation(editing._id, payload);
        toast.success('Education updated.');
      } else {
        await educationApi.createEducation(payload);
        toast.success('Education added.');
      }
      setModalOpen(false);
      load();
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const onDelete = async (id) => {
    if (!window.confirm('Delete this education entry?')) return;
    try {
      await educationApi.deleteEducation(id);
      toast.success('Education deleted.');
      setRecords((prev) => prev.filter((r) => r._id !== id));
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading education…" />
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center justify-between">
        <p className="text-sm text-ink-soft">Your academic history, most recent first.</p>
        <Button icon={Plus} onClick={openCreate}>
          Add education
        </Button>
      </div>

      {records.length === 0 ? (
        <EmptyState
          icon={GraduationCap}
          title="No education added yet"
          description="Add your degree, university, and CGPA to include in your resumes."
          actionLabel="Add education"
          onAction={openCreate}
        />
      ) : (
        <div className="space-y-3">
          {records.map((r) => (
            <Card key={r._id} className="p-4 flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-indigo-soft flex items-center justify-center shrink-0">
                  <GraduationCap size={16} className="text-indigo-deep" />
                </div>
                <div>
                  <p className="font-medium text-ink text-sm">
                    {r.degree}
                    {r.branch ? ` · ${r.branch}` : ''}
                  </p>
                  <p className="text-sm text-ink-soft">{r.university}</p>
                  <p className="text-xs text-ink-soft/80 font-mono mt-0.5">
                    {r.startYear} – {r.isOngoing ? 'Present' : r.endYear || '—'}
                    {r.cgpa ? ` · CGPA ${r.cgpa}` : r.percentage ? ` · ${r.percentage}%` : ''}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => openEdit(r)} className="p-2 text-ink-soft hover:text-indigo-deep rounded-lg hover:bg-paper-dim">
                  <Pencil size={15} />
                </button>
                <button onClick={() => onDelete(r._id)} className="p-2 text-ink-soft hover:text-crimson rounded-lg hover:bg-crimson/5">
                  <Trash2 size={15} />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit education' : 'Add education'}>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <Input label="University" required error={errors.university?.message} {...register('university', { required: 'Required' })} />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Degree" required error={errors.degree?.message} {...register('degree', { required: 'Required' })} />
            <Input label="Branch / Major" {...register('branch')} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="CGPA (0-10)" type="number" step="0.01" {...register('cgpa')} />
            <Input label="Percentage" type="number" step="0.1" {...register('percentage')} />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Start year" type="number" required error={errors.startYear?.message} {...register('startYear', { required: 'Required' })} />
            <Input label="End year" type="number" {...register('endYear')} />
          </div>
          <label className="flex items-center gap-2 text-sm text-ink-soft">
            <input type="checkbox" className="rounded border-mist" {...register('isOngoing')} /> Currently studying here
          </label>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)} type="button">
              Cancel
            </Button>
            <Button type="submit" loading={isSubmitting}>
              {editing ? 'Save changes' : 'Add education'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default EducationPage;
