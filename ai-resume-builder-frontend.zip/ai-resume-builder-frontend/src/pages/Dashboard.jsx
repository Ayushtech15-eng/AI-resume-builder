import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FileText,
  Sparkles,
  ScanLine,
  ArrowRight,
  GraduationCap,
  Briefcase,
  FolderKanban,
  Bell,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import * as profileApi from '../api/profile';
import * as resumesApi from '../api/resumes';
import * as subscriptionsApi from '../api/subscriptions';
import * as notificationsApi from '../api/notifications';
import * as educationApi from '../api/education';
import * as experienceApi from '../api/experience';
import * as projectsApi from '../api/projects';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import ScoreGauge from '../components/common/ScoreGauge';
import Spinner from '../components/common/Spinner';
import { timeAgo } from '../utils/formatDate';
import { getErrorMessage } from '../api/axiosClient';

const Dashboard = () => {
  const { user } = useAuth();
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [resumes, setResumes] = useState([]);
  const [subscription, setSubscription] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const [counts, setCounts] = useState({ education: 0, experience: 0, projects: 0 });

  useEffect(() => {
    const load = async () => {
      try {
        const [profileRes, resumesRes, subRes, notifRes, eduRes, expRes, projRes] = await Promise.all([
          profileApi.getProfile(),
          resumesApi.getResumes(),
          subscriptionsApi.getMySubscription(),
          notificationsApi.getNotifications(),
          educationApi.getEducation(),
          experienceApi.getExperience(),
          projectsApi.getProjects(),
        ]);
        setProfile(profileRes.data.profile);
        setResumes(resumesRes.data.resumes);
        setSubscription(subRes.data.subscription);
        setNotifications(notifRes.data.notifications.slice(0, 4));
        setCounts({
          education: eduRes.data.count,
          experience: expRes.data.count,
          projects: projRes.data.count,
        });
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading your dashboard…" />
      </div>
    );
  }

  const bestResume = resumes.reduce(
    (best, r) => (r.lastAtsScore != null && (!best || r.lastAtsScore > best.lastAtsScore) ? r : best),
    null
  );
  const primaryResume = resumes.find((r) => r.isPrimary) || resumes[0];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display text-2xl text-ink">Hi {user?.name?.split(' ')[0]}, let's build something that gets read.</h2>
        <p className="text-ink-soft text-sm mt-1">Here's where your resume stands today.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        {/* Profile completeness */}
        <Card className="p-5 md:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-base text-ink">Profile completeness</h3>
            <Link to="/profile" className="text-xs text-indigo-deep font-medium hover:underline flex items-center gap-1">
              Edit profile <ArrowRight size={12} />
            </Link>
          </div>
          <div className="flex items-center gap-4 mb-5">
            <div className="flex-1 h-2 bg-paper-dim rounded-full overflow-hidden">
              <div
                className="h-full bg-indigo rounded-full transition-all"
                style={{ width: `${profile?.profileCompleteness ?? 0}%` }}
              />
            </div>
            <span className="font-mono text-sm text-ink-soft w-10 text-right">{profile?.profileCompleteness ?? 0}%</span>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Link to="/education" className="flex items-center gap-2.5 p-3 rounded-lg border border-mist hover:border-indigo/40 transition-colors">
              <GraduationCap size={16} className="text-indigo-deep" />
              <div>
                <p className="text-sm font-medium text-ink">{counts.education}</p>
                <p className="text-xs text-ink-soft">Education</p>
              </div>
            </Link>
            <Link to="/experience" className="flex items-center gap-2.5 p-3 rounded-lg border border-mist hover:border-indigo/40 transition-colors">
              <Briefcase size={16} className="text-indigo-deep" />
              <div>
                <p className="text-sm font-medium text-ink">{counts.experience}</p>
                <p className="text-xs text-ink-soft">Experience</p>
              </div>
            </Link>
            <Link to="/projects" className="flex items-center gap-2.5 p-3 rounded-lg border border-mist hover:border-indigo/40 transition-colors">
              <FolderKanban size={16} className="text-indigo-deep" />
              <div>
                <p className="text-sm font-medium text-ink">{counts.projects}</p>
                <p className="text-xs text-ink-soft">Projects</p>
              </div>
            </Link>
          </div>
        </Card>

        {/* ATS score widget */}
        <Card className="p-5 flex flex-col items-center justify-center text-center">
          {bestResume ? (
            <>
              <ScoreGauge score={bestResume.lastAtsScore} label="Best ATS score" size={108} />
              <p className="text-xs text-ink-soft mt-3 truncate max-w-full">{bestResume.title}</p>
              <Link to="/ats-analyzer" className="text-xs text-indigo-deep font-medium hover:underline mt-2">
                Re-analyze →
              </Link>
            </>
          ) : (
            <>
              <ScanLine size={28} className="text-mist mb-3" />
              <p className="text-sm text-ink-soft mb-3">No ATS scan yet</p>
              <Link to="/ats-analyzer" className="text-xs text-indigo-deep font-medium hover:underline">
                Run your first scan →
              </Link>
            </>
          )}
        </Card>
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        {/* Resumes */}
        <Card className="p-5 md:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-base text-ink">Your resumes</h3>
            <Link to="/resumes" className="text-xs text-indigo-deep font-medium hover:underline flex items-center gap-1">
              View all <ArrowRight size={12} />
            </Link>
          </div>
          {resumes.length === 0 ? (
            <div className="text-center py-8">
              <FileText size={24} className="text-mist mx-auto mb-2" />
              <p className="text-sm text-ink-soft mb-3">You haven't created a resume yet.</p>
              <Link to="/resumes" className="text-sm text-indigo-deep font-medium hover:underline">
                Create your first resume →
              </Link>
            </div>
          ) : (
            <div className="space-y-2">
              {resumes.slice(0, 4).map((r) => (
                <Link
                  key={r._id}
                  to={`/resumes/${r._id}`}
                  className="flex items-center justify-between p-3 rounded-lg border border-mist hover:border-indigo/40 transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <FileText size={15} className="text-indigo-deep shrink-0" />
                    <span className="text-sm text-ink truncate">{r.title}</span>
                    {r.isPrimary && <Badge tone="indigo">Primary</Badge>}
                  </div>
                  {r.lastAtsScore != null && <span className="font-mono text-xs text-ink-soft shrink-0">{r.lastAtsScore}/100</span>}
                </Link>
              ))}
            </div>
          )}
        </Card>

        {/* Subscription + notifications */}
        <div className="space-y-5">
          <Card className="p-5">
            <h3 className="font-display text-base text-ink mb-3">Plan</h3>
            <div className="flex items-center justify-between mb-1">
              <Badge tone={subscription?.plan === 'premium' ? 'success' : 'neutral'}>
                {subscription?.plan === 'premium' ? 'Premium' : 'Free'}
              </Badge>
              {subscription?.plan !== 'premium' && (
                <Link to="/subscription" className="text-xs text-indigo-deep font-medium hover:underline">
                  Upgrade
                </Link>
              )}
            </div>
            {subscription?.plan !== 'premium' && (
              <p className="text-xs text-ink-soft mt-2">
                {subscription?.aiUsageCount ?? 0}/{subscription?.aiUsageLimit ?? 10} AI calls used today
              </p>
            )}
          </Card>

          <Card className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display text-base text-ink">Recent activity</h3>
              <Bell size={14} className="text-ink-soft" />
            </div>
            {notifications.length === 0 ? (
              <p className="text-xs text-ink-soft">No notifications yet.</p>
            ) : (
              <ul className="space-y-2.5">
                {notifications.map((n) => (
                  <li key={n._id} className="text-xs">
                    <p className="text-ink-soft leading-snug">{n.message}</p>
                    <p className="text-ink-soft/60 mt-0.5">{timeAgo(n.createdAt)}</p>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>

      {primaryResume && (
        <Card className="p-5 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <Sparkles size={18} className="text-indigo-deep" />
            <p className="text-sm text-ink">
              Want fresher AI-written content for <strong>{primaryResume.title}</strong>?
            </p>
          </div>
          <Link
            to={`/resumes/${primaryResume._id}`}
            className="text-sm font-medium text-indigo-deep hover:underline flex items-center gap-1"
          >
            Regenerate with AI <ArrowRight size={14} />
          </Link>
        </Card>
      )}
    </div>
  );
};

export default Dashboard;
