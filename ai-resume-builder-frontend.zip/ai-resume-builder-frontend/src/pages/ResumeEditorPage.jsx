import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Sparkles,
  Save,
  Download,
  ScanLine,
  Target,
  Mail,
  ArrowLeft,
  GraduationCap,
  Briefcase,
  FolderKanban,
  Tag,
} from 'lucide-react';
import * as resumesApi from '../api/resumes';
import * as templatesApi from '../api/templates';
import * as educationApi from '../api/education';
import * as experienceApi from '../api/experience';
import * as projectsApi from '../api/projects';
import * as skillsApi from '../api/skills';
import * as pdfApi from '../api/pdf';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import TextArea from '../components/common/TextArea';
import Select from '../components/common/Select';
import Spinner from '../components/common/Spinner';
import Badge from '../components/common/Badge';

const idsOf = (arr) => arr.map((x) => (typeof x === 'string' ? x : x._id));

const PickerSection = ({ icon: Icon, title, items, selectedIds, onToggle, renderLabel }) => (
  <div>
    <div className="flex items-center gap-2 mb-2">
      <Icon size={15} className="text-indigo-deep" />
      <p className="text-sm font-medium text-ink">{title}</p>
      <span className="text-xs text-ink-soft">
        ({selectedIds.length}/{items.length})
      </span>
    </div>
    {items.length === 0 ? (
      <p className="text-xs text-ink-soft pl-5">Nothing added yet.</p>
    ) : (
      <div className="space-y-1.5 pl-5">
        {items.map((item) => (
          <label key={item._id} className="flex items-start gap-2 text-sm text-ink-soft hover:text-ink cursor-pointer">
            <input
              type="checkbox"
              className="rounded border-mist mt-0.5"
              checked={selectedIds.includes(item._id)}
              onChange={() => onToggle(item._id)}
            />
            <span>{renderLabel(item)}</span>
          </label>
        ))}
      </div>
    )}
  </div>
);

const ResumeEditorPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);

  const [resume, setResume] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [masterEducation, setMasterEducation] = useState([]);
  const [masterExperience, setMasterExperience] = useState([]);
  const [masterProjects, setMasterProjects] = useState([]);
  const [masterSkills, setMasterSkills] = useState([]);
  const [targetRole, setTargetRole] = useState('');

  const [form, setForm] = useState({
    title: '',
    templateId: '',
    careerObjective: '',
    professionalSummary: '',
    status: 'draft',
    education: [],
    experience: [],
    projects: [],
    skills: [],
  });

  useEffect(() => {
    const load = async () => {
      try {
        const [resumeRes, templatesRes, eduRes, expRes, projRes, skillRes] = await Promise.all([
          resumesApi.getResumeById(id),
          templatesApi.getTemplates(),
          educationApi.getEducation(),
          experienceApi.getExperience(),
          projectsApi.getProjects(),
          skillsApi.getSkills(),
        ]);
        const r = resumeRes.data.resume;
        setResume(r);
        setTemplates(templatesRes.data.templates);
        setMasterEducation(eduRes.data.education);
        setMasterExperience(expRes.data.experience);
        setMasterProjects(projRes.data.projects);
        setMasterSkills(skillRes.data.skills);
        setTargetRole(r.experience[0]?.role || '');
        setForm({
          title: r.title,
          templateId: r.template?._id || '',
          careerObjective: r.careerObjective || '',
          professionalSummary: r.professionalSummary || '',
          status: r.status,
          education: idsOf(r.education),
          experience: idsOf(r.experience),
          projects: idsOf(r.projects),
          skills: idsOf(r.skills),
        });
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggle = (field, itemId) => {
    setForm((prev) => ({
      ...prev,
      [field]: prev[field].includes(itemId) ? prev[field].filter((x) => x !== itemId) : [...prev[field], itemId],
    }));
  };

  const save = async () => {
    setSaving(true);
    try {
      const { data } = await resumesApi.updateResume(id, {
        title: form.title,
        template: form.templateId || undefined,
        careerObjective: form.careerObjective,
        professionalSummary: form.professionalSummary,
        status: form.status,
        education: form.education,
        experience: form.experience,
        projects: form.projects,
        skills: form.skills,
      });
      setResume(data.resume);
      toast.success('Resume saved.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const generateWithAi = async () => {
    setAiLoading(true);
    try {
      // persist current selections first so AI generation reflects them
      await resumesApi.updateResume(id, {
        education: form.education,
        experience: form.experience,
        projects: form.projects,
        skills: form.skills,
      });
      const { data } = await resumesApi.aiGenerateResumeContent(id, targetRole);
      setForm((prev) => ({
        ...prev,
        professionalSummary: data.resume.professionalSummary,
        careerObjective: data.resume.careerObjective,
      }));
      toast.success(data.aiSource?.summary === 'openai' ? 'Content generated by AI.' : 'Content drafted (offline mode).');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setAiLoading(false);
    }
  };

  const download = async () => {
    setDownloading(true);
    try {
      const { data } = await pdfApi.downloadResumePdf(id);
      const url = window.URL.createObjectURL(new Blob([data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `${form.title.replace(/[^a-z0-9]/gi, '_') || 'resume'}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading resume…" />
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-4xl">
      <button onClick={() => navigate('/resumes')} className="inline-flex items-center gap-1.5 text-sm text-ink-soft hover:text-ink">
        <ArrowLeft size={14} /> Back to resumes
      </button>

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex-1 min-w-[240px]">
          <Input value={form.title} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} className="font-display text-lg" />
        </div>
        <div className="flex items-center gap-2">
          {resume?.lastAtsScore != null && <Badge tone="warning">ATS {resume.lastAtsScore}/100</Badge>}
          <Badge tone={form.status === 'finalized' ? 'success' : 'neutral'}>{form.status}</Badge>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" icon={Download} loading={downloading} onClick={download}>
          Download PDF
        </Button>
        <Button size="sm" variant="secondary" icon={ScanLine} onClick={() => navigate(`/ats-analyzer?resumeId=${id}`)}>
          Run ATS scan
        </Button>
        <Button size="sm" variant="secondary" icon={Target} onClick={() => navigate(`/job-match?resumeId=${id}`)}>
          Match against a job
        </Button>
        <Button size="sm" variant="secondary" icon={Mail} onClick={() => navigate(`/cover-letters?resumeId=${id}`)}>
          Write cover letter
        </Button>
      </div>

      <Card className="p-5">
        <h3 className="font-display text-base text-ink mb-3">Template</h3>
        <div className="grid sm:grid-cols-3 gap-3">
          {templates.map((t) => (
            <button
              key={t._id}
              onClick={() => setForm((p) => ({ ...p, templateId: t._id }))}
              className={`text-left p-3 rounded-lg border transition-colors ${
                form.templateId === t._id ? 'border-indigo bg-indigo-soft' : 'border-mist hover:border-indigo/40'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium text-ink">{t.name}</span>
                {t.isPremium && <Badge tone="warning">Premium</Badge>}
              </div>
              <p className="text-xs text-ink-soft">{t.type}</p>
            </button>
          ))}
        </div>
      </Card>

      <Card className="p-5">
        <div className="flex items-center justify-between mb-1">
          <h3 className="font-display text-base text-ink">AI-written content</h3>
          <Button size="sm" variant="subtle" icon={Sparkles} loading={aiLoading} onClick={generateWithAi}>
            Generate with AI
          </Button>
        </div>
        <Input
          placeholder="Target role for AI context, e.g. Full Stack Developer"
          value={targetRole}
          onChange={(e) => setTargetRole(e.target.value)}
          className="mb-3 mt-3"
        />
        <div className="space-y-3">
          <TextArea
            label="Career objective"
            rows={2}
            value={form.careerObjective}
            onChange={(e) => setForm((p) => ({ ...p, careerObjective: e.target.value }))}
          />
          <TextArea
            label="Professional summary"
            rows={4}
            value={form.professionalSummary}
            onChange={(e) => setForm((p) => ({ ...p, professionalSummary: e.target.value }))}
          />
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="font-display text-base text-ink mb-4">What's included in this resume</h3>
        <div className="space-y-5">
          <PickerSection
            icon={GraduationCap}
            title="Education"
            items={masterEducation}
            selectedIds={form.education}
            onToggle={(itemId) => toggle('education', itemId)}
            renderLabel={(e) => `${e.degree} — ${e.university}`}
          />
          <PickerSection
            icon={Briefcase}
            title="Experience"
            items={masterExperience}
            selectedIds={form.experience}
            onToggle={(itemId) => toggle('experience', itemId)}
            renderLabel={(e) => `${e.role} at ${e.company}`}
          />
          <PickerSection
            icon={FolderKanban}
            title="Projects"
            items={masterProjects}
            selectedIds={form.projects}
            onToggle={(itemId) => toggle('projects', itemId)}
            renderLabel={(p) => p.name}
          />
          <PickerSection
            icon={Tag}
            title="Skills"
            items={masterSkills}
            selectedIds={form.skills}
            onToggle={(itemId) => toggle('skills', itemId)}
            renderLabel={(s) => s.name}
          />
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="font-display text-base text-ink mb-3">Status</h3>
        <Select value={form.status} onChange={(e) => setForm((p) => ({ ...p, status: e.target.value }))} className="max-w-xs">
          <option value="draft">Draft</option>
          <option value="finalized">Finalized</option>
        </Select>
      </Card>

      <div className="flex justify-end sticky bottom-4">
        <Button icon={Save} loading={saving} onClick={save} size="lg">
          Save resume
        </Button>
      </div>
    </div>
  );
};

export default ResumeEditorPage;
