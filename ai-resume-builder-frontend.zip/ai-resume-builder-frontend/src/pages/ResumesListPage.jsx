import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FileText, Plus, Copy, Trash2, Star, Download, GitCompare } from 'lucide-react';
import * as resumesApi from '../api/resumes';
import * as pdfApi from '../api/pdf';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Input from '../components/common/Input';
import Modal from '../components/common/Modal';
import Badge from '../components/common/Badge';
import EmptyState from '../components/common/EmptyState';
import Spinner from '../components/common/Spinner';
import { formatDate } from '../utils/formatDate';

const ResumesListPage = () => {
  const toast = useToast();
  const navigate = useNavigate();
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [creating, setCreating] = useState(false);
  const [busyId, setBusyId] = useState(null);
  const [selected, setSelected] = useState([]);
  const [compareData, setCompareData] = useState(null);

  const load = async () => {
    try {
      const { data } = await resumesApi.getResumes();
      setResumes(data.resumes);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const createResume = async () => {
    setCreating(true);
    try {
      const { data } = await resumesApi.createResume({ title: newTitle.trim() || 'Untitled Resume' });
      toast.success('Resume created.');
      navigate(`/resumes/${data.resume._id}`);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setCreating(false);
      setCreateOpen(false);
    }
  };

  const duplicate = async (id) => {
    setBusyId(id);
    try {
      const { data } = await resumesApi.duplicateResume(id);
      setResumes((prev) => [data.resume, ...prev]);
      toast.success('Resume duplicated.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const setPrimary = async (id) => {
    setBusyId(id);
    try {
      const { data } = await resumesApi.setPrimaryResume(id);
      setResumes((prev) => prev.map((r) => ({ ...r, isPrimary: r._id === data.resume._id })));
      toast.success('Set as primary resume.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const remove = async (id) => {
    if (!window.confirm('Delete this resume? This cannot be undone.')) return;
    setBusyId(id);
    try {
      await resumesApi.deleteResume(id);
      setResumes((prev) => prev.filter((r) => r._id !== id));
      toast.success('Resume deleted.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const download = async (resume) => {
    setBusyId(resume._id);
    try {
      const { data } = await pdfApi.downloadResumePdf(resume._id);
      const url = window.URL.createObjectURL(new Blob([data], { type: 'application/pdf' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = `${resume.title.replace(/[^a-z0-9]/gi, '_')}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setBusyId(null);
    }
  };

  const toggleSelect = (id) => {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : prev.length < 2 ? [...prev, id] : prev));
  };

  const runCompare = async () => {
    try {
      const { data } = await resumesApi.compareResumes(selected);
      setCompareData(data.comparison);
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading resumes…" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-ink-soft">
          {resumes.length} version{resumes.length === 1 ? '' : 's'}. Select two to compare.
        </p>
        <div className="flex gap-2">
          {selected.length === 2 && (
            <Button variant="secondary" icon={GitCompare} onClick={runCompare}>
              Compare selected
            </Button>
          )}
          <Button icon={Plus} onClick={() => setCreateOpen(true)}>
            New resume
          </Button>
        </div>
      </div>

      {resumes.length === 0 ? (
        <EmptyState
          icon={FileText}
          title="No resumes yet"
          description="Create a resume version from your profile, education, experience, and projects."
          actionLabel="Create your first resume"
          onAction={() => setCreateOpen(true)}
        />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {resumes.map((r) => (
            <Card key={r._id} className="p-4 flex flex-col">
              <div className="flex items-start justify-between gap-2 mb-2">
                <label className="flex items-center gap-2 min-w-0">
                  <input
                    type="checkbox"
                    className="rounded border-mist mt-0.5"
                    checked={selected.includes(r._id)}
                    onChange={() => toggleSelect(r._id)}
                  />
                  <button onClick={() => navigate(`/resumes/${r._id}`)} className="font-medium text-ink text-sm text-left hover:text-indigo-deep truncate">
                    {r.title}
                  </button>
                </label>
                {r.isPrimary && <Badge tone="indigo">Primary</Badge>}
              </div>

              <div className="flex items-center gap-2 mb-3 flex-wrap">
                <Badge tone={r.status === 'finalized' ? 'success' : 'neutral'}>{r.status}</Badge>
                {r.lastAtsScore != null && <Badge tone="warning">ATS {r.lastAtsScore}/100</Badge>}
              </div>

              <p className="text-xs text-ink-soft mb-4">Updated {formatDate(r.updatedAt)}</p>

              <div className="mt-auto flex items-center gap-1 flex-wrap">
                <button onClick={() => download(r)} disabled={busyId === r._id} title="Download PDF" className="p-2 text-ink-soft hover:text-indigo-deep rounded-lg hover:bg-paper-dim disabled:opacity-50">
                  <Download size={15} />
                </button>
                <button onClick={() => duplicate(r._id)} disabled={busyId === r._id} title="Duplicate" className="p-2 text-ink-soft hover:text-indigo-deep rounded-lg hover:bg-paper-dim disabled:opacity-50">
                  <Copy size={15} />
                </button>
                {!r.isPrimary && (
                  <button onClick={() => setPrimary(r._id)} disabled={busyId === r._id} title="Set as primary" className="p-2 text-ink-soft hover:text-indigo-deep rounded-lg hover:bg-paper-dim disabled:opacity-50">
                    <Star size={15} />
                  </button>
                )}
                <button onClick={() => remove(r._id)} disabled={busyId === r._id} title="Delete" className="p-2 text-ink-soft hover:text-crimson rounded-lg hover:bg-crimson/5 disabled:opacity-50">
                  <Trash2 size={15} />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="New resume version">
        <div className="space-y-4">
          <Input
            label="Title"
            placeholder="e.g. MERN Developer Resume"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
          />
          <p className="text-xs text-ink-soft">
            It'll start with all of your current education, experience, projects, and skills attached — you can adjust what's
            included from the resume editor.
          </p>
          <div className="flex justify-end gap-2">
            <Button variant="secondary" type="button" onClick={() => setCreateOpen(false)}>
              Cancel
            </Button>
            <Button loading={creating} onClick={createResume}>
              Create resume
            </Button>
          </div>
        </div>
      </Modal>

      <Modal open={Boolean(compareData)} onClose={() => setCompareData(null)} title="Compare resumes" width="max-w-2xl">
        {compareData && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-ink-soft border-b border-mist">
                  <th className="py-2 pr-4">Resume</th>
                  <th className="py-2 pr-4">ATS Score</th>
                  <th className="py-2 pr-4">Education</th>
                  <th className="py-2 pr-4">Experience</th>
                  <th className="py-2 pr-4">Projects</th>
                  <th className="py-2 pr-4">Skills</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {compareData.map((c) => (
                  <tr key={c.id} className="border-b border-mist/60">
                    <td className="py-2.5 pr-4 font-medium text-ink">{c.title}</td>
                    <td className="py-2.5 pr-4 font-mono">{c.lastAtsScore ?? '—'}</td>
                    <td className="py-2.5 pr-4">{c.educationCount}</td>
                    <td className="py-2.5 pr-4">{c.experienceCount}</td>
                    <td className="py-2.5 pr-4">{c.projectsCount}</td>
                    <td className="py-2.5 pr-4">{c.skillsCount}</td>
                    <td className="py-2.5">{c.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default ResumesListPage;
