import { ScanLine } from 'lucide-react';

/**
 * Shared right-hand panel for Login/Register - reuses the scan-beam
 * signature motif so the auth flow feels continuous with the landing page.
 */
const BrandPanel = () => (
  <div className="hidden md:flex relative bg-ink items-center justify-center px-12 overflow-hidden">
    <div className="absolute inset-0 doc-grid opacity-[0.06]" />
    <div className="relative max-w-sm">
      <div className="relative bg-white/[0.04] border border-white/10 rounded-xl p-6 mb-8 overflow-hidden">
        <div className="scan-rail">
          <div
            className="absolute inset-x-0 h-[22%] animate-scan"
            style={{
              background:
                'linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(255,255,255,0.10) 50%, rgba(255,255,255,0) 100%)',
            }}
          />
        </div>
        <div className="relative space-y-2">
          <div className="h-2.5 w-2/5 bg-white/30 rounded" />
          <div className="h-2 w-3/5 bg-white/15 rounded" />
          <div className="h-2 w-full bg-white/15 rounded mt-4" />
          <div className="h-2 w-[88%] bg-white/15 rounded" />
          <div className="h-2 w-[70%] bg-white/15 rounded" />
        </div>
      </div>
      <div className="flex items-center gap-2 text-white/90 mb-3">
        <ScanLine size={16} />
        <span className="font-mono text-xs uppercase tracking-widest">ATS Score Engine</span>
      </div>
      <p className="font-display text-2xl text-white leading-snug">
        "The resume that gets read isn't the best one — it's the one that passes the filter first."
      </p>
    </div>
  </div>
);

export default BrandPanel;
