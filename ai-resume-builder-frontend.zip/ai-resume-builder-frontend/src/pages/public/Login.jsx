import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ScanLine, ArrowRight } from 'lucide-react';
import { useAuth, getErrorMessage } from '../../context/AuthContext';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import BrandPanel from './BrandPanel';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [serverError, setServerError] = useState('');
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm();

  const onSubmit = async (values) => {
    setServerError('');
    try {
      await login(values);
      navigate(location.state?.from?.pathname || '/dashboard', { replace: true });
    } catch (err) {
      setServerError(getErrorMessage(err));
    }
  };

  return (
    <div className="min-h-[calc(100vh-140px)] grid md:grid-cols-2">
      <div className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-8 md:hidden">
            <div className="w-8 h-8 rounded-lg bg-indigo flex items-center justify-center">
              <ScanLine size={16} className="text-white" />
            </div>
            <span className="font-display text-lg text-ink">
              Resume<span className="text-indigo">AI</span>
            </span>
          </div>

          <h1 className="font-display text-2xl text-ink mb-1.5">Welcome back</h1>
          <p className="text-sm text-ink-soft mb-7">Log in to keep building your resume.</p>

          {serverError && (
            <div className="mb-4 text-sm text-crimson bg-crimson/5 border border-crimson/20 rounded-lg px-3.5 py-2.5">
              {serverError}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              required
              error={errors.email?.message}
              {...register('email', { required: 'Email is required' })}
            />
            <Input
              label="Password"
              type="password"
              placeholder="••••••••"
              required
              error={errors.password?.message}
              {...register('password', { required: 'Password is required' })}
            />
            <Button type="submit" loading={isSubmitting} className="w-full" icon={ArrowRight}>
              Log in
            </Button>
          </form>

          <p className="text-sm text-ink-soft mt-6 text-center">
            Don't have an account?{' '}
            <Link to="/register" className="text-indigo-deep font-medium hover:underline">
              Create one
            </Link>
          </p>
        </div>
      </div>

      <BrandPanel />
    </div>
  );
};

export default Login;
