import { Link } from 'react-router-dom';
import { ArrowRight, ScanLine, Sparkles, Target, Mail, FileCheck2 } from 'lucide-react';

const KEYWORDS = ['React', 'Node.js', 'Team Leadership', 'AWS', 'Agile', 'SQL'];

const Hero = () => (
  <section className="relative px-6 md:px-10 pt-14 md:pt-20 pb-16 md:pb-24 doc-grid">
    <div className="absolute inset-0 bg-gradient-to-b from-paper via-paper to-paper/0" />
    <div className="relative max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
      <div>
        <span className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-indigo-deep bg-indigo-soft px-3 py-1 rounded-full mb-5">
          <ScanLine size={12} /> AI Resume Builder
        </span>
        <h1 className="font-display text-[2.6rem] md:text-[3.4rem] leading-[1.05] text-ink mb-5">
          Write resumes that
          <br />
          survive the <span className="text-indigo italic">scan</span>.
        </h1>
        <p className="text-ink-soft text-base md:text-lg max-w-md mb-8 leading-relaxed">
          Most resumes never reach a human — an ATS filters them first. ResumeAI drafts your
          summary, sharpens your project bullets, and scores every resume against the keywords
          that get you through.
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <Link
            to="/register"
            className="inline-flex items-center gap-2 bg-indigo text-white px-5 py-3 rounded-lg font-medium text-sm hover:bg-indigo-deep transition-colors shadow-card"
          >
            Build your resume free <ArrowRight size={16} />
          </Link>
          <a
            href="#how-it-works"
            className="inline-flex items-center gap-2 text-ink-soft hover:text-ink px-5 py-3 rounded-lg font-medium text-sm transition-colors"
          >
            See how scoring works
          </a>
        </div>
      </div>

      {/* Signature element: a mock resume document being swept by a scan
          beam, with keyword chips standing in for what the ATS is looking for */}
      <div className="relative">
        <div className="relative bg-white border border-mist rounded-xl shadow-card p-6 md:p-7 overflow-hidden">
          <div className="scan-rail">
            <div className="scan-beam absolute inset-x-0 animate-scan" />
          </div>
          <div className="relative">
            <div className="h-3 w-2/5 bg-ink/85 rounded mb-2" />
            <div className="h-2 w-3/5 bg-mist rounded mb-5" />
            <div className="space-y-1.5 mb-5">
              <div className="h-2 bg-mist rounded w-full" />
              <div className="h-2 bg-mist rounded w-[92%]" />
              <div className="h-2 bg-mist rounded w-[78%]" />
            </div>
            <div className="h-2 w-1/4 bg-ink/70 rounded mb-3" />
            <div className="flex flex-wrap gap-2">
              {KEYWORDS.map((kw, i) => (
                <span
                  key={kw}
                  className="font-mono text-[11px] px-2.5 py-1 rounded-md border border-indigo/25 bg-indigo-soft text-indigo-deep"
                  style={{ animationDelay: `${i * 0.18}s` }}
                >
                  {kw}
                </span>
              ))}
            </div>
          </div>
        </div>
        <div className="absolute -bottom-4 -right-4 bg-white border border-mist rounded-xl shadow-card px-4 py-3 flex items-center gap-2.5">
          <div className="font-mono text-lg font-semibold text-signal">87</div>
          <div className="text-xs text-ink-soft leading-tight">
            ATS score
            <br />
            this resume
          </div>
        </div>
      </div>
    </div>
  </section>
);

const STEPS = [
  { n: '01', title: 'Tell it who you are', desc: 'Education, experience, projects, skills — entered once, reused everywhere.' },
  { n: '02', title: 'Let AI draft the language', desc: 'Summaries, bullet points, and achievements written in resume-ready phrasing.' },
  { n: '03', title: 'Score it against a real job', desc: 'Paste a job description and see exactly which keywords are missing.' },
  { n: '04', title: 'Export and apply', desc: 'Download a clean PDF, generate a matching cover letter, and send it.' },
];

const HowItWorks = () => (
  <section id="how-it-works" className="px-6 md:px-10 py-16 md:py-20 border-t border-mist">
    <div className="max-w-6xl mx-auto">
      <h2 className="font-display text-2xl md:text-3xl text-ink mb-2">From blank page to interview</h2>
      <p className="text-ink-soft mb-10 max-w-lg">The same four steps every time, in the order an ATS actually evaluates a candidate.</p>
      <div className="grid md:grid-cols-4 gap-6">
        {STEPS.map((s) => (
          <div key={s.n} className="relative pl-0">
            <div className="font-mono text-xs text-indigo-deep mb-3">{s.n}</div>
            <h3 className="font-display text-lg text-ink mb-1.5">{s.title}</h3>
            <p className="text-sm text-ink-soft leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const FEATURES = [
  { icon: Sparkles, title: 'AI Resume Generator', desc: 'Professional summaries, career objectives, and project bullet points — drafted from what you already entered.' },
  { icon: ScanLine, title: 'ATS Analyzer', desc: 'A 0–100 score broken into keywords, skills, formatting, experience, and readability, with concrete fixes.' },
  { icon: Target, title: 'Job Match', desc: 'Compare any resume against a job posting and see your match percentage before you apply.' },
  { icon: Mail, title: 'Cover Letter Generator', desc: 'A personalized cover letter for each role, built from your resume and the job description.' },
];

const Features = () => (
  <section className="px-6 md:px-10 py-16 md:py-20 bg-paper-dim/50 border-t border-mist">
    <div className="max-w-6xl mx-auto">
      <h2 className="font-display text-2xl md:text-3xl text-ink mb-10">What's actually inside</h2>
      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-5">
        {FEATURES.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="bg-white border border-mist rounded-xl p-5 shadow-card">
            <div className="w-9 h-9 rounded-lg bg-indigo-soft flex items-center justify-center mb-4">
              <Icon size={17} className="text-indigo-deep" />
            </div>
            <h3 className="font-display text-base text-ink mb-1.5">{title}</h3>
            <p className="text-sm text-ink-soft leading-relaxed">{desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const ClosingCta = () => (
  <section className="px-6 md:px-10 py-20 text-center border-t border-mist">
    <FileCheck2 size={28} className="text-indigo mx-auto mb-5" />
    <h2 className="font-display text-2xl md:text-3xl text-ink mb-3">Your next resume starts here.</h2>
    <p className="text-ink-soft mb-7">Free to start. No credit card required.</p>
    <Link
      to="/register"
      className="inline-flex items-center gap-2 bg-indigo text-white px-6 py-3 rounded-lg font-medium text-sm hover:bg-indigo-deep transition-colors shadow-card"
    >
      Create your account <ArrowRight size={16} />
    </Link>
  </section>
);

const Landing = () => (
  <>
    <Hero />
    <HowItWorks />
    <Features />
    <ClosingCta />
  </>
);

export default Landing;
