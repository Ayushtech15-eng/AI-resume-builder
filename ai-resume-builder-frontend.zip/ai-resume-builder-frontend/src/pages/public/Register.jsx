import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, useNavigate } from 'react-router-dom';
import { ScanLine, ArrowRight } from 'lucide-react';
import { useAuth, getErrorMessage } from '../../context/AuthContext';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import Button from '../../components/common/Button';
import BrandPanel from './BrandPanel';

const Register = () => {
  const { register: registerUser } = useAuth();
  const navigate = useNavigate();
  const [serverError, setServerError] = useState('');
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm({ defaultValues: { role: 'jobseeker' } });

  const onSubmit = async (values) => {
    setServerError('');
    try {
      await registerUser(values);
      navigate('/dashboard', { replace: true });
    } catch (err) {
      setServerError(getErrorMessage(err));
    }
  };

  return (
    <div className="min-h-[calc(100vh-140px)] grid md:grid-cols-2">
      <div className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-2 mb-8 md:hidden">
            <div className="w-8 h-8 rounded-lg bg-indigo flex items-center justify-center">
              <ScanLine size={16} className="text-white" />
            </div>
            <span className="font-display text-lg text-ink">
              Resume<span className="text-indigo">AI</span>
            </span>
          </div>

          <h1 className="font-display text-2xl text-ink mb-1.5">Create your account</h1>
          <p className="text-sm text-ink-soft mb-7">Free to start — no credit card needed.</p>

          {serverError && (
            <div className="mb-4 text-sm text-crimson bg-crimson/5 border border-crimson/20 rounded-lg px-3.5 py-2.5">
              {serverError}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input
              label="Full name"
              placeholder="Jane Doe"
              required
              error={errors.name?.message}
              {...register('name', { required: 'Name is required' })}
            />
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              required
              error={errors.email?.message}
              {...register('email', { required: 'Email is required' })}
            />
            <Input
              label="Password"
              type="password"
              placeholder="At least 6 characters"
              required
              error={errors.password?.message}
              {...register('password', {
                required: 'Password is required',
                minLength: { value: 6, message: 'Use at least 6 characters' },
              })}
            />
            <Select label="I am a…" {...register('role')}>
              <option value="jobseeker">Job seeker</option>
              <option value="recruiter">Recruiter</option>
            </Select>

            <Button type="submit" loading={isSubmitting} className="w-full" icon={ArrowRight}>
              Create account
            </Button>
          </form>

          <p className="text-sm text-ink-soft mt-6 text-center">
            Already have an account?{' '}
            <Link to="/login" className="text-indigo-deep font-medium hover:underline">
              Log in
            </Link>
          </p>
        </div>
      </div>

      <BrandPanel />
    </div>
  );
};

export default Register;
