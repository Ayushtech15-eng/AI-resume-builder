import { useEffect, useState } from 'react';
import { LayoutTemplate } from 'lucide-react';
import * as templatesApi from '../api/templates';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import EmptyState from '../components/common/EmptyState';

const TemplatesPage = () => {
  const toast = useToast();
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await templatesApi.getTemplates();
        setTemplates(data.templates);
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading templates…" />
      </div>
    );
  }

  if (templates.length === 0) {
    return (
      <EmptyState
        icon={LayoutTemplate}
        title="No templates yet"
        description="Ask an admin to run the template seed script, or add some from the admin panel."
      />
    );
  }

  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {templates.map((t) => (
        <Card key={t._id} className="overflow-hidden">
          <div className="h-28 flex items-center justify-center" style={{ backgroundColor: `${t.accentColor}14` }}>
            <div className="w-16 h-20 bg-white rounded shadow-card border border-mist p-2 flex flex-col gap-1">
              <div className="h-1.5 w-3/5 rounded" style={{ backgroundColor: t.accentColor }} />
              <div className="h-1 w-full bg-mist rounded" />
              <div className="h-1 w-4/5 bg-mist rounded" />
              <div className="h-1 w-2/3 bg-mist rounded mt-1" />
            </div>
          </div>
          <div className="p-4">
            <div className="flex items-center justify-between mb-1">
              <h3 className="font-display text-base text-ink">{t.name}</h3>
              {t.isPremium && <Badge tone="warning">Premium</Badge>}
            </div>
            <Badge tone="indigo" className="mb-2">
              {t.type}
            </Badge>
            <p className="text-sm text-ink-soft">{t.description}</p>
          </div>
        </Card>
      ))}
    </div>
  );
};

export default TemplatesPage;
