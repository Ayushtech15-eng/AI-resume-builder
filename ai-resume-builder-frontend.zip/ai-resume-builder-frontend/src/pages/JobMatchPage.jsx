import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Target } from 'lucide-react';
import * as resumesApi from '../api/resumes';
import * as jobMatchApi from '../api/jobMatch';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Select from '../components/common/Select';
import TextArea from '../components/common/TextArea';
import ScoreGauge from '../components/common/ScoreGauge';
import ScanLoader from '../components/common/ScanLoader';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';

const VERDICT_TONE = { 'Strong Match': 'success', 'Moderate Match': 'warning' };

const JobMatchPage = () => {
  const toast = useToast();
  const [searchParams] = useSearchParams();
  const [resumes, setResumes] = useState([]);
  const [resumeId, setResumeId] = useState(searchParams.get('resumeId') || '');
  const [jobDescription, setJobDescription] = useState('');
  const [loading, setLoading] = useState(true);
  const [matching, setMatching] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await resumesApi.getResumes();
        setResumes(data.resumes);
        if (!resumeId && data.resumes.length) setResumeId(data.resumes[0]._id);
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const runMatch = async () => {
    if (!resumeId || !jobDescription.trim()) {
      toast.error('Select a resume and paste a job description.');
      return;
    }
    setMatching(true);
    setResult(null);
    try {
      const { data } = await jobMatchApi.matchJob(resumeId, jobDescription);
      setResult(data);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setMatching(false);
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading resumes…" />
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-3xl">
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <Target size={16} className="text-indigo-deep" />
          <h3 className="font-display text-base text-ink">Match a resume to a job</h3>
        </div>
        <div className="space-y-4">
          <Select label="Resume" value={resumeId} onChange={(e) => setResumeId(e.target.value)}>
            <option value="">Select a resume…</option>
            {resumes.map((r) => (
              <option key={r._id} value={r._id}>
                {r.title}
              </option>
            ))}
          </Select>
          <TextArea label="Job description" required rows={6} value={jobDescription} onChange={(e) => setJobDescription(e.target.value)} />
          <Button icon={Target} loading={matching} onClick={runMatch} className="w-full sm:w-auto">
            Check match
          </Button>
        </div>
      </Card>

      {matching && <ScanLoader label="Comparing resume to job description…" />}

      {result && !matching && (
        <Card className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6 mb-5">
            <ScoreGauge score={result.matchPercentage} size={140} label="Match" />
            <div>
              <Badge tone={VERDICT_TONE[result.verdict] || 'danger'} className="mb-2">
                {result.verdict}
              </Badge>
              <p className="text-sm text-ink-soft">
                {result.matchedSkills.length} of {result.matchedSkills.length + result.missingSkills.length} key terms from
                this posting show up in your resume.
              </p>
            </div>
          </div>

          {result.matchedSkills?.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft/70 mb-1.5">You already have</p>
              <div className="flex flex-wrap gap-1.5">
                {result.matchedSkills.map((s) => (
                  <Badge key={s} tone="success">
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          {result.missingSkills?.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft/70 mb-1.5">Consider adding</p>
              <div className="flex flex-wrap gap-1.5">
                {result.missingSkills.map((s) => (
                  <Badge key={s} tone="danger">
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}
    </div>
  );
};

export default JobMatchPage;
