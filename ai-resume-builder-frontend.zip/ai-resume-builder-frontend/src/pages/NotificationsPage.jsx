import { useEffect, useState } from 'react';
import { Bell, Check, CheckCheck, Trash2 } from 'lucide-react';
import * as notificationsApi from '../api/notifications';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import EmptyState from '../components/common/EmptyState';
import Spinner from '../components/common/Spinner';
import { timeAgo } from '../utils/formatDate';
import { cx } from '../utils/classNames';

const NotificationsPage = () => {
  const toast = useToast();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const { data } = await notificationsApi.getNotifications();
      setNotifications(data.notifications);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const markRead = async (id) => {
    try {
      await notificationsApi.markAsRead(id);
      setNotifications((prev) => prev.map((n) => (n._id === id ? { ...n, isRead: true } : n)));
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const markAllRead = async () => {
    try {
      await notificationsApi.markAllAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
      toast.success('All notifications marked as read.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  const remove = async (id) => {
    try {
      await notificationsApi.deleteNotification(id);
      setNotifications((prev) => prev.filter((n) => n._id !== id));
    } catch (err) {
      toast.error(getErrorMessage(err));
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading notifications…" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-4">
      <div className="flex justify-end">
        {notifications.some((n) => !n.isRead) && (
          <Button size="sm" variant="secondary" icon={CheckCheck} onClick={markAllRead}>
            Mark all as read
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <EmptyState icon={Bell} title="You're all caught up" description="Activity from AI generations, ATS scans, and job matches will show up here." />
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => (
            <Card key={n._id} className={cx('p-4 flex items-start justify-between gap-3', !n.isRead && 'border-indigo/40 bg-indigo-soft/30')}>
              <div className="flex items-start gap-3">
                <div className={cx('w-2 h-2 rounded-full mt-1.5 shrink-0', n.isRead ? 'bg-mist' : 'bg-indigo')} />
                <div>
                  <p className="text-sm text-ink">{n.message}</p>
                  <p className="text-xs text-ink-soft mt-0.5">{timeAgo(n.createdAt)}</p>
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {!n.isRead && (
                  <button onClick={() => markRead(n._id)} className="p-2 text-ink-soft hover:text-indigo-deep rounded-lg hover:bg-paper-dim" title="Mark as read">
                    <Check size={14} />
                  </button>
                )}
                <button onClick={() => remove(n._id)} className="p-2 text-ink-soft hover:text-crimson rounded-lg hover:bg-crimson/5" title="Delete">
                  <Trash2 size={14} />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default NotificationsPage;
