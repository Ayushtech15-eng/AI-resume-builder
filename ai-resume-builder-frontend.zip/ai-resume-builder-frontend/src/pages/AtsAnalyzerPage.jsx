import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ScanLine, History } from 'lucide-react';
import * as resumesApi from '../api/resumes';
import * as atsApi from '../api/ats';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Select from '../components/common/Select';
import TextArea from '../components/common/TextArea';
import ScoreGauge from '../components/common/ScoreGauge';
import ScanLoader from '../components/common/ScanLoader';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';
import { timeAgo } from '../utils/formatDate';

const BREAKDOWN_LABELS = {
  keywordScore: 'Keywords',
  skillsScore: 'Skills',
  formattingScore: 'Formatting',
  experienceScore: 'Experience',
  readabilityScore: 'Readability',
};

const BreakdownBar = ({ label, value }) => (
  <div>
    <div className="flex justify-between text-xs text-ink-soft mb-1">
      <span>{label}</span>
      <span className="font-mono">{value}</span>
    </div>
    <div className="h-1.5 bg-paper-dim rounded-full overflow-hidden">
      <div className="h-full bg-indigo rounded-full transition-all" style={{ width: `${value}%` }} />
    </div>
  </div>
);

const AtsAnalyzerPage = () => {
  const toast = useToast();
  const [searchParams] = useSearchParams();
  const [resumes, setResumes] = useState([]);
  const [resumeId, setResumeId] = useState(searchParams.get('resumeId') || '');
  const [jobDescription, setJobDescription] = useState('');
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [report, setReport] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await resumesApi.getResumes();
        setResumes(data.resumes);
        if (!resumeId && data.resumes.length) setResumeId(data.resumes[0]._id);
      } catch (err) {
        toast.error(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!resumeId) return;
    atsApi
      .getReportsForResume(resumeId)
      .then(({ data }) => setHistory(data.reports))
      .catch(() => setHistory([]));
  }, [resumeId]);

  const runScan = async () => {
    if (!resumeId) {
      toast.error('Add a resume first.');
      return;
    }
    setScanning(true);
    setReport(null);
    try {
      const { data } = await atsApi.analyzeResume(resumeId, jobDescription);
      setReport(data.report);
      setHistory((prev) => [data.report, ...prev]);
      toast.success('ATS scan complete.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setScanning(false);
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading resumes…" />
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-3xl">
      <Card className="p-5">
        <div className="flex items-center gap-2 mb-4">
          <ScanLine size={16} className="text-indigo-deep" />
          <h3 className="font-display text-base text-ink">Run an ATS scan</h3>
        </div>
        <div className="space-y-4">
          <Select label="Resume" value={resumeId} onChange={(e) => setResumeId(e.target.value)}>
            <option value="">Select a resume…</option>
            {resumes.map((r) => (
              <option key={r._id} value={r._id}>
                {r.title}
              </option>
            ))}
          </Select>
          <TextArea
            label="Job description (optional)"
            hint="Paste a job posting to score keyword match against that specific role. Leave blank for a general ATS health check."
            rows={5}
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
          />
          <Button icon={ScanLine} loading={scanning} onClick={runScan} className="w-full sm:w-auto">
            Run scan
          </Button>
        </div>
      </Card>

      {scanning && <ScanLoader />}

      {report && !scanning && (
        <Card className="p-6">
          <div className="flex flex-col sm:flex-row items-center gap-6 mb-6">
            <ScoreGauge score={report.score} size={140} />
            <div className="flex-1 w-full space-y-3">
              {Object.entries(report.breakdown || {}).map(([key, value]) => (
                <BreakdownBar key={key} label={BREAKDOWN_LABELS[key] || key} value={value} />
              ))}
            </div>
          </div>

          {report.matchedKeywords?.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft/70 mb-1.5">Matched keywords</p>
              <div className="flex flex-wrap gap-1.5">
                {report.matchedKeywords.map((k) => (
                  <Badge key={k} tone="success">
                    {k}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          {report.missingKeywords?.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft/70 mb-1.5">Missing keywords</p>
              <div className="flex flex-wrap gap-1.5">
                {report.missingKeywords.map((k) => (
                  <Badge key={k} tone="danger">
                    {k}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-ink-soft/70 mb-2">Suggestions</p>
            <ul className="space-y-1.5 text-sm text-ink-soft list-disc ml-4">
              {report.suggestions.map((s, i) => (
                <li key={i}>{s}</li>
              ))}
            </ul>
          </div>
        </Card>
      )}

      {history.length > 0 && (
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3">
            <History size={15} className="text-ink-soft" />
            <h3 className="font-display text-base text-ink">Scan history</h3>
          </div>
          <div className="space-y-2">
            {history.map((h) => (
              <div key={h._id} className="flex items-center justify-between text-sm py-1.5 border-b border-mist/60 last:border-0">
                <span className="text-ink-soft">{timeAgo(h.createdAt)}</span>
                <span className="font-mono text-ink">{h.score}/100</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
};

export default AtsAnalyzerPage;
