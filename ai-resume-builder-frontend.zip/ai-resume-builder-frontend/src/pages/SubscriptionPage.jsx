import { useEffect, useState } from 'react';
import { CreditCard, Check, Zap } from 'lucide-react';
import * as subscriptionsApi from '../api/subscriptions';
import { getErrorMessage } from '../api/axiosClient';
import { useToast } from '../context/ToastContext';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Badge from '../components/common/Badge';
import Spinner from '../components/common/Spinner';

const FREE_PERKS = ['1 resume version', '10 AI generations per day', 'All standard templates', 'PDF export'];
const PREMIUM_PERKS = [
  'Unlimited resume versions',
  'Unlimited AI generations',
  'Premium templates',
  'Priority ATS analysis',
  'Unlimited cover letters',
];

const SubscriptionPage = () => {
  const toast = useToast();
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const load = async () => {
    try {
      const { data } = await subscriptionsApi.getMySubscription();
      setSubscription(data.subscription);
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const upgrade = async () => {
    setUpgrading(true);
    try {
      // NOTE: no real payment gateway is wired up here. In production this
      // button would launch Razorpay/Stripe checkout and only call /upgrade
      // after a verified webhook confirms payment. paymentRef below is a
      // stand-in confirmation id for demo purposes.
      const demoPaymentRef = `demo_${Date.now()}`;
      const { data } = await subscriptionsApi.upgradeToPremium({ paymentRef: demoPaymentRef, months: 1 });
      setSubscription(data.subscription);
      toast.success('Upgraded to Premium.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setUpgrading(false);
    }
  };

  const cancel = async () => {
    if (!window.confirm('Cancel your Premium subscription?')) return;
    setCancelling(true);
    try {
      const { data } = await subscriptionsApi.cancelSubscription();
      setSubscription(data.subscription);
      toast.success('Subscription cancelled.');
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setCancelling(false);
    }
  };

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="Loading subscription…" />
      </div>
    );
  }

  const isPremium = subscription?.plan === 'premium' && subscription?.status === 'active';

  return (
    <div className="max-w-3xl space-y-6">
      <Card className="p-5 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <CreditCard size={18} className="text-indigo-deep" />
          <div>
            <p className="text-sm text-ink-soft">Current plan</p>
            <Badge tone={isPremium ? 'success' : 'neutral'}>{isPremium ? 'Premium' : 'Free'}</Badge>
          </div>
        </div>
        {!isPremium && (
          <p className="text-sm text-ink-soft font-mono">
            {subscription?.aiUsageCount ?? 0} / {subscription?.aiUsageLimit ?? 10} AI calls used today
          </p>
        )}
        {isPremium && subscription?.endDate && (
          <p className="text-sm text-ink-soft">Renews {new Date(subscription.endDate).toLocaleDateString()}</p>
        )}
      </Card>

      <div className="grid sm:grid-cols-2 gap-5">
        <Card className={`p-6 ${!isPremium ? 'border-indigo' : ''}`}>
          <h3 className="font-display text-lg text-ink mb-1">Free</h3>
          <p className="text-2xl font-display text-ink mb-4">R0</p>
          <ul className="space-y-2 mb-2">
            {FREE_PERKS.map((p) => (
              <li key={p} className="flex items-center gap-2 text-sm text-ink-soft">
                <Check size={14} className="text-signal shrink-0" /> {p}
              </li>
            ))}
          </ul>
        </Card>

        <Card className={`p-6 ${isPremium ? 'border-indigo' : ''}`}>
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-display text-lg text-ink">Premium</h3>
            <Zap size={15} className="text-amber" />
          </div>
          <p className="text-2xl font-display text-ink mb-4">R99 / month</p>
          <ul className="space-y-2 mb-5">
            {PREMIUM_PERKS.map((p) => (
              <li key={p} className="flex items-center gap-2 text-sm text-ink-soft">
                <Check size={14} className="text-signal shrink-0" /> {p}
              </li>
            ))}
          </ul>
          {isPremium ? (
            <Button variant="danger" loading={cancelling} onClick={cancel} className="w-full">
              Cancel subscription
            </Button>
          ) : (
            <Button loading={upgrading} onClick={upgrade} className="w-full">
              Upgrade to Premium
            </Button>
          )}
        </Card>
      </div>

      <p className="text-xs text-ink-soft">
        This demo upgrade flow skips real payment processing. Wire up Razorpay or Stripe checkout in production and only
        confirm the upgrade after a verified payment webhook.
      </p>
    </div>
  );
};

export default SubscriptionPage;
