import axiosClient from './axiosClient';

export const getMySubscription = () => axiosClient.get('/subscriptions/me');
export const upgradeToPremium = (data) => axiosClient.post('/subscriptions/upgrade', data);
export const cancelSubscription = () => axiosClient.post('/subscriptions/cancel');
