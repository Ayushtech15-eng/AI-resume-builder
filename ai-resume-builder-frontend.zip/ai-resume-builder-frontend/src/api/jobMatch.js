import axiosClient from './axiosClient';

export const matchJob = (resumeId, jobDescription) =>
  axiosClient.post(`/job-match/${resumeId}`, { jobDescription });
