import axiosClient from './axiosClient';

export const generateCoverLetter = (data) => axiosClient.post('/cover-letters/generate', data);
export const getCoverLetters = () => axiosClient.get('/cover-letters');
export const getCoverLetterById = (id) => axiosClient.get(`/cover-letters/${id}`);
export const updateCoverLetter = (id, data) => axiosClient.put(`/cover-letters/${id}`, data);
export const deleteCoverLetter = (id) => axiosClient.delete(`/cover-letters/${id}`);
