import axiosClient from './axiosClient';

export const analyzeResume = (resumeId, jobDescription) =>
  axiosClient.post(`/ats/analyze/${resumeId}`, { jobDescription });
export const getReportsForResume = (resumeId) => axiosClient.get(`/ats/reports/${resumeId}`);
export const getAllReports = () => axiosClient.get('/ats/reports');
