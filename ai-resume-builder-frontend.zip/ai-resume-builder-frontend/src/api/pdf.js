import axiosClient from './axiosClient';

// Returns a Blob the caller can turn into a download link
export const downloadResumePdf = (resumeId) =>
  axiosClient.get(`/pdf/resume/${resumeId}`, { responseType: 'blob' });
