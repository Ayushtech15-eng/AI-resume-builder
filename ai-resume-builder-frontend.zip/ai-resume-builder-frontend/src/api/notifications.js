import axiosClient from './axiosClient';

export const getNotifications = (unreadOnly = false) =>
  axiosClient.get('/notifications', { params: unreadOnly ? { unreadOnly: 'true' } : {} });
export const markAsRead = (id) => axiosClient.put(`/notifications/${id}/read`);
export const markAllAsRead = () => axiosClient.put('/notifications/read-all');
export const deleteNotification = (id) => axiosClient.delete(`/notifications/${id}`);
