import axiosClient from './axiosClient';

export const getUsers = (params) => axiosClient.get('/admin/users', { params });
export const updateUserRole = (id, role) => axiosClient.put(`/admin/users/${id}/role`, { role });
export const toggleUserActive = (id) => axiosClient.put(`/admin/users/${id}/deactivate`);
export const getAnalytics = () => axiosClient.get('/admin/analytics');
