import axiosClient from './axiosClient';

export const register = (data) => axiosClient.post('/auth/register', data);
export const login = (data) => axiosClient.post('/auth/login', data);
export const googleLogin = (data) => axiosClient.post('/auth/google', data);
export const getMe = () => axiosClient.get('/auth/me');
export const logout = () => axiosClient.post('/auth/logout');
export const verifyEmail = (data) => axiosClient.post('/auth/verify-email', data);
export const forgotPassword = (data) => axiosClient.post('/auth/forgot-password', data);
export const resetPassword = (data) => axiosClient.post('/auth/reset-password', data);
export const changePassword = (data) => axiosClient.put('/auth/change-password', data);
