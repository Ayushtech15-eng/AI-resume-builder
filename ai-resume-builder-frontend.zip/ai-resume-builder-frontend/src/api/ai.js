import axiosClient from './axiosClient';

export const reviewResume = () => axiosClient.post('/ai/review-resume');
export const generateSummary = (data) => axiosClient.post('/ai/generate-summary', data);
export const generateObjective = (data) => axiosClient.post('/ai/generate-objective', data);
