import axiosClient from './axiosClient';

export const getProjects = () => axiosClient.get('/projects');
export const createProject = (data) => axiosClient.post('/projects', data);
export const updateProject = (id, data) => axiosClient.put(`/projects/${id}`, data);
export const deleteProject = (id) => axiosClient.delete(`/projects/${id}`);
export const aiGenerateProjectDescription = (id) => axiosClient.post(`/projects/${id}/ai-description`);
export const aiGenerateTechnicalSummary = (id) => axiosClient.post(`/projects/${id}/ai-technical-summary`);
