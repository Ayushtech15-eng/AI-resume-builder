import axiosClient from './axiosClient';

export const getSkills = () => axiosClient.get('/skills');
export const createSkill = (data) => axiosClient.post('/skills', data);
export const createSkillsBulk = (skills) => axiosClient.post('/skills/bulk', { skills });
export const deleteSkill = (id) => axiosClient.delete(`/skills/${id}`);
export const aiRecommendSkills = (targetRole) => axiosClient.post('/skills/ai-recommend', { targetRole });
export const skillGapAnalysis = (targetRole) =>
  axiosClient.get('/skills/gap-analysis', { params: { targetRole } });
