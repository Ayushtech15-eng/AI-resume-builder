import axiosClient from './axiosClient';

export const getProfile = () => axiosClient.get('/profile');
export const updateProfile = (data) => axiosClient.put('/profile', data);
