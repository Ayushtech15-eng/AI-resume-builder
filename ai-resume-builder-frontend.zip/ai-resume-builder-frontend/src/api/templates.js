import axiosClient from './axiosClient';

export const getTemplates = () => axiosClient.get('/templates');
