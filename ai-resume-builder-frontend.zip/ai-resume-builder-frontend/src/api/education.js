import axiosClient from './axiosClient';

export const getEducation = () => axiosClient.get('/education');
export const createEducation = (data) => axiosClient.post('/education', data);
export const updateEducation = (id, data) => axiosClient.put(`/education/${id}`, data);
export const deleteEducation = (id) => axiosClient.delete(`/education/${id}`);
