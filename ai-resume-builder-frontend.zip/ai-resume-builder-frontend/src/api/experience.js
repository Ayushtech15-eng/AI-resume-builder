import axiosClient from './axiosClient';

export const getExperience = () => axiosClient.get('/experience');
export const createExperience = (data) => axiosClient.post('/experience', data);
export const updateExperience = (id, data) => axiosClient.put(`/experience/${id}`, data);
export const deleteExperience = (id) => axiosClient.delete(`/experience/${id}`);
export const aiEnhanceExperience = (id) => axiosClient.post(`/experience/${id}/ai-enhance`);
export const aiGenerateAchievements = (id) => axiosClient.post(`/experience/${id}/ai-achievements`);
