import axiosClient from './axiosClient';

export const getResumes = () => axiosClient.get('/resumes');
export const getResumeById = (id) => axiosClient.get(`/resumes/${id}`);
export const createResume = (data) => axiosClient.post('/resumes', data);
export const updateResume = (id, data) => axiosClient.put(`/resumes/${id}`, data);
export const deleteResume = (id) => axiosClient.delete(`/resumes/${id}`);
export const duplicateResume = (id) => axiosClient.post(`/resumes/${id}/duplicate`);
export const setPrimaryResume = (id) => axiosClient.post(`/resumes/${id}/set-primary`);
export const compareResumes = (ids) => axiosClient.get('/resumes/compare', { params: { ids: ids.join(',') } });
export const aiGenerateResumeContent = (id, targetRole) =>
  axiosClient.post(`/resumes/${id}/ai-generate`, { targetRole });
