/**
 * Signature motif: a thin indigo "scan beam" sweeping over content,
 * used while the ATS Analyzer / AI features are processing - ties the
 * loading state directly to the idea of a resume being scanned.
 */
const ScanLoader = ({ label = 'Scanning resume…' }) => (
  <div className="relative overflow-hidden rounded-xl border border-mist bg-white py-14 px-6">
    <div className="scan-rail">
      <div className="scan-beam absolute inset-x-0 animate-scan" />
    </div>
    <div className="relative flex flex-col items-center gap-3 text-center">
      <div className="font-mono text-xs tracking-widest text-indigo-deep uppercase">{label}</div>
      <div className="flex gap-1.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="w-1.5 h-1.5 rounded-full bg-indigo animate-pulse"
            style={{ animationDelay: `${i * 0.15}s` }}
          />
        ))}
      </div>
    </div>
  </div>
);

export default ScanLoader;
