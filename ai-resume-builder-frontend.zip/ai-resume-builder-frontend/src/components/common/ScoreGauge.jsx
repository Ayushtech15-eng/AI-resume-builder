import { cx } from '../../utils/classNames';

const toneFor = (score) => {
  if (score >= 80) return { ring: '#1F9D62', text: 'text-signal' };
  if (score >= 55) return { ring: '#D97706', text: 'text-amber' };
  return { ring: '#DC2626', text: 'text-crimson' };
};

/**
 * Radial readout for a 0-100 score, styled like an instrument dial reading
 * a scan result - the mono digits + tick marks tie back to the ATS/
 * "machine scanning" theme used throughout the app.
 */
const ScoreGauge = ({ score = 0, size = 132, label = 'ATS Score' }) => {
  const radius = size / 2 - 10;
  const circumference = 2 * Math.PI * radius;
  const clamped = Math.max(0, Math.min(100, score));
  const offset = circumference - (clamped / 100) * circumference;
  const { ring, text } = toneFor(clamped);

  return (
    <div className="flex flex-col items-center gap-2">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#E4E2DC" strokeWidth={9} />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={ring}
            strokeWidth={9}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 0.8s ease-out' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={cx('font-mono text-2xl font-semibold', text)}>{clamped}</span>
          <span className="text-[10px] text-ink-soft font-mono">/100</span>
        </div>
      </div>
      {label && <span className="text-xs font-medium text-ink-soft uppercase tracking-wide">{label}</span>}
    </div>
  );
};

export default ScoreGauge;
