import { cx } from '../../utils/classNames';

const Card = ({ children, className, as: Tag = 'div', ...rest }) => (
  <Tag className={cx('bg-white border border-mist rounded-xl shadow-card', className)} {...rest}>
    {children}
  </Tag>
);

export default Card;
