import { Loader2 } from 'lucide-react';
import { cx } from '../../utils/classNames';

const VARIANTS = {
  primary: 'bg-indigo text-white hover:bg-indigo-deep shadow-card',
  secondary: 'bg-white text-ink border border-mist hover:border-ink/30',
  ghost: 'bg-transparent text-ink-soft hover:text-ink hover:bg-paper-dim',
  danger: 'bg-white text-crimson border border-crimson/30 hover:bg-crimson/5',
  subtle: 'bg-indigo-soft text-indigo-deep hover:bg-indigo/15',
};

const SIZES = {
  sm: 'text-xs px-3 py-1.5 gap-1.5',
  md: 'text-sm px-4 py-2.5 gap-2',
  lg: 'text-base px-5 py-3 gap-2',
};

const Button = ({
  children,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false,
  icon: Icon,
  className,
  type = 'button',
  ...rest
}) => {
  return (
    <button
      type={type}
      disabled={disabled || loading}
      className={cx(
        'inline-flex items-center justify-center rounded-lg font-medium transition-colors duration-150',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        VARIANTS[variant],
        SIZES[size],
        className
      )}
      {...rest}
    >
      {loading ? <Loader2 size={16} className="animate-spin" /> : Icon ? <Icon size={16} /> : null}
      {children}
    </button>
  );
};

export default Button;
