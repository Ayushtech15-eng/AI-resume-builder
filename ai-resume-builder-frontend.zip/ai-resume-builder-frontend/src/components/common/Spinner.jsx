import { Loader2 } from 'lucide-react';
import { cx } from '../../utils/classNames';

const Spinner = ({ size = 22, className, label }) => (
  <div className={cx('flex flex-col items-center justify-center gap-2 text-ink-soft', className)}>
    <Loader2 size={size} className="animate-spin text-indigo" />
    {label && <span className="text-sm">{label}</span>}
  </div>
);

export default Spinner;
