import { cx } from '../../utils/classNames';

const TONES = {
  neutral: 'bg-paper-dim text-ink-soft border-mist',
  indigo: 'bg-indigo-soft text-indigo-deep border-indigo/20',
  success: 'bg-signal/10 text-signal border-signal/25',
  warning: 'bg-amber/10 text-amber border-amber/25',
  danger: 'bg-crimson/10 text-crimson border-crimson/25',
};

const Badge = ({ children, tone = 'neutral', className }) => (
  <span
    className={cx(
      'inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium font-mono',
      TONES[tone],
      className
    )}
  >
    {children}
  </span>
);

export default Badge;
