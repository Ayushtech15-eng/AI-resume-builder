import { forwardRef } from 'react';
import { ChevronDown } from 'lucide-react';
import { cx } from '../../utils/classNames';

const Select = forwardRef(({ label, error, className, required, children, ...rest }, ref) => (
  <label className="block">
    {label && (
      <span className="block text-sm font-medium text-ink mb-1.5">
        {label} {required && <span className="text-crimson">*</span>}
      </span>
    )}
    <div className="relative">
      <select
        ref={ref}
        className={cx(
          'w-full appearance-none rounded-lg border bg-white px-3.5 py-2.5 pr-9 text-sm text-ink',
          'transition-colors focus:border-indigo focus:ring-1 focus:ring-indigo/30',
          error ? 'border-crimson' : 'border-mist',
          className
        )}
        {...rest}
      >
        {children}
      </select>
      <ChevronDown size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-soft pointer-events-none" />
    </div>
    {error && <span className="block text-xs text-crimson mt-1">{error}</span>}
  </label>
));
Select.displayName = 'Select';

export default Select;
