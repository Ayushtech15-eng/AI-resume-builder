import Button from './Button';

const EmptyState = ({ icon: Icon, title, description, actionLabel, onAction }) => (
  <div className="flex flex-col items-center justify-center text-center py-14 px-6 border border-dashed border-mist rounded-xl bg-paper-dim/40">
    {Icon && (
      <div className="w-11 h-11 rounded-full bg-indigo-soft flex items-center justify-center mb-4">
        <Icon size={20} className="text-indigo-deep" />
      </div>
    )}
    <h3 className="font-display text-lg text-ink mb-1">{title}</h3>
    {description && <p className="text-sm text-ink-soft max-w-sm mb-5">{description}</p>}
    {actionLabel && onAction && (
      <Button onClick={onAction} size="sm">
        {actionLabel}
      </Button>
    )}
  </div>
);

export default EmptyState;
