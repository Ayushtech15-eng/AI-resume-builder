import { forwardRef } from 'react';
import { cx } from '../../utils/classNames';

const Input = forwardRef(({ label, error, hint, className, required, ...rest }, ref) => (
  <label className="block">
    {label && (
      <span className="block text-sm font-medium text-ink mb-1.5">
        {label} {required && <span className="text-crimson">*</span>}
      </span>
    )}
    <input
      ref={ref}
      className={cx(
        'w-full rounded-lg border bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-soft/60',
        'transition-colors focus:border-indigo focus:ring-1 focus:ring-indigo/30',
        error ? 'border-crimson' : 'border-mist',
        className
      )}
      {...rest}
    />
    {hint && !error && <span className="block text-xs text-ink-soft mt-1">{hint}</span>}
    {error && <span className="block text-xs text-crimson mt-1">{error}</span>}
  </label>
));
Input.displayName = 'Input';

export default Input;
