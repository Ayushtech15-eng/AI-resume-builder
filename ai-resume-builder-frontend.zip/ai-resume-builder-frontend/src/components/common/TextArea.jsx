import { forwardRef } from 'react';
import { cx } from '../../utils/classNames';

const TextArea = forwardRef(({ label, error, hint, className, rows = 4, required, ...rest }, ref) => (
  <label className="block">
    {label && (
      <span className="block text-sm font-medium text-ink mb-1.5">
        {label} {required && <span className="text-crimson">*</span>}
      </span>
    )}
    <textarea
      ref={ref}
      rows={rows}
      className={cx(
        'w-full rounded-lg border bg-white px-3.5 py-2.5 text-sm text-ink placeholder:text-ink-soft/60 resize-y',
        'transition-colors focus:border-indigo focus:ring-1 focus:ring-indigo/30',
        error ? 'border-crimson' : 'border-mist',
        className
      )}
      {...rest}
    />
    {hint && !error && <span className="block text-xs text-ink-soft mt-1">{hint}</span>}
    {error && <span className="block text-xs text-crimson mt-1">{error}</span>}
  </label>
));
TextArea.displayName = 'TextArea';

export default TextArea;
