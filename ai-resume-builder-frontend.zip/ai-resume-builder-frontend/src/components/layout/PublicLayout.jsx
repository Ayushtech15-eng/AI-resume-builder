import { Link, Outlet } from 'react-router-dom';
import { ScanLine } from 'lucide-react';

const PublicLayout = () => (
  <div className="min-h-screen flex flex-col bg-paper">
    <header className="px-6 md:px-10 py-5 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-indigo flex items-center justify-center">
          <ScanLine size={16} className="text-white" />
        </div>
        <span className="font-display text-lg text-ink">
          Resume<span className="text-indigo">AI</span>
        </span>
      </Link>
      <nav className="flex items-center gap-2">
        <Link
          to="/login"
          className="text-sm font-medium text-ink-soft hover:text-ink px-4 py-2 rounded-lg hover:bg-paper-dim transition-colors"
        >
          Log in
        </Link>
        <Link
          to="/register"
          className="text-sm font-medium text-white bg-indigo hover:bg-indigo-deep px-4 py-2 rounded-lg transition-colors"
        >
          Get started
        </Link>
      </nav>
    </header>
    <main className="flex-1">
      <Outlet />
    </main>
    <footer className="px-6 md:px-10 py-6 text-xs text-ink-soft border-t border-mist">
      © {new Date().getFullYear()} ResumeAI. Built to get real resumes past real ATS filters.
    </footer>
  </div>
);

export default PublicLayout;
