import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, ChevronDown, LogOut, Menu, User as UserIcon } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import * as notificationsApi from '../../api/notifications';
import { cx } from '../../utils/classNames';

const Topbar = ({ onMenuClick, title }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    const fetchUnread = async () => {
      try {
        const { data } = await notificationsApi.getNotifications(true);
        setUnreadCount(data.unreadCount ?? data.count ?? 0);
      } catch {
        // silent - notifications are non-critical chrome
      }
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const onClickOutside = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <header className="h-16 border-b border-mist bg-paper/80 backdrop-blur-sm flex items-center justify-between px-4 md:px-6 sticky top-0 z-30">
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onMenuClick}
          className="md:hidden p-2 -ml-2 text-ink-soft hover:text-ink rounded-lg hover:bg-paper-dim"
          aria-label="Open menu"
        >
          <Menu size={20} />
        </button>
        <h1 className="font-display text-lg text-ink truncate">{title}</h1>
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={() => navigate('/notifications')}
          className="relative p-2 text-ink-soft hover:text-ink rounded-lg hover:bg-paper-dim"
          aria-label="Notifications"
        >
          <Bell size={19} />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-crimson text-white text-[10px] font-mono font-semibold flex items-center justify-center">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen((o) => !o)}
            className="flex items-center gap-2 pl-2 pr-1 py-1.5 rounded-lg hover:bg-paper-dim"
          >
            <div className="w-7 h-7 rounded-full bg-indigo text-white flex items-center justify-center text-xs font-medium">
              {user?.name?.[0]?.toUpperCase() || <UserIcon size={14} />}
            </div>
            <span className="text-sm text-ink hidden sm:inline">{user?.name?.split(' ')[0]}</span>
            <ChevronDown size={14} className="text-ink-soft" />
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white border border-mist rounded-xl shadow-card py-1.5 animate-fadeUp">
              <div className="px-3.5 py-2 border-b border-mist mb-1">
                <p className="text-sm font-medium text-ink truncate">{user?.name}</p>
                <p className="text-xs text-ink-soft truncate">{user?.email}</p>
              </div>
              <button
                onClick={() => {
                  setMenuOpen(false);
                  navigate('/profile');
                }}
                className={cx('w-full text-left px-3.5 py-2 text-sm text-ink-soft hover:bg-paper-dim hover:text-ink')}
              >
                Profile settings
              </button>
              <button
                onClick={handleLogout}
                className="w-full text-left px-3.5 py-2 text-sm text-crimson hover:bg-crimson/5 flex items-center gap-2"
              >
                <LogOut size={14} /> Log out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Topbar;
