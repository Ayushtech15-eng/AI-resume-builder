import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  User,
  GraduationCap,
  Briefcase,
  FolderKanban,
  Sparkles,
  FileText,
  LayoutTemplate,
  ScanLine,
  Mail,
  Target,
  CreditCard,
  ShieldCheck,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { cx } from '../../utils/classNames';

const NAV_GROUPS = [
  {
    label: 'Overview',
    items: [{ to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard }],
  },
  {
    label: 'Build your story',
    items: [
      { to: '/profile', label: 'Profile', icon: User },
      { to: '/education', label: 'Education', icon: GraduationCap },
      { to: '/experience', label: 'Experience', icon: Briefcase },
      { to: '/projects', label: 'Projects', icon: FolderKanban },
      { to: '/skills', label: 'Skills', icon: Sparkles },
    ],
  },
  {
    label: 'Create',
    items: [
      { to: '/resumes', label: 'Resumes', icon: FileText },
      { to: '/templates', label: 'Templates', icon: LayoutTemplate },
      { to: '/ats-analyzer', label: 'ATS Analyzer', icon: ScanLine },
      { to: '/job-match', label: 'Job Match', icon: Target },
      { to: '/cover-letters', label: 'Cover Letters', icon: Mail },
    ],
  },
  {
    label: 'Account',
    items: [{ to: '/subscription', label: 'Subscription', icon: CreditCard }],
  },
];

const Sidebar = ({ onNavigate }) => {
  const { user } = useAuth();

  return (
    <nav className="flex flex-col h-full px-3 py-5 overflow-y-auto">
      <div className="px-3 mb-6 flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-indigo flex items-center justify-center shrink-0">
          <ScanLine size={16} className="text-white" />
        </div>
        <span className="font-display text-[17px] text-ink leading-none">
          Resume<span className="text-indigo">AI</span>
        </span>
      </div>

      <div className="flex-1 space-y-6">
        {NAV_GROUPS.map((group) => (
          <div key={group.label}>
            <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-ink-soft/70 mb-1.5">
              {group.label}
            </p>
            <div className="space-y-0.5">
              {group.items.map(({ to, label, icon: Icon }) => (
                <NavLink
                  key={to}
                  to={to}
                  onClick={onNavigate}
                  className={({ isActive }) =>
                    cx(
                      'flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors',
                      isActive
                        ? 'bg-indigo-soft text-indigo-deep font-medium'
                        : 'text-ink-soft hover:bg-paper-dim hover:text-ink'
                    )
                  }
                >
                  <Icon size={16} />
                  {label}
                </NavLink>
              ))}
            </div>
          </div>
        ))}

        {user?.role === 'admin' && (
          <div>
            <p className="px-3 text-[11px] font-semibold uppercase tracking-wider text-ink-soft/70 mb-1.5">
              Admin
            </p>
            <NavLink
              to="/admin"
              onClick={onNavigate}
              className={({ isActive }) =>
                cx(
                  'flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors',
                  isActive ? 'bg-indigo-soft text-indigo-deep font-medium' : 'text-ink-soft hover:bg-paper-dim hover:text-ink'
                )
              }
            >
              <ShieldCheck size={16} />
              Analytics &amp; Users
            </NavLink>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Sidebar;
