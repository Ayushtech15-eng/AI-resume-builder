import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';

const TITLES = {
  '/dashboard': 'Dashboard',
  '/profile': 'Profile',
  '/education': 'Education',
  '/experience': 'Experience',
  '/projects': 'Projects',
  '/skills': 'Skills',
  '/resumes': 'Resumes',
  '/templates': 'Templates',
  '/ats-analyzer': 'ATS Analyzer',
  '/job-match': 'Job Match',
  '/cover-letters': 'Cover Letters',
  '/subscription': 'Subscription',
  '/notifications': 'Notifications',
  '/admin': 'Admin · Analytics & Users',
};

const AppLayout = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const path = '/' + window.location.pathname.split('/')[1];
  const matched = Object.keys(TITLES).find((p) => path.startsWith(p));

  return (
    <div className="min-h-screen flex bg-paper">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex md:w-64 border-r border-mist flex-col shrink-0">
        <Sidebar />
      </aside>

      {/* Mobile drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-ink/40" onClick={() => setDrawerOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-64 bg-paper border-r border-mist">
            <Sidebar onNavigate={() => setDrawerOpen(false)} />
          </aside>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <Topbar onMenuClick={() => setDrawerOpen(true)} title={matched ? TITLES[matched] : 'ResumeAI'} />
        <main className="flex-1 px-4 md:px-8 py-6 md:py-8 max-w-6xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
