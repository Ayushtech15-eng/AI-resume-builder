/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // A simple custom primary color used throughout the app
        primary: "#4F46E5",
      },
    },
  },
  plugins: [],
};
