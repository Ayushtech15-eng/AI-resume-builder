// pages/Profile.jsx
// Simple page showing the logged-in user's profile details

import { useState, useEffect, useContext } from "react";
import { toast } from "react-toastify";
import { getProfile } from "../services/authService";
import { getResumes } from "../services/resumeService";
import { AuthContext } from "../context/AuthContext";
import Spinner from "../components/Spinner";

const Profile = () => {
  const { user } = useContext(AuthContext);
  const [profile, setProfile] = useState(null);
  const [resumeCount, setResumeCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const profileData = await getProfile();
        const resumes = await getResumes();
        setProfile(profileData);
        setResumeCount(resumes.length);
      } catch (error) {
        toast.error("Failed to load profile");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) return <Spinner />;

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">My Profile</h1>

      <div className="bg-white shadow-md rounded-lg p-6">
        {/* Avatar with first letter of name */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-2xl font-bold">
            {profile?.name?.charAt(0).toUpperCase()}
          </div>
          <div>
            <h2 className="text-xl font-semibold text-gray-800">{profile?.name}</h2>
            <p className="text-gray-500 text-sm">{profile?.email}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gray-50 rounded-md p-4 text-center">
            <p className="text-2xl font-bold text-primary">{resumeCount}</p>
            <p className="text-sm text-gray-500">Resumes Created</p>
          </div>
          <div className="bg-gray-50 rounded-md p-4 text-center">
            <p className="text-sm text-gray-500 mt-1">Member since</p>
            <p className="text-sm font-medium text-gray-700">
              {profile?.createdAt
                ? new Date(profile.createdAt).toLocaleDateString()
                : "N/A"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
