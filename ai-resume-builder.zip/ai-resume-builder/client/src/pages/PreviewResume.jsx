// pages/PreviewResume.jsx
// Shows a nicely formatted preview of the resume and allows downloading it as a PDF

import { useState, useEffect, useRef } from "react";
import { useParams, Link } from "react-router-dom";
import { toast } from "react-toastify";
import html2pdf from "html2pdf.js";
import { getResumeById } from "../services/resumeService";
import Spinner from "../components/Spinner";

const PreviewResume = () => {
  const { id } = useParams();
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(true);
  const resumeRef = useRef(); // reference to the resume DOM element (used for PDF export)

  useEffect(() => {
    const fetchResume = async () => {
      try {
        const data = await getResumeById(id);
        setResume(data);
      } catch (error) {
        toast.error("Failed to load resume");
      } finally {
        setLoading(false);
      }
    };
    fetchResume();
  }, [id]);

  // Converts the resume preview div into a downloadable PDF file
  const handleDownloadPDF = () => {
    const element = resumeRef.current;
    const options = {
      margin: 0.5,
      filename: `${resume.fullName.replace(/\s+/g, "_")}_Resume.pdf`,
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "in", format: "a4", orientation: "portrait" },
    };
    html2pdf().set(options).from(element).save();
  };

  if (loading) return <Spinner />;
  if (!resume) return <p className="text-center py-10">Resume not found</p>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-4">
        <Link to="/dashboard" className="text-primary hover:underline text-sm">
          ← Back to Dashboard
        </Link>
        <button
          onClick={handleDownloadPDF}
          className="bg-primary text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-sm"
        >
          Download as PDF
        </button>
      </div>

      {/* This is the actual resume content that gets converted to PDF */}
      <div ref={resumeRef} className="bg-white shadow-md rounded-lg p-8">
        {/* Header */}
        <div className="border-b border-gray-200 pb-4 mb-4">
          <h1 className="text-3xl font-bold text-gray-800">{resume.fullName}</h1>
          {resume.jobTitle && (
            <p className="text-primary font-medium">{resume.jobTitle}</p>
          )}
          <p className="text-sm text-gray-500 mt-1">
            {resume.email} {resume.phone && `• ${resume.phone}`}
          </p>
        </div>

        {/* Summary */}
        {resume.summary && (
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-gray-700 mb-1">Professional Summary</h2>
            <p className="text-gray-600 text-sm leading-relaxed">{resume.summary}</p>
          </div>
        )}

        {/* Skills */}
        {resume.skills?.length > 0 && (
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-gray-700 mb-1">Skills</h2>
            <div className="flex flex-wrap gap-2">
              {resume.skills.map((skill, index) => (
                <span
                  key={index}
                  className="bg-indigo-50 text-primary text-xs px-2 py-1 rounded-full"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Experience */}
        {resume.experience?.length > 0 && (
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-gray-700 mb-2">Work Experience</h2>
            {resume.experience.map((exp, index) => (
              <div key={index} className="mb-3">
                <div className="flex justify-between">
                  <p className="font-medium text-gray-800">
                    {exp.role} {exp.company && `- ${exp.company}`}
                  </p>
                  <p className="text-xs text-gray-400">{exp.duration}</p>
                </div>
                {exp.description && (
                  <p className="text-sm text-gray-600 mt-1">{exp.description}</p>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Education */}
        {resume.education?.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-gray-700 mb-2">Education</h2>
            {resume.education.map((edu, index) => (
              <div key={index} className="flex justify-between mb-2">
                <p className="text-sm text-gray-800">
                  {edu.degree} {edu.institution && `- ${edu.institution}`}
                </p>
                <p className="text-xs text-gray-400">{edu.year}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PreviewResume;
