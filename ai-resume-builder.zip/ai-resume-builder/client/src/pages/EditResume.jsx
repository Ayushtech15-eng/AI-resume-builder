// pages/EditResume.jsx
// Form to edit an existing resume. Very similar to CreateResume,
// but it first loads the existing resume data from the backend.

import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { getResumeById, updateResume } from "../services/resumeService";
import { generateSummary, improveSkills } from "../services/aiService";
import Spinner from "../components/Spinner";

const EditResume = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    jobTitle: "",
    summary: "",
    skills: "",
  });
  const [education, setEducation] = useState([]);
  const [experience, setExperience] = useState([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [aiSummaryLoading, setAiSummaryLoading] = useState(false);
  const [aiSkillsLoading, setAiSkillsLoading] = useState(false);

  // Load existing resume data when page opens
  useEffect(() => {
    const fetchResume = async () => {
      try {
        const data = await getResumeById(id);
        setFormData({
          fullName: data.fullName || "",
          email: data.email || "",
          phone: data.phone || "",
          jobTitle: data.jobTitle || "",
          summary: data.summary || "",
          skills: (data.skills || []).join(", "),
        });
        setEducation(
          data.education?.length
            ? data.education
            : [{ degree: "", institution: "", year: "" }]
        );
        setExperience(
          data.experience?.length
            ? data.experience
            : [{ role: "", company: "", duration: "", description: "" }]
        );
      } catch (error) {
        toast.error("Failed to load resume");
        navigate("/dashboard");
      } finally {
        setLoading(false);
      }
    };
    fetchResume();
  }, [id, navigate]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Education handlers
  const handleEducationChange = (index, e) => {
    const updated = [...education];
    updated[index][e.target.name] = e.target.value;
    setEducation(updated);
  };
  const addEducation = () =>
    setEducation([...education, { degree: "", institution: "", year: "" }]);
  const removeEducation = (index) =>
    setEducation(education.filter((_, i) => i !== index));

  // Experience handlers
  const handleExperienceChange = (index, e) => {
    const updated = [...experience];
    updated[index][e.target.name] = e.target.value;
    setExperience(updated);
  };
  const addExperience = () =>
    setExperience([
      ...experience,
      { role: "", company: "", duration: "", description: "" },
    ]);
  const removeExperience = (index) =>
    setExperience(experience.filter((_, i) => i !== index));

  // AI: Generate Summary
  const handleGenerateSummary = async () => {
    if (!formData.jobTitle) {
      toast.warn("Please enter a job title first");
      return;
    }
    setAiSummaryLoading(true);
    try {
      const skillsArray = formData.skills.split(",").map((s) => s.trim()).filter(Boolean);
      const expText = experience.map((exp) => exp.role).filter(Boolean).join(", ");
      const data = await generateSummary(formData.jobTitle, skillsArray, expText);
      setFormData({ ...formData, summary: data.summary });
      toast.success("Summary generated!");
    } catch (error) {
      toast.error("AI failed to generate summary");
    } finally {
      setAiSummaryLoading(false);
    }
  };

  // AI: Improve Skills
  const handleImproveSkills = async () => {
    if (!formData.jobTitle) {
      toast.warn("Please enter a job title first");
      return;
    }
    setAiSkillsLoading(true);
    try {
      const currentSkills = formData.skills.split(",").map((s) => s.trim()).filter(Boolean);
      const data = await improveSkills(formData.jobTitle, currentSkills);
      setFormData({ ...formData, skills: data.skills.join(", ") });
      toast.success("Skills improved with AI suggestions!");
    } catch (error) {
      toast.error("AI failed to improve skills");
    } finally {
      setAiSkillsLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const resumeData = {
        ...formData,
        skills: formData.skills.split(",").map((s) => s.trim()).filter(Boolean),
        education,
        experience,
      };
      await updateResume(id, resumeData);
      toast.success("Resume updated successfully!");
      navigate(`/preview/${id}`);
    } catch (error) {
      toast.error(error.response?.data?.message || "Failed to update resume");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Spinner />;

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Edit Resume</h1>

      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-lg p-6 space-y-6">
        {/* Personal Details */}
        <section>
          <h2 className="text-lg font-semibold text-gray-700 mb-3">Personal Details</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <input
              type="text"
              name="fullName"
              placeholder="Full Name"
              value={formData.fullName}
              onChange={handleChange}
              required
              className="border border-gray-300 rounded-md px-3 py-2"
            />
            <input
              type="text"
              name="jobTitle"
              placeholder="Job Title"
              value={formData.jobTitle}
              onChange={handleChange}
              className="border border-gray-300 rounded-md px-3 py-2"
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              className="border border-gray-300 rounded-md px-3 py-2"
            />
            <input
              type="text"
              name="phone"
              placeholder="Phone Number"
              value={formData.phone}
              onChange={handleChange}
              className="border border-gray-300 rounded-md px-3 py-2"
            />
          </div>
        </section>

        {/* Summary */}
        <section>
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-lg font-semibold text-gray-700">Professional Summary</h2>
            <button
              type="button"
              onClick={handleGenerateSummary}
              disabled={aiSummaryLoading}
              className="text-sm bg-indigo-50 text-primary px-3 py-1 rounded-md hover:bg-indigo-100 disabled:opacity-60"
            >
              {aiSummaryLoading ? "Generating..." : "✨ Generate with AI"}
            </button>
          </div>
          <textarea
            name="summary"
            rows="4"
            value={formData.summary}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          />
        </section>

        {/* Skills */}
        <section>
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-lg font-semibold text-gray-700">Skills</h2>
            <button
              type="button"
              onClick={handleImproveSkills}
              disabled={aiSkillsLoading}
              className="text-sm bg-indigo-50 text-primary px-3 py-1 rounded-md hover:bg-indigo-100 disabled:opacity-60"
            >
              {aiSkillsLoading ? "Improving..." : "✨ Improve with AI"}
            </button>
          </div>
          <input
            type="text"
            name="skills"
            placeholder="e.g. React, Node.js, MongoDB"
            value={formData.skills}
            onChange={handleChange}
            className="w-full border border-gray-300 rounded-md px-3 py-2"
          />
        </section>

        {/* Education */}
        <section>
          <h2 className="text-lg font-semibold text-gray-700 mb-3">Education</h2>
          {education.map((edu, index) => (
            <div key={index} className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
              <input
                type="text"
                name="degree"
                placeholder="Degree"
                value={edu.degree}
                onChange={(e) => handleEducationChange(index, e)}
                className="border border-gray-300 rounded-md px-3 py-2"
              />
              <input
                type="text"
                name="institution"
                placeholder="Institution"
                value={edu.institution}
                onChange={(e) => handleEducationChange(index, e)}
                className="border border-gray-300 rounded-md px-3 py-2"
              />
              <div className="flex gap-2">
                <input
                  type="text"
                  name="year"
                  placeholder="Year"
                  value={edu.year}
                  onChange={(e) => handleEducationChange(index, e)}
                  className="border border-gray-300 rounded-md px-3 py-2 flex-1"
                />
                {education.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeEducation(index)}
                    className="text-red-500 text-sm px-2"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          ))}
          <button
            type="button"
            onClick={addEducation}
            className="text-sm text-primary hover:underline"
          >
            + Add Education
          </button>
        </section>

        {/* Experience */}
        <section>
          <h2 className="text-lg font-semibold text-gray-700 mb-3">Work Experience</h2>
          {experience.map((exp, index) => (
            <div key={index} className="border border-gray-200 rounded-md p-3 mb-3">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-2">
                <input
                  type="text"
                  name="role"
                  placeholder="Role"
                  value={exp.role}
                  onChange={(e) => handleExperienceChange(index, e)}
                  className="border border-gray-300 rounded-md px-3 py-2"
                />
                <input
                  type="text"
                  name="company"
                  placeholder="Company"
                  value={exp.company}
                  onChange={(e) => handleExperienceChange(index, e)}
                  className="border border-gray-300 rounded-md px-3 py-2"
                />
                <input
                  type="text"
                  name="duration"
                  placeholder="Duration"
                  value={exp.duration}
                  onChange={(e) => handleExperienceChange(index, e)}
                  className="border border-gray-300 rounded-md px-3 py-2"
                />
              </div>
              <textarea
                name="description"
                rows="2"
                value={exp.description}
                onChange={(e) => handleExperienceChange(index, e)}
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              />
              {experience.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeExperience(index)}
                  className="text-red-500 text-sm mt-2"
                >
                  Remove this experience
                </button>
              )}
            </div>
          ))}
          <button
            type="button"
            onClick={addExperience}
            className="text-sm text-primary hover:underline"
          >
            + Add Experience
          </button>
        </section>

        <button
          type="submit"
          disabled={saving}
          className="w-full bg-primary text-white py-3 rounded-md hover:bg-indigo-700 disabled:opacity-60"
        >
          {saving ? "Saving..." : "Update Resume"}
        </button>

        {saving && <Spinner />}
      </form>
    </div>
  );
};

export default EditResume;
