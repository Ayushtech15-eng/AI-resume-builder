// pages/Dashboard.jsx
// Shows all resumes created by the logged-in user

import { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { getResumes, deleteResume } from "../services/resumeService";
import { AuthContext } from "../context/AuthContext";
import ResumeCard from "../components/ResumeCard";
import Spinner from "../components/Spinner";

const Dashboard = () => {
  const { user } = useContext(AuthContext);
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch resumes when the page loads
  useEffect(() => {
    fetchResumes();
  }, []);

  const fetchResumes = async () => {
    try {
      const data = await getResumes();
      setResumes(data);
    } catch (error) {
      toast.error("Failed to load resumes");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    // Simple confirmation before deleting
    const confirmDelete = window.confirm("Are you sure you want to delete this resume?");
    if (!confirmDelete) return;

    try {
      await deleteResume(id);
      // Remove the deleted resume from state without refetching everything
      setResumes(resumes.filter((resume) => resume._id !== id));
      toast.success("Resume deleted");
    } catch (error) {
      toast.error("Failed to delete resume");
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">
            Welcome, {user?.name} 👋
          </h1>
          <p className="text-gray-500 text-sm">Manage all your resumes here</p>
        </div>
        <Link
          to="/create"
          className="bg-primary text-white px-4 py-2 rounded-md hover:bg-indigo-700"
        >
          + Create Resume
        </Link>
      </div>

      {loading ? (
        <Spinner />
      ) : resumes.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-lg shadow-sm">
          <p className="text-gray-500 mb-4">You haven't created any resumes yet.</p>
          <Link
            to="/create"
            className="bg-primary text-white px-4 py-2 rounded-md hover:bg-indigo-700"
          >
            Create your first resume
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {resumes.map((resume) => (
            <ResumeCard key={resume._id} resume={resume} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
