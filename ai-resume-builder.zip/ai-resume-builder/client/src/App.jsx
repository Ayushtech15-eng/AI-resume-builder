// App.jsx
// This is the main component that sets up routing for the entire app

import { Routes, Route } from "react-router-dom";
import { Link } from "react-router-dom";
import Navbar from "./components/Navbar";
import Toast from "./components/Toast";
import ProtectedRoute from "./components/ProtectedRoute";

// Pages
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import CreateResume from "./pages/CreateResume";
import EditResume from "./pages/EditResume";
import PreviewResume from "./pages/PreviewResume";
import Profile from "./pages/Profile";

// Simple landing/home page
const Home = () => (
  <div className="min-h-[80vh] flex flex-col items-center justify-center text-center px-4">
    <h1 className="text-4xl font-bold text-gray-800 mb-4">
      Build Your Resume with the Power of AI
    </h1>
    <p className="text-gray-500 max-w-lg mb-6">
      Create a professional resume in minutes. Let AI help you write a great
      summary and improve your skills section.
    </p>
    <Link
      to="/signup"
      className="bg-primary text-white px-6 py-3 rounded-md hover:bg-indigo-700"
    >
      Get Started for Free
    </Link>
  </div>
);

function App() {
  return (
    <div>
      <Navbar />
      {/* Toast container so toast.success()/toast.error() work app-wide */}
      <Toast />

      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />

        {/* Protected Routes (only accessible when logged in) */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/create"
          element={
            <ProtectedRoute>
              <CreateResume />
            </ProtectedRoute>
          }
        />
        <Route
          path="/edit/:id"
          element={
            <ProtectedRoute>
              <EditResume />
            </ProtectedRoute>
          }
        />
        <Route
          path="/preview/:id"
          element={
            <ProtectedRoute>
              <PreviewResume />
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default App;
