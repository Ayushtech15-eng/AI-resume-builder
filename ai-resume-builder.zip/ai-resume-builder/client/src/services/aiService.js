// services/aiService.js
// Wraps all API calls related to AI (Gemini) features

import api from "./api";

// Ask AI to generate a professional summary
export const generateSummary = async (jobTitle, skills, experience) => {
  const res = await api.post("/ai/generate-summary", {
    jobTitle,
    skills,
    experience,
  });
  return res.data; // { summary: "..." }
};

// Ask AI to suggest/improve skills
export const improveSkills = async (jobTitle, currentSkills) => {
  const res = await api.post("/ai/improve-skills", {
    jobTitle,
    currentSkills,
  });
  return res.data; // { skills: [...] }
};
