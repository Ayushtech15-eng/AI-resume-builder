// services/resumeService.js
// Wraps all API calls related to resumes (CRUD operations)

import api from "./api";

// Create a new resume
export const createResume = async (resumeData) => {
  const res = await api.post("/resumes", resumeData);
  return res.data;
};

// Get all resumes of the logged-in user
export const getResumes = async () => {
  const res = await api.get("/resumes");
  return res.data;
};

// Get a single resume by its id
export const getResumeById = async (id) => {
  const res = await api.get(`/resumes/${id}`);
  return res.data;
};

// Update an existing resume
export const updateResume = async (id, resumeData) => {
  const res = await api.put(`/resumes/${id}`, resumeData);
  return res.data;
};

// Delete a resume
export const deleteResume = async (id) => {
  const res = await api.delete(`/resumes/${id}`);
  return res.data;
};
