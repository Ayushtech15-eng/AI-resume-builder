// services/api.js
// A central axios instance so we don't repeat the base URL everywhere

import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:5000/api", // backend server URL
});

// Automatically attach the JWT token (if present) to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default api;
