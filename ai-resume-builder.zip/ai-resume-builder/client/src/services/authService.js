// services/authService.js
// Wraps all API calls related to authentication

import api from "./api";

// Signup new user
export const signupUser = async (name, email, password) => {
  const res = await api.post("/auth/signup", { name, email, password });
  return res.data;
};

// Login existing user
export const loginUser = async (email, password) => {
  const res = await api.post("/auth/login", { email, password });
  return res.data;
};

// Get logged-in user profile
export const getProfile = async () => {
  const res = await api.get("/auth/profile");
  return res.data;
};
