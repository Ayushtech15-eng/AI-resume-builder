// components/ResumeCard.jsx
// A small card used on the Dashboard page to display each resume summary

import { Link } from "react-router-dom";

const ResumeCard = ({ resume, onDelete }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-5 flex flex-col justify-between border border-gray-100 hover:shadow-lg transition-shadow">
      <div>
        <h3 className="text-lg font-semibold text-gray-800">
          {resume.fullName}
        </h3>
        <p className="text-sm text-gray-500">{resume.jobTitle || "No job title added"}</p>
        <p className="text-xs text-gray-400 mt-2">
          Last updated: {new Date(resume.updatedAt).toLocaleDateString()}
        </p>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2 mt-4">
        <Link
          to={`/preview/${resume._id}`}
          className="flex-1 text-center bg-primary text-white text-sm py-2 rounded-md hover:bg-indigo-700"
        >
          Preview
        </Link>
        <Link
          to={`/edit/${resume._id}`}
          className="flex-1 text-center bg-gray-100 text-gray-700 text-sm py-2 rounded-md hover:bg-gray-200"
        >
          Edit
        </Link>
        <button
          onClick={() => onDelete(resume._id)}
          className="flex-1 text-center bg-red-50 text-red-600 text-sm py-2 rounded-md hover:bg-red-100"
        >
          Delete
        </button>
      </div>
    </div>
  );
};

export default ResumeCard;
