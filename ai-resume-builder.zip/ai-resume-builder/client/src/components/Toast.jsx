// components/Toast.jsx
// A small wrapper around react-toastify's ToastContainer
// Placed once in App.jsx so toast messages can be shown from anywhere
// using: import { toast } from "react-toastify"; toast.success("message")

import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Toast = () => {
  return <ToastContainer position="top-right" autoClose={2500} />;
};

export default Toast;
