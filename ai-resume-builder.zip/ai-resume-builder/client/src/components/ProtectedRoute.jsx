// components/ProtectedRoute.jsx
// Wraps pages that should only be visible to logged-in users
// If there's no user, it redirects to the login page

import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import Spinner from "./Spinner";

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useContext(AuthContext);

  // While we're checking localStorage for saved login info, show a spinner
  if (loading) {
    return <Spinner />;
  }

  // If not logged in, redirect to login page
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // Otherwise, show the requested page
  return children;
};

export default ProtectedRoute;
