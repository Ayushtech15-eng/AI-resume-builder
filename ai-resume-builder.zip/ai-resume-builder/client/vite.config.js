import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Vite configuration file
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
});
