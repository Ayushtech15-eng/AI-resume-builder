# AI Resume Builder (MERN Stack + Gemini AI)

A simple, beginner-friendly full-stack project where users can sign up, log in,
create resumes, and use Google's Gemini AI to auto-generate a professional
summary and improve their skills section. Resumes can be previewed and
downloaded as PDF.

## Tech Stack
- **Frontend:** React.js (Vite) + Tailwind CSS + React Router + Axios
- **Backend:** Node.js + Express.js
- **Database:** MongoDB + Mongoose
- **Auth:** JWT (JSON Web Tokens)
- **AI:** Google Gemini API (`gemini-1.5-flash`)

## Folder Structure
```
ai-resume-builder/
├── client/                # React frontend
│   ├── src/
│   │   ├── components/    # Reusable UI components (Navbar, Spinner, etc.)
│   │   ├── pages/          # Page-level components (Login, Dashboard, etc.)
│   │   ├── services/       # Axios API calls
│   │   └── context/        # Auth context (global login state)
│   └── .env.example
│
└── server/                # Express backend
    ├── config/            # DB connection
    ├── controllers/       # Business logic
    ├── middleware/        # JWT auth + error handling
    ├── models/            # Mongoose schemas
    ├── routes/            # API routes
    ├── server.js           # Entry point
    └── .env.example
```

## Features
1. User Signup & Login (JWT Authentication)
2. Protected Dashboard
3. Create / Edit / Delete Resume
4. Preview Resume
5. Download Resume as PDF
6. AI-generated Professional Summary (Gemini)
7. AI-improved Skills Section (Gemini)
8. Profile Page
9. Logout
10. Toast notifications + Loading spinners

---

## Setup Instructions

### 1. Prerequisites
- Node.js (v18+ recommended)
- MongoDB installed locally OR a free MongoDB Atlas cluster
- A Google Gemini API key (free from https://aistudio.google.com/app/apikey)

### 2. Backend Setup
```bash
cd server
npm install
```

Create a `.env` file inside `server/` (copy from `.env.example`):
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/ai-resume-builder
JWT_SECRET=this_is_a_super_secret_key_change_it
GEMINI_API_KEY=your_gemini_api_key_here
CLIENT_URL=http://localhost:5173
```

Run the backend:
```bash
npm run dev
```
The server will start at `http://localhost:5000`.

### 3. Frontend Setup
Open a new terminal:
```bash
cd client
npm install
npm run dev
```
The frontend will start at `http://localhost:5173`.

> Note: The frontend's Axios base URL is set in `client/src/services/api.js`
> as `http://localhost:5000/api`. Update it there if your backend runs on a
> different port/URL.

### 4. Using the App
1. Open `http://localhost:5173` in your browser.
2. Sign up for a new account.
3. Go to Dashboard → Create Resume.
4. Fill in your job title, then click **"✨ Generate with AI"** for the
   summary and **"✨ Improve with AI"** for skills.
5. Save the resume, preview it, and download it as a PDF.

---

## API Endpoints (Quick Reference)

### Auth
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | /api/auth/signup | Public | Register new user |
| POST | /api/auth/login | Public | Login user |
| GET | /api/auth/profile | Private | Get logged-in user profile |

### Resumes
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | /api/resumes | Private | Create resume |
| GET | /api/resumes | Private | Get all resumes of user |
| GET | /api/resumes/:id | Private | Get single resume |
| PUT | /api/resumes/:id | Private | Update resume |
| DELETE | /api/resumes/:id | Private | Delete resume |

### AI
| Method | Endpoint | Access | Description |
|--------|-----------|--------|--------------|
| POST | /api/ai/generate-summary | Private | Generate professional summary |
| POST | /api/ai/improve-skills | Private | Suggest/improve skills |

---

## Notes for Students
- Passwords are hashed using `bcryptjs` before saving to the database.
- JWT tokens are stored in `localStorage` on the frontend and sent via the
  `Authorization: Bearer <token>` header on every request.
- The `authMiddleware.js` file protects backend routes — no token, no access.
- `ProtectedRoute.jsx` does the same thing on the frontend — redirects to
  `/login` if the user isn't logged in.
- All AI calls happen on the **backend** so your Gemini API key stays secret
  and is never exposed to the browser.
- This project intentionally avoids Redux, TypeScript, and Docker to keep
  things simple for beginners — plain React state (`useState`/`useContext`)
  is used for state management.

## Possible Improvements (Optional)
- Add multiple resume templates/themes
- Add drag-and-drop reordering for experience/education
- Add forgot password / email verification
- Add pagination on the dashboard
