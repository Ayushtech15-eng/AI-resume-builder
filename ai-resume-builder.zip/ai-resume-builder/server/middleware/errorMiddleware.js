// middleware/errorMiddleware.js
// A simple centralized error handler so we don't repeat try/catch everywhere

// Handles routes that don't exist (404)
export const notFound = (req, res, next) => {
  const error = new Error(`Route not found - ${req.originalUrl}`);
  res.status(404);
  next(error);
};

// Handles any error passed via next(error)
export const errorHandler = (err, req, res, next) => {
  // Sometimes status code is 200 even though there's an error, fix that
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  // Handle invalid MongoDB ObjectId error
  if (err.name === "CastError" && err.kind === "ObjectId") {
    statusCode = 404;
    message = "Resource not found";
  }

  res.status(statusCode).json({
    message,
    // Only show the stack trace during development
    stack: process.env.NODE_ENV === "production" ? null : err.stack,
  });
};
