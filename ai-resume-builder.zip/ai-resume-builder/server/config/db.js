// config/db.js
// This file handles the connection to our MongoDB database using Mongoose

import mongoose from "mongoose";

const connectDB = async () => {
  try {
    // Connect using the URI stored in our .env file
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    // Stop the server if the DB connection fails
    process.exit(1);
  }
};

export default connectDB;
