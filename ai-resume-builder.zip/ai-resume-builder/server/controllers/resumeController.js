// controllers/resumeController.js
// Handles Create, Read, Update, Delete (CRUD) operations for resumes

import Resume from "../models/Resume.js";

// @route   POST /api/resumes
// @desc    Create a new resume
// @access  Private
export const createResume = async (req, res, next) => {
  try {
    const { fullName, email, phone, jobTitle, summary, skills, education, experience } =
      req.body;

    if (!fullName) {
      return res.status(400).json({ message: "Full name is required" });
    }

    const resume = await Resume.create({
      user: req.user._id, // comes from authMiddleware
      fullName,
      email,
      phone,
      jobTitle,
      summary,
      skills,
      education,
      experience,
    });

    res.status(201).json(resume);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/resumes
// @desc    Get all resumes belonging to the logged-in user
// @access  Private
export const getResumes = async (req, res, next) => {
  try {
    // Only fetch resumes that belong to this user, newest first
    const resumes = await Resume.find({ user: req.user._id }).sort({
      createdAt: -1,
    });
    res.status(200).json(resumes);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/resumes/:id
// @desc    Get a single resume by id
// @access  Private
export const getResumeById = async (req, res, next) => {
  try {
    const resume = await Resume.findById(req.params.id);

    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    // Make sure the resume belongs to the logged-in user
    if (resume.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to view this resume" });
    }

    res.status(200).json(resume);
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/resumes/:id
// @desc    Update an existing resume
// @access  Private
export const updateResume = async (req, res, next) => {
  try {
    let resume = await Resume.findById(req.params.id);

    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    if (resume.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to edit this resume" });
    }

    // Update the resume with new data, run validators, return the new version
    resume = await Resume.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    res.status(200).json(resume);
  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/resumes/:id
// @desc    Delete a resume
// @access  Private
export const deleteResume = async (req, res, next) => {
  try {
    const resume = await Resume.findById(req.params.id);

    if (!resume) {
      return res.status(404).json({ message: "Resume not found" });
    }

    if (resume.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to delete this resume" });
    }

    await resume.deleteOne();

    res.status(200).json({ message: "Resume deleted successfully" });
  } catch (error) {
    next(error);
  }
};
