// controllers/aiController.js
// This controller talks to Google's Gemini AI model to help generate
// a professional summary and improve the skills section of a resume

import { GoogleGenerativeAI } from "@google/generative-ai";

// Initialize Gemini using the API key from our .env file
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// @route   POST /api/ai/generate-summary
// @desc    Generate a professional summary using AI
// @access  Private
export const generateSummary = async (req, res, next) => {
  try {
    const { jobTitle, skills, experience } = req.body;

    if (!jobTitle) {
      return res.status(400).json({ message: "Job title is required" });
    }

    // Get the Gemini text generation model
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    // Build a clear prompt for the AI
    const prompt = `Write a short, professional resume summary (3-4 sentences)
for a person applying for the role of "${jobTitle}".
Their skills are: ${skills?.join(", ") || "not specified"}.
Their experience: ${experience || "not specified"}.
Keep it confident, concise, and suitable for a resume. Do not use markdown, just plain text.`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();

    res.status(200).json({ summary: text.trim() });
  } catch (error) {
    console.error("Gemini AI error:", error.message);
    res.status(500).json({ message: "Failed to generate summary using AI" });
  }
};

// @route   POST /api/ai/improve-skills
// @desc    Improve/suggest skills using AI based on job title
// @access  Private
export const improveSkills = async (req, res, next) => {
  try {
    const { jobTitle, currentSkills } = req.body;

    if (!jobTitle) {
      return res.status(400).json({ message: "Job title is required" });
    }

    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

    const prompt = `Suggest 8-10 relevant technical and soft skills for a resume
for someone applying to be a "${jobTitle}".
Current skills already listed: ${currentSkills?.join(", ") || "none"}.
Return ONLY a comma separated list of skills, nothing else. No numbering, no extra text.`;

    const result = await model.generateContent(prompt);
    const text = result.response.text();

    // Convert the comma separated string into a clean array
    const skillsArray = text
      .split(",")
      .map((skill) => skill.trim())
      .filter((skill) => skill.length > 0);

    res.status(200).json({ skills: skillsArray });
  } catch (error) {
    console.error("Gemini AI error:", error.message);
    res.status(500).json({ message: "Failed to improve skills using AI" });
  }
};
