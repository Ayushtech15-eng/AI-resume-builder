// models/Resume.js
// Defines how a "Resume" document looks in MongoDB

import mongoose from "mongoose";

// Sub-schema for education entries
const educationSchema = new mongoose.Schema(
  {
    degree: { type: String, default: "" },
    institution: { type: String, default: "" },
    year: { type: String, default: "" },
  },
  { _id: false }
);

// Sub-schema for work experience entries
const experienceSchema = new mongoose.Schema(
  {
    role: { type: String, default: "" },
    company: { type: String, default: "" },
    duration: { type: String, default: "" },
    description: { type: String, default: "" },
  },
  { _id: false }
);

const resumeSchema = new mongoose.Schema(
  {
    // Link every resume to the user who created it
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    fullName: { type: String, required: true },
    email: { type: String, default: "" },
    phone: { type: String, default: "" },
    jobTitle: { type: String, default: "" },

    // AI-generated or user-written professional summary
    summary: { type: String, default: "" },

    // Comma separated or array of skills
    skills: { type: [String], default: [] },

    education: { type: [educationSchema], default: [] },
    experience: { type: [experienceSchema], default: [] },
  },
  {
    timestamps: true,
  }
);

const Resume = mongoose.model("Resume", resumeSchema);

export default Resume;
