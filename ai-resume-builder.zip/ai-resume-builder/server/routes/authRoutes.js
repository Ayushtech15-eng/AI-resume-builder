// routes/authRoutes.js
// Defines all endpoints related to authentication

import express from "express";
import { signup, login, getProfile } from "../controllers/authController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/signup", signup);
router.post("/login", login);
router.get("/profile", protect, getProfile); // protected route, needs valid token

export default router;
