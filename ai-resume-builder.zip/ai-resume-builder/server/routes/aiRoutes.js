// routes/aiRoutes.js
// Defines endpoints that use Gemini AI to help build the resume

import express from "express";
import { generateSummary, improveSkills } from "../controllers/aiController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect); // only logged-in users can use AI features

router.post("/generate-summary", generateSummary);
router.post("/improve-skills", improveSkills);

export default router;
