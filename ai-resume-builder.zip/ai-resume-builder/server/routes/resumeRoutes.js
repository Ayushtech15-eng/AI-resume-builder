// routes/resumeRoutes.js
// Defines all endpoints related to resumes (CRUD)
// All these routes are protected — user must be logged in

import express from "express";
import {
  createResume,
  getResumes,
  getResumeById,
  updateResume,
  deleteResume,
} from "../controllers/resumeController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// Apply the "protect" middleware to every route in this file
router.use(protect);

router.route("/").post(createResume).get(getResumes);
router.route("/:id").get(getResumeById).put(updateResume).delete(deleteResume);

export default router;
