const { tokenize, uniqueKeywords } = require('./atsService');

/**
 * Computes a simple skills/keyword overlap match score between a resume
 * and a job description. Lightweight alternative to a full ML matching
 * pipeline, swappable later for an embeddings-based approach.
 */
const matchResumeToJob = ({ skills = [], experience = [], education = [] }, jobDescription = '') => {
  const jdKeywords = uniqueKeywords(jobDescription, 30);
  const resumeTokens = new Set([
    ...skills.map((s) => (s.name || s).toLowerCase()),
    ...tokenize(experience.map((e) => `${e.role} ${e.company} ${(e.responsibilities || []).join(' ')}`).join(' ')),
    ...tokenize(education.map((e) => `${e.degree} ${e.branch}`).join(' ')),
  ]);

  const matched = jdKeywords.filter((k) => resumeTokens.has(k));
  const missing = jdKeywords.filter((k) => !resumeTokens.has(k));
  const matchPercentage = jdKeywords.length ? Math.round((matched.length / jdKeywords.length) * 100) : 0;

  return {
    matchPercentage,
    matchedSkills: matched,
    missingSkills: missing,
    verdict:
      matchPercentage >= 75
        ? 'Strong Match'
        : matchPercentage >= 50
        ? 'Moderate Match'
        : 'Weak Match - consider tailoring your resume',
  };
};

module.exports = { matchResumeToJob };
