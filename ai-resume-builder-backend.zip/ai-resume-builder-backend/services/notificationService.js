const Notification = require('../models/Notification');

/**
 * Centralized helper for creating in-app notifications. Kept fire-and-forget
 * (errors are logged, not thrown) so a notification failure never breaks the
 * primary request flow (e.g. resume generation).
 */
const notify = async (userId, type, message, link = null) => {
  try {
    return await Notification.create({ user: userId, type, message, link });
  } catch (err) {
    console.error(`[notificationService] Failed to create notification: ${err.message}`);
    return null;
  }
};

module.exports = { notify };
