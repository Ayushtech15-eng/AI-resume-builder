/**
 * ATS Scoring Service
 * -------------------
 * Computes a 0-100 ATS-readiness score for a resume, optionally weighted
 * against a target job description. Pure, deterministic, no external calls -
 * keeps the ATS Analyzer fast and free to run as often as needed.
 */

const STOPWORDS = new Set([
  'the', 'and', 'a', 'an', 'of', 'to', 'in', 'for', 'with', 'on', 'at', 'by', 'is', 'are',
  'as', 'be', 'or', 'this', 'that', 'will', 'we', 'you', 'your', 'our', 'have', 'has',
  'from', 'it', 'their', 'they', 'team', 'role',
]);

const tokenize = (text = '') =>
  (text.toLowerCase().match(/[a-z0-9+.#]+/g) || []).filter((w) => w.length > 2 && !STOPWORDS.has(w));

const uniqueKeywords = (text, limit = 40) => {
  const counts = {};
  tokenize(text).forEach((w) => (counts[w] = (counts[w] || 0) + 1));
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([w]) => w);
};

/**
 * Builds a flat searchable corpus of resume text from structured resume data.
 */
const buildResumeCorpus = ({ professionalSummary, careerObjective, skills = [], experience = [], projects = [] }) => {
  const parts = [professionalSummary || '', careerObjective || ''];
  skills.forEach((s) => parts.push(s.name || s));
  experience.forEach((e) => {
    parts.push(e.role || '', e.company || '');
    (e.responsibilities || []).forEach((r) => parts.push(r));
    (e.achievements || []).forEach((a) => parts.push(a));
  });
  projects.forEach((p) => {
    parts.push(p.name || '', p.description || '');
    (p.techStack || []).forEach((t) => parts.push(t));
  });
  return parts.join(' ');
};

const analyzeResume = (resumeData, jobDescription = '') => {
  const corpus = buildResumeCorpus(resumeData);
  const corpusTokens = new Set(tokenize(corpus));

  // --- Keyword score (against job description if provided, else general check) ---
  let keywordScore;
  let matchedKeywords = [];
  let missingKeywords = [];

  if (jobDescription && jobDescription.trim().length > 0) {
    const jdKeywords = uniqueKeywords(jobDescription, 25);
    matchedKeywords = jdKeywords.filter((k) => corpusTokens.has(k));
    missingKeywords = jdKeywords.filter((k) => !corpusTokens.has(k));
    keywordScore = jdKeywords.length ? Math.round((matchedKeywords.length / jdKeywords.length) * 100) : 100;
  } else {
    // No JD: reward having a reasonable spread of distinct technical/skill keywords
    const distinctCount = corpusTokens.size;
    keywordScore = Math.min(100, Math.round((distinctCount / 40) * 100));
  }

  // --- Skills score ---
  const skillCount = (resumeData.skills || []).length;
  const skillsScore = Math.min(100, Math.round((skillCount / 8) * 100));

  // --- Experience score (quantified achievements + responsibilities depth) ---
  const experience = resumeData.experience || [];
  const totalBullets = experience.reduce(
    (sum, e) => sum + (e.responsibilities || []).length + (e.achievements || []).length,
    0
  );
  const quantified = experience.reduce((sum, e) => {
    const bullets = [...(e.responsibilities || []), ...(e.achievements || [])];
    return sum + bullets.filter((b) => /\d/.test(b)).length;
  }, 0);
  const experienceScore = experience.length
    ? Math.min(100, Math.round((totalBullets / (experience.length * 3)) * 60 + (quantified / Math.max(totalBullets, 1)) * 40))
    : 30;

  // --- Formatting score (presence of key sections) ---
  const sectionsPresent = [
    Boolean(resumeData.professionalSummary || resumeData.careerObjective),
    (resumeData.education || []).length > 0,
    (resumeData.experience || []).length > 0,
    (resumeData.projects || []).length > 0,
    (resumeData.skills || []).length > 0,
  ].filter(Boolean).length;
  const formattingScore = Math.round((sectionsPresent / 5) * 100);

  // --- Readability score (summary length sanity check) ---
  const summaryWordCount = tokenize(resumeData.professionalSummary || resumeData.careerObjective || '').length;
  const readabilityScore =
    summaryWordCount === 0 ? 40 : summaryWordCount > 12 && summaryWordCount < 90 ? 100 : 65;

  const breakdown = { keywordScore, skillsScore, formattingScore, experienceScore, readabilityScore };

  const score = Math.round(
    keywordScore * 0.3 + skillsScore * 0.2 + formattingScore * 0.2 + experienceScore * 0.2 + readabilityScore * 0.1
  );

  // --- Suggestions ---
  const suggestions = [];
  if (keywordScore < 70) {
    suggestions.push(
      jobDescription
        ? `Add missing keywords from the job description: ${missingKeywords.slice(0, 6).join(', ') || 'n/a'}`
        : 'Add more role-relevant keywords and technologies to your summary, skills, and project sections.'
    );
  }
  if (skillsScore < 70) suggestions.push('List at least 6-8 relevant skills to improve keyword coverage.');
  if (experienceScore < 70)
    suggestions.push('Quantify your achievements with numbers, percentages, or measurable outcomes.');
  if (formattingScore < 100)
    suggestions.push('Make sure your resume includes a summary, education, experience, projects, and skills section.');
  if (readabilityScore < 80)
    suggestions.push('Keep your professional summary between roughly 15-80 words for best readability.');
  if (suggestions.length === 0) suggestions.push('Great job! Your resume is well-optimized for ATS systems.');

  return {
    score,
    matchedKeywords,
    missingKeywords,
    suggestions,
    breakdown,
  };
};

module.exports = { analyzeResume, uniqueKeywords, tokenize };
