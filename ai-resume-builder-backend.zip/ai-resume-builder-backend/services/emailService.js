/**
 * Email Service
 * -------------
 * Sends transactional emails (verification, password reset) via nodemailer.
 * If SMTP credentials are not configured, emails are logged to the console
 * instead of failing the request - useful for local development.
 */
const nodemailer = require('nodemailer');

const isConfigured = Boolean(process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS);

const transporter = isConfigured
  ? nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
    })
  : null;

const sendEmail = async ({ to, subject, html, text }) => {
  if (!isConfigured) {
    console.log(`[emailService] SMTP not configured - logging email instead.\nTo: ${to}\nSubject: ${subject}\n${text || html}`);
    return { delivered: false, logged: true };
  }

  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'noreply@airesumebuilder.com',
    to,
    subject,
    html,
    text,
  });
  return { delivered: true };
};

const sendVerificationEmail = (to, token) =>
  sendEmail({
    to,
    subject: 'Verify your AI Resume Builder account',
    text: `Welcome! Your email verification code is: ${token}. It expires in 24 hours.`,
    html: `<p>Welcome to AI Resume Builder!</p><p>Your verification code is: <b>${token}</b></p><p>This code expires in 24 hours.</p>`,
  });

const sendPasswordResetEmail = (to, token) =>
  sendEmail({
    to,
    subject: 'Reset your AI Resume Builder password',
    text: `Your password reset code is: ${token}. It expires in 1 hour.`,
    html: `<p>You requested a password reset.</p><p>Your reset code is: <b>${token}</b></p><p>This code expires in 1 hour. If you did not request this, you can ignore this email.</p>`,
  });

module.exports = { sendEmail, sendVerificationEmail, sendPasswordResetEmail, isConfigured };
