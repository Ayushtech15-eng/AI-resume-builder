/**
 * PDF Generation Service
 * -----------------------
 * Renders a populated Resume document into a downloadable PDF using pdfkit.
 * No headless browser required, keeping the deployment lightweight.
 */
const PDFDocument = require('pdfkit');

const addSectionTitle = (doc, title) => {
  doc.moveDown(0.6);
  doc.fontSize(13).fillColor('#2563EB').text(title.toUpperCase(), { underline: false });
  doc.moveTo(doc.x, doc.y + 2).lineTo(545, doc.y + 2).strokeColor('#2563EB').stroke();
  doc.moveDown(0.4);
  doc.fillColor('#111111').fontSize(10.5);
};

/**
 * @param {object} resume - a fully populated Resume mongoose document (lean)
 * @param {object} user - the owning user (for name/contact header)
 * @param {object} profile - the owning profile (for contact links)
 * @returns {PDFDocument} a pdfkit document stream - caller pipes it to a response or file
 */
const buildResumePdf = (resume, user, profile = {}) => {
  const doc = new PDFDocument({ margin: 50, size: 'A4' });

  // Header
  doc.fontSize(22).fillColor('#111111').text(user.name || 'Candidate Name', { align: 'left' });
  doc.fontSize(10).fillColor('#444444');
  const contactLine = [
    user.email,
    profile.phone,
    profile.location,
    profile.linkedinUrl,
    profile.githubUrl,
    profile.portfolioUrl,
  ]
    .filter(Boolean)
    .join('  |  ');
  doc.text(contactLine);
  doc.moveTo(50, doc.y + 6).lineTo(545, doc.y + 6).strokeColor('#cccccc').stroke();

  // Summary / Objective
  const summary = resume.professionalSummary || resume.careerObjective;
  if (summary) {
    addSectionTitle(doc, 'Professional Summary');
    doc.text(summary, { align: 'left' });
  }

  // Skills
  if (resume.skills && resume.skills.length) {
    addSectionTitle(doc, 'Skills');
    const skillNames = resume.skills.map((s) => (typeof s === 'string' ? s : s.name)).join('  •  ');
    doc.text(skillNames);
  }

  // Experience
  if (resume.experience && resume.experience.length) {
    addSectionTitle(doc, 'Experience');
    resume.experience.forEach((exp) => {
      doc.fontSize(11).fillColor('#111111').text(`${exp.role || ''} — ${exp.company || ''}`, { continued: false });
      doc.fontSize(9).fillColor('#666666').text(exp.durationText || '');
      doc.fontSize(10.5).fillColor('#111111');
      (exp.responsibilities || []).forEach((r) => doc.text(`•  ${r}`));
      (exp.achievements || []).forEach((a) => doc.text(`•  ${a}`));
      doc.moveDown(0.3);
    });
  }

  // Projects
  if (resume.projects && resume.projects.length) {
    addSectionTitle(doc, 'Projects');
    resume.projects.forEach((p) => {
      doc.fontSize(11).fillColor('#111111').text(p.name || '');
      doc.fontSize(9).fillColor('#666666').text((p.techStack || []).join(', '));
      doc.fontSize(10.5).fillColor('#111111');
      if (p.description) doc.text(p.description);
      (p.bulletPoints || []).forEach((b) => doc.text(`•  ${b}`));
      doc.moveDown(0.3);
    });
  }

  // Education
  if (resume.education && resume.education.length) {
    addSectionTitle(doc, 'Education');
    resume.education.forEach((edu) => {
      doc
        .fontSize(11)
        .fillColor('#111111')
        .text(`${edu.degree || ''}${edu.branch ? ' - ' + edu.branch : ''}, ${edu.university || ''}`);
      const yearRange = `${edu.startYear || ''} - ${edu.isOngoing ? 'Present' : edu.endYear || ''}`;
      const cgpaText = edu.cgpa ? `CGPA: ${edu.cgpa}` : edu.percentage ? `${edu.percentage}%` : '';
      doc.fontSize(9).fillColor('#666666').text([yearRange, cgpaText].filter(Boolean).join('  |  '));
      doc.moveDown(0.2);
    });
  }

  return doc;
};

module.exports = { buildResumePdf };
