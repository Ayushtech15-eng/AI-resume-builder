/**
 * AI Service
 * ----------
 * Thin wrapper around the OpenAI API for every AI-powered feature in the
 * platform (summaries, project descriptions, experience rewrites, skill
 * recommendations, cover letters, ATS suggestions).
 *
 * If OPENAI_API_KEY is not set, every method falls back to a deterministic,
 * template-based generator so the whole API remains fully functional for
 * local development/demo purposes without requiring billing on a key.
 */

let OpenAI;
try {
  OpenAI = require('openai');
} catch (e) {
  OpenAI = null;
}

const hasOpenAI = Boolean(process.env.OPENAI_API_KEY) && OpenAI;
const client = hasOpenAI ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

/**
 * Low level chat completion call. Returns plain text.
 */
const complete = async (systemPrompt, userPrompt, { temperature = 0.7, maxTokens = 500 } = {}) => {
  if (!hasOpenAI) {
    throw new Error('OPENAI_NOT_CONFIGURED');
  }

  const response = await client.chat.completions.create({
    model: MODEL,
    temperature,
    max_tokens: maxTokens,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
  });

  return response.choices[0]?.message?.content?.trim() || '';
};

/**
 * Wraps a generator with a fallback so callers never have to special-case
 * "AI not configured" themselves.
 */
const withFallback = async (aiFn, fallbackFn) => {
  if (!hasOpenAI) return { text: fallbackFn(), source: 'fallback' };
  try {
    const text = await aiFn();
    return { text, source: 'openai' };
  } catch (err) {
    return { text: fallbackFn(), source: 'fallback' };
  }
};

// ---------------------------------------------------------------------------
// Feature-specific generators
// ---------------------------------------------------------------------------

const generateProfessionalSummary = ({ role, yearsOfExperience, skills = [], achievements = [] }) =>
  withFallback(
    () =>
      complete(
        'You are an expert resume writer. Write a concise, ATS-friendly professional summary (3-4 sentences, no first person pronouns, results-oriented).',
        `Role: ${role}\nYears of experience: ${yearsOfExperience}\nKey skills: ${skills.join(', ')}\nNotable achievements: ${achievements.join('; ')}`
      ),
    () =>
      `Results-driven ${role || 'professional'} with ${yearsOfExperience || 'several years'} of experience in ${
        skills.slice(0, 4).join(', ') || 'modern technology stacks'
      }. Proven track record of delivering high-quality solutions and ${
        achievements[0] ? achievements[0].toLowerCase() : 'driving measurable business impact'
      }. Strong collaborator with a focus on scalable, maintainable, and user-centric outcomes.`
  );

const generateCareerObjective = ({ targetRole, skills = [] }) =>
  withFallback(
    () =>
      complete(
        'You are an expert resume writer. Write a single, punchy career objective sentence for a resume, ATS-friendly, no first person pronouns.',
        `Target role: ${targetRole}\nKey skills: ${skills.join(', ')}`
      ),
    () =>
      `Motivated ${targetRole || 'candidate'} seeking to leverage expertise in ${
        skills.slice(0, 3).join(', ') || 'software development'
      } to deliver impactful results within a growth-focused engineering team.`
  );

const enhanceExperienceDescription = ({ company, role, responsibilities = [] }) =>
  withFallback(
    () =>
      complete(
        'You are an expert resume writer. Rewrite the given responsibilities into 3-5 strong, ATS-friendly resume bullet points. Start each with an action verb, quantify impact where plausible, no first person pronouns. Return one bullet per line, no numbering.',
        `Company: ${company}\nRole: ${role}\nRaw responsibilities: ${responsibilities.join('; ')}`
      ),
    () =>
      (responsibilities.length
        ? responsibilities
        : ['Contributed to core product features', 'Collaborated with cross-functional teams']
      )
        .map((r) => `Delivered ${r.toLowerCase()} resulting in improved efficiency and stakeholder satisfaction`)
        .join('\n')
  );

const generateAchievements = ({ company, role }) =>
  withFallback(
    () =>
      complete(
        'You are an expert resume writer. Suggest 2-3 plausible, quantified achievement bullet points for a resume, ATS-friendly, no first person pronouns.',
        `Company: ${company}\nRole: ${role}`
      ),
    () =>
      [
        `Improved team delivery efficiency while serving as ${role || 'a key contributor'} at ${company || 'the organization'}`,
        'Recognized for consistent on-time delivery of high-impact initiatives',
      ].join('\n')
  );

const generateProjectDescription = ({ name, techStack = [], rawDescription }) =>
  withFallback(
    () =>
      complete(
        'You are an expert resume writer. Write a concise, ATS-friendly project description (2-3 sentences) plus 3 resume bullet points. Format as:\nDESCRIPTION: <text>\nBULLETS:\n- bullet 1\n- bullet 2\n- bullet 3',
        `Project: ${name}\nTech stack: ${techStack.join(', ')}\nNotes: ${rawDescription || 'N/A'}`
      ),
    () =>
      `DESCRIPTION: Built ${name || 'a full-stack application'} using ${
        techStack.join(', ') || 'modern web technologies'
      }, focusing on clean architecture and scalable design.\nBULLETS:\n- Designed and implemented core features using ${
        techStack[0] || 'the chosen stack'
      }\n- Integrated ${techStack[1] || 'third-party services'} to extend platform functionality\n- Followed best practices for performance, security, and maintainability`
  );

const generateTechnicalSummary = ({ techStack = [] }) =>
  withFallback(
    () =>
      complete(
        'Summarize the technical scope of a project in one ATS-friendly sentence given its tech stack.',
        `Tech stack: ${techStack.join(', ')}`
      ),
    () => `Engineered using ${techStack.join(', ') || 'a modern technology stack'} following industry best practices.`
  );

const recommendSkills = ({ currentSkills = [], targetRole = '' }) =>
  withFallback(
    () =>
      complete(
        'You are a career advisor. Given a target role and current skills, list 5-8 additional in-demand, relevant skills the candidate should add to their resume. Return a comma-separated list only, no explanations.',
        `Target role: ${targetRole}\nCurrent skills: ${currentSkills.join(', ')}`
      ),
    () => {
      const pool = ['TypeScript', 'Docker', 'AWS', 'CI/CD', 'GraphQL', 'Redis', 'Kubernetes', 'Testing (Jest)', 'System Design', 'REST APIs'];
      const missing = pool.filter((s) => !currentSkills.includes(s));
      return missing.slice(0, 6).join(', ');
    }
  );

const generateCoverLetter = ({ candidateName, jobTitle, companyName, jobDescription, summary, skills = [] }) =>
  withFallback(
    () =>
      complete(
        'You are an expert career coach. Write a professional, personalized cover letter (3-4 short paragraphs) for the candidate applying to the given role. Keep it concise and ATS-friendly. Sign off with the candidate name.',
        `Candidate: ${candidateName}\nJob title: ${jobTitle}\nCompany: ${companyName}\nJob description: ${jobDescription || 'N/A'}\nCandidate summary: ${summary || 'N/A'}\nKey skills: ${skills.join(', ')}`
      ),
    () =>
      `Dear Hiring Manager,\n\nI am writing to express my interest in the ${jobTitle} position at ${companyName}. With a strong background in ${
        skills.slice(0, 3).join(', ') || 'relevant technologies'
      }, I am confident in my ability to contribute meaningfully to your team.\n\n${
        summary || 'Throughout my career, I have focused on delivering high-quality, scalable solutions while collaborating effectively across teams.'
      }\n\nI would welcome the opportunity to discuss how my background aligns with the goals of ${companyName}. Thank you for your time and consideration.\n\nSincerely,\n${candidateName}`
  );

const reviewResume = ({ resumeText }) =>
  withFallback(
    () =>
      complete(
        'You are a senior recruiter. Provide concise, actionable feedback (4-6 bullet points) on the resume content provided, covering clarity, impact, and ATS friendliness.',
        resumeText
      ),
    () =>
      [
        'Add quantifiable metrics (%, $, time saved) to strengthen impact statements.',
        'Ensure each bullet point starts with a strong action verb.',
        'Make sure key skills from target job postings appear in the Skills section.',
        'Keep the professional summary to 3-4 sentences max for readability.',
        'Double-check consistent date formatting across Education and Experience.',
      ].join('\n'),
  );

module.exports = {
  isConfigured: hasOpenAI,
  generateProfessionalSummary,
  generateCareerObjective,
  enhanceExperienceDescription,
  generateAchievements,
  generateProjectDescription,
  generateTechnicalSummary,
  recommendSkills,
  generateCoverLetter,
  reviewResume,
};
