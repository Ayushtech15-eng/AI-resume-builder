/**
 * Creates (or promotes) an admin user from ADMIN_* env vars.
 * Run with: npm run seed:admin
 */
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Profile = require('../models/Profile');
const Subscription = require('../models/Subscription');

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for seeding admin...');

    const email = (process.env.ADMIN_EMAIL || 'admin@airesumebuilder.com').toLowerCase();
    let user = await User.findOne({ email });

    if (user) {
      user.role = 'admin';
      await user.save();
      console.log(`Existing user ${email} promoted to admin.`);
    } else {
      user = await User.create({
        name: process.env.ADMIN_NAME || 'Platform Admin',
        email,
        password: process.env.ADMIN_PASSWORD || 'ChangeMe123!',
        role: 'admin',
        isEmailVerified: true,
      });
      await Profile.create({ user: user._id });
      await Subscription.create({ user: user._id, plan: 'premium', status: 'active' });
      console.log(`Admin user created: ${email}`);
    }

    process.exit(0);
  } catch (err) {
    console.error('Admin seeding failed:', err.message);
    process.exit(1);
  }
})();
