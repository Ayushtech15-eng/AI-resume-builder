/**
 * Seeds the default resume templates referenced in Module 9 (Modern,
 * Professional, Corporate, Creative, Minimal). Run with: npm run seed:templates
 */
require('dotenv').config();
const mongoose = require('mongoose');
const Template = require('../models/Template');

const templates = [
  { name: 'Modern Edge', type: 'Modern', description: 'Clean two-column layout with bold section headers.', accentColor: '#2563EB', isPremium: false },
  { name: 'Professional Classic', type: 'Professional', description: 'Traditional single-column ATS-safe layout.', accentColor: '#111827', isPremium: false },
  { name: 'Corporate Suite', type: 'Corporate', description: 'Formal layout suited for finance and consulting roles.', accentColor: '#1E3A8A', isPremium: true },
  { name: 'Creative Spark', type: 'Creative', description: 'Accent sidebar with subtle color highlights for design/marketing roles.', accentColor: '#DB2777', isPremium: true },
  { name: 'Minimal Focus', type: 'Minimal', description: 'Maximum whitespace, typography-first, fully ATS-safe.', accentColor: '#374151', isPremium: false },
];

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for seeding templates...');

    for (const t of templates) {
      await Template.findOneAndUpdate({ name: t.name }, t, { upsert: true, new: true });
      console.log(`Upserted template: ${t.name}`);
    }

    console.log('Template seeding complete.');
    process.exit(0);
  } catch (err) {
    console.error('Seeding failed:', err.message);
    process.exit(1);
  }
})();
