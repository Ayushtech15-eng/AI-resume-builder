const asyncHandler = require('express-async-handler');
const Experience = require('../models/Experience');
const aiService = require('../services/aiService');

// @route GET /api/experience
const getExperience = asyncHandler(async (req, res) => {
  const records = await Experience.find({ user: req.user._id }).sort({ startDate: -1, createdAt: -1 });
  res.json({ success: true, count: records.length, experience: records });
});

// @route POST /api/experience
const createExperience = asyncHandler(async (req, res) => {
  const { company, role, startDate, endDate, isCurrent, durationText, responsibilities, achievements } = req.body;

  if (!company || !role) {
    res.status(400);
    throw new Error('company and role are required');
  }

  const record = await Experience.create({
    user: req.user._id,
    company,
    role,
    startDate,
    endDate,
    isCurrent,
    durationText,
    responsibilities,
    achievements,
  });

  res.status(201).json({ success: true, experience: record });
});

// @route PUT /api/experience/:id
const updateExperience = asyncHandler(async (req, res) => {
  const record = await Experience.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Experience record not found');
  }

  Object.assign(record, req.body);
  await record.save();

  res.json({ success: true, experience: record });
});

// @route DELETE /api/experience/:id
const deleteExperience = asyncHandler(async (req, res) => {
  const record = await Experience.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Experience record not found');
  }
  res.json({ success: true, message: 'Experience record deleted' });
});

// @route POST /api/experience/:id/ai-enhance
// AI Feature: "Improve Experience Description" / "Rewrite Responsibilities"
const enhanceExperience = asyncHandler(async (req, res) => {
  const record = await Experience.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Experience record not found');
  }

  const { text, source } = await aiService.enhanceExperienceDescription({
    company: record.company,
    role: record.role,
    responsibilities: record.responsibilities,
  });

  const bullets = text.split('\n').map((b) => b.replace(/^[-•\d.\s]+/, '').trim()).filter(Boolean);
  record.responsibilities = bullets;
  record.aiEnhanced = true;
  await record.save();

  res.json({ success: true, experience: record, aiSource: source });
});

// @route POST /api/experience/:id/ai-achievements
// AI Feature: "Generate Achievements"
const generateAchievementsForExperience = asyncHandler(async (req, res) => {
  const record = await Experience.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Experience record not found');
  }

  const { text, source } = await aiService.generateAchievements({ company: record.company, role: record.role });
  const bullets = text.split('\n').map((b) => b.replace(/^[-•\d.\s]+/, '').trim()).filter(Boolean);
  record.achievements = [...new Set([...(record.achievements || []), ...bullets])];
  await record.save();

  res.json({ success: true, experience: record, aiSource: source });
});

module.exports = {
  getExperience,
  createExperience,
  updateExperience,
  deleteExperience,
  enhanceExperience,
  generateAchievementsForExperience,
};
