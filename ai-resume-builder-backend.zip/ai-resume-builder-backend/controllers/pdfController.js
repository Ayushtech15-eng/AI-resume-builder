const asyncHandler = require('express-async-handler');
const Resume = require('../models/Resume');
const Profile = require('../models/Profile');
const { buildResumePdf } = require('../services/pdfService');

// @route GET /api/pdf/resume/:resumeId
// Module 14: Resume PDF Generator
const downloadResumePdf = asyncHandler(async (req, res) => {
  const resume = await Resume.findOne({ _id: req.params.resumeId, user: req.user._id }).populate([
    'education',
    'experience',
    'projects',
    'skills',
  ]);
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }

  const profile = await Profile.findOne({ user: req.user._id });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="${resume.title.replace(/[^a-z0-9]/gi, '_')}.pdf"`);

  const doc = buildResumePdf(resume.toObject(), req.user.toSafeObject(), profile ? profile.toObject() : {});
  doc.pipe(res);
  doc.end();
});

module.exports = { downloadResumePdf };
