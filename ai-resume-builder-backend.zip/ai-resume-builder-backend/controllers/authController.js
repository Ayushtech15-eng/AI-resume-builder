const crypto = require('crypto');
const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const Profile = require('../models/Profile');
const Subscription = require('../models/Subscription');
const generateToken = require('../utils/generateToken');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../services/emailService');

const sendTokenResponse = (user, statusCode, res) => {
  const token = generateToken(user._id, user.role);

  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    expires: new Date(Date.now() + (Number(process.env.JWT_COOKIE_EXPIRES_DAYS) || 7) * 24 * 60 * 60 * 1000),
  };

  res.cookie('token', token, cookieOptions);
  res.status(statusCode).json({
    success: true,
    token,
    user: user.toSafeObject(),
  });
};

// @route POST /api/auth/register
const register = asyncHandler(async (req, res) => {
  const { name, email, password, role } = req.body;

  if (!name || !email || !password) {
    res.status(400);
    throw new Error('Name, email, and password are required');
  }

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) {
    res.status(400);
    throw new Error('An account with this email already exists');
  }

  const verificationToken = crypto.randomInt(100000, 999999).toString();

  const user = await User.create({
    name,
    email,
    password,
    role: ['jobseeker', 'recruiter'].includes(role) ? role : 'jobseeker',
    emailVerificationToken: verificationToken,
    emailVerificationExpire: Date.now() + 24 * 60 * 60 * 1000,
  });

  // Bootstrap related docs so the rest of the API has somewhere to write to
  await Profile.create({ user: user._id });
  await Subscription.create({ user: user._id });

  await sendVerificationEmail(user.email, verificationToken);

  sendTokenResponse(user, 201, res);
});

// @route POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    res.status(400);
    throw new Error('Email and password are required');
  }

  const user = await User.findOne({ email: email.toLowerCase() }).select('+password');
  if (!user || !(await user.matchPassword(password))) {
    res.status(401);
    throw new Error('Invalid email or password');
  }

  if (!user.isActive) {
    res.status(403);
    throw new Error('This account has been deactivated. Contact support.');
  }

  user.lastLoginAt = new Date();
  await user.save();

  sendTokenResponse(user, 200, res);
});

// @route POST /api/auth/google
// Lightweight placeholder for Google OAuth - expects a pre-verified payload
// from the frontend's Google Sign-In flow (googleId, email, name).
const googleLogin = asyncHandler(async (req, res) => {
  const { googleId, email, name } = req.body;
  if (!googleId || !email) {
    res.status(400);
    throw new Error('googleId and email are required');
  }

  let user = await User.findOne({ $or: [{ googleId }, { email: email.toLowerCase() }] });

  if (!user) {
    user = await User.create({ name: name || email.split('@')[0], email, googleId, isEmailVerified: true });
    await Profile.create({ user: user._id });
    await Subscription.create({ user: user._id });
  } else if (!user.googleId) {
    user.googleId = googleId;
    user.isEmailVerified = true;
    await user.save();
  }

  user.lastLoginAt = new Date();
  await user.save();

  sendTokenResponse(user, 200, res);
});

// @route GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  res.json({ success: true, user: req.user.toSafeObject() });
});

// @route POST /api/auth/logout
const logout = asyncHandler(async (req, res) => {
  res.clearCookie('token');
  res.json({ success: true, message: 'Logged out successfully' });
});

// @route POST /api/auth/verify-email
const verifyEmail = asyncHandler(async (req, res) => {
  const { email, token } = req.body;
  const user = await User.findOne({ email: email?.toLowerCase() }).select(
    '+emailVerificationToken +emailVerificationExpire'
  );

  if (!user || user.emailVerificationToken !== token || user.emailVerificationExpire < Date.now()) {
    res.status(400);
    throw new Error('Invalid or expired verification code');
  }

  user.isEmailVerified = true;
  user.emailVerificationToken = undefined;
  user.emailVerificationExpire = undefined;
  await user.save();

  res.json({ success: true, message: 'Email verified successfully' });
});

// @route POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email: email?.toLowerCase() });

  // Always respond success to avoid leaking which emails are registered
  if (!user) {
    return res.json({ success: true, message: 'If that email exists, a reset code has been sent.' });
  }

  const resetToken = crypto.randomInt(100000, 999999).toString();
  user.passwordResetToken = resetToken;
  user.passwordResetExpire = Date.now() + 60 * 60 * 1000;
  await user.save();

  await sendPasswordResetEmail(user.email, resetToken);

  res.json({ success: true, message: 'If that email exists, a reset code has been sent.' });
});

// @route POST /api/auth/reset-password
const resetPassword = asyncHandler(async (req, res) => {
  const { email, token, newPassword } = req.body;

  if (!newPassword || newPassword.length < 6) {
    res.status(400);
    throw new Error('New password must be at least 6 characters');
  }

  const user = await User.findOne({ email: email?.toLowerCase() }).select(
    '+passwordResetToken +passwordResetExpire'
  );

  if (!user || user.passwordResetToken !== token || user.passwordResetExpire < Date.now()) {
    res.status(400);
    throw new Error('Invalid or expired reset code');
  }

  user.password = newPassword;
  user.passwordResetToken = undefined;
  user.passwordResetExpire = undefined;
  await user.save();

  res.json({ success: true, message: 'Password reset successfully. You can now log in.' });
});

// @route PUT /api/auth/change-password
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = await User.findById(req.user._id).select('+password');

  if (!(await user.matchPassword(currentPassword))) {
    res.status(401);
    throw new Error('Current password is incorrect');
  }

  if (!newPassword || newPassword.length < 6) {
    res.status(400);
    throw new Error('New password must be at least 6 characters');
  }

  user.password = newPassword;
  await user.save();

  res.json({ success: true, message: 'Password changed successfully' });
});

module.exports = {
  register,
  login,
  googleLogin,
  getMe,
  logout,
  verifyEmail,
  forgotPassword,
  resetPassword,
  changePassword,
};
