const asyncHandler = require('express-async-handler');
const Template = require('../models/Template');

// @route GET /api/templates
const getTemplates = asyncHandler(async (req, res) => {
  const filter = { isActive: true };
  if (req.query.type) filter.type = req.query.type;

  const templates = await Template.find(filter).sort({ usageCount: -1, name: 1 });
  res.json({ success: true, count: templates.length, templates });
});

// @route GET /api/templates/:id
const getTemplateById = asyncHandler(async (req, res) => {
  const template = await Template.findById(req.params.id);
  if (!template) {
    res.status(404);
    throw new Error('Template not found');
  }
  res.json({ success: true, template });
});

// @route POST /api/templates  (admin only)
const createTemplate = asyncHandler(async (req, res) => {
  const { name, type, description, previewImageUrl, isPremium, accentColor } = req.body;
  if (!name || !type) {
    res.status(400);
    throw new Error('name and type are required');
  }
  const template = await Template.create({ name, type, description, previewImageUrl, isPremium, accentColor });
  res.status(201).json({ success: true, template });
});

// @route PUT /api/templates/:id  (admin only)
const updateTemplate = asyncHandler(async (req, res) => {
  const template = await Template.findById(req.params.id);
  if (!template) {
    res.status(404);
    throw new Error('Template not found');
  }
  Object.assign(template, req.body);
  await template.save();
  res.json({ success: true, template });
});

// @route DELETE /api/templates/:id  (admin only)
const deleteTemplate = asyncHandler(async (req, res) => {
  const template = await Template.findByIdAndDelete(req.params.id);
  if (!template) {
    res.status(404);
    throw new Error('Template not found');
  }
  res.json({ success: true, message: 'Template deleted' });
});

module.exports = { getTemplates, getTemplateById, createTemplate, updateTemplate, deleteTemplate };
