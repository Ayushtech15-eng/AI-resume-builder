const asyncHandler = require('express-async-handler');
const Subscription = require('../models/Subscription');
const { getOrCreateSubscription } = require('../middleware/subscriptionGuard');

// @route GET /api/subscriptions/me
const getMySubscription = asyncHandler(async (req, res) => {
  const sub = await getOrCreateSubscription(req.user._id);
  sub.refreshUsageWindowIfNeeded();
  await sub.save();
  res.json({ success: true, subscription: sub });
});

// @route POST /api/subscriptions/upgrade
// Simplified upgrade flow. In production this would only run after a verified
// Razorpay/Stripe webhook confirms payment - paymentRef is passed through here
// as a placeholder for that confirmation id.
const upgradeToPremium = asyncHandler(async (req, res) => {
  const { paymentRef, months } = req.body;
  if (!paymentRef) {
    res.status(400);
    throw new Error('paymentRef is required (payment gateway confirmation reference)');
  }

  const sub = await getOrCreateSubscription(req.user._id);
  sub.plan = 'premium';
  sub.status = 'active';
  sub.startDate = new Date();
  sub.endDate = new Date(Date.now() + (Number(months) || 1) * 30 * 24 * 60 * 60 * 1000);
  sub.paymentRef = paymentRef;
  // resumeLimit/aiUsageLimit are ignored entirely while isPremiumActive() is
  // true (see middleware/subscriptionGuard.js), so no need to mutate them.
  await sub.save();

  res.json({ success: true, subscription: sub, message: 'Upgraded to Premium successfully' });
});

// @route POST /api/subscriptions/cancel
const cancelSubscription = asyncHandler(async (req, res) => {
  const sub = await getOrCreateSubscription(req.user._id);
  sub.status = 'cancelled';
  await sub.save();
  res.json({ success: true, subscription: sub, message: 'Subscription cancelled' });
});

module.exports = { getMySubscription, upgradeToPremium, cancelSubscription };
