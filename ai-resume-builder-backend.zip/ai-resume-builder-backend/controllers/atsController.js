const asyncHandler = require('express-async-handler');
const Resume = require('../models/Resume');
const AtsReport = require('../models/AtsReport');
const atsService = require('../services/atsService');
const aiService = require('../services/aiService');
const { notify } = require('../services/notificationService');

// @route POST /api/ats/analyze/:resumeId
// Module 8: ATS Resume Analyzer. Accepts an optional jobDescription in the body
// to score keyword match against a specific job posting.
const analyzeResume = asyncHandler(async (req, res) => {
  const resume = await Resume.findOne({ _id: req.params.resumeId, user: req.user._id }).populate([
    'education',
    'experience',
    'projects',
    'skills',
  ]);
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }

  const { jobDescription } = req.body;
  const result = atsService.analyzeResume(resume.toObject(), jobDescription);

  // Layer an AI-written suggestion on top of the deterministic ones when available
  let aiSource = 'fallback';
  if (aiService.isConfigured) {
    const resumeText = [resume.professionalSummary, resume.careerObjective].filter(Boolean).join('\n');
    const aiFeedback = await aiService.reviewResume({ resumeText: resumeText || resume.title });
    result.suggestions.push(...aiFeedback.text.split('\n').filter(Boolean));
    aiSource = aiFeedback.source;
  }

  const report = await AtsReport.create({
    resume: resume._id,
    user: req.user._id,
    jobDescription,
    score: result.score,
    matchedKeywords: result.matchedKeywords,
    missingKeywords: result.missingKeywords,
    suggestions: result.suggestions,
    breakdown: result.breakdown,
  });

  resume.lastAtsScore = result.score;
  await resume.save();

  await notify(
    req.user._id,
    'ats_analysis_complete',
    `ATS analysis complete for "${resume.title}" - score: ${result.score}/100`,
    `/resumes/${resume._id}/ats`
  );

  res.json({ success: true, report, aiSource });
});

// @route GET /api/ats/reports/:resumeId
const getReportsForResume = asyncHandler(async (req, res) => {
  const reports = await AtsReport.find({ resume: req.params.resumeId, user: req.user._id }).sort({ createdAt: -1 });
  res.json({ success: true, count: reports.length, reports });
});

// @route GET /api/ats/reports
const getAllReports = asyncHandler(async (req, res) => {
  const reports = await AtsReport.find({ user: req.user._id }).sort({ createdAt: -1 }).populate('resume', 'title');
  res.json({ success: true, count: reports.length, reports });
});

module.exports = { analyzeResume, getReportsForResume, getAllReports };
