const asyncHandler = require('express-async-handler');
const User = require('../models/User');
const Resume = require('../models/Resume');
const AtsReport = require('../models/AtsReport');
const Subscription = require('../models/Subscription');
const CoverLetter = require('../models/CoverLetter');
const Template = require('../models/Template');

// @route GET /api/admin/users
const getUsers = asyncHandler(async (req, res) => {
  const { role, search, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (role) filter.role = role;
  if (search) filter.$or = [{ name: new RegExp(search, 'i') }, { email: new RegExp(search, 'i') }];

  const skip = (Number(page) - 1) * Number(limit);
  const [users, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    User.countDocuments(filter),
  ]);

  res.json({ success: true, total, page: Number(page), pages: Math.ceil(total / limit), users });
});

// @route PUT /api/admin/users/:id/role
const updateUserRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  if (!['jobseeker', 'recruiter', 'admin'].includes(role)) {
    res.status(400);
    throw new Error('Invalid role');
  }
  const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true });
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  res.json({ success: true, user: user.toSafeObject() });
});

// @route PUT /api/admin/users/:id/deactivate
const toggleUserActive = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }
  user.isActive = !user.isActive;
  await user.save();
  res.json({ success: true, user: user.toSafeObject() });
});

// @route GET /api/admin/analytics
// Module 16: Admin Analytics (Total Users, Resumes Generated, Premium Users, Revenue proxy)
const getAnalytics = asyncHandler(async (req, res) => {
  const [totalUsers, totalResumes, totalAtsReports, totalCoverLetters, premiumUsers, usersByRole, templateUsage] =
    await Promise.all([
      User.countDocuments(),
      Resume.countDocuments(),
      AtsReport.countDocuments(),
      CoverLetter.countDocuments(),
      Subscription.countDocuments({ plan: 'premium', status: 'active' }),
      User.aggregate([{ $group: { _id: '$role', count: { $sum: 1 } } }]),
      Template.find().sort({ usageCount: -1 }).limit(5).select('name usageCount'),
    ]);

  const avgAtsScoreAgg = await AtsReport.aggregate([{ $group: { _id: null, avgScore: { $avg: '$score' } } }]);

  res.json({
    success: true,
    analytics: {
      totalUsers,
      totalResumes,
      totalAtsReportsGenerated: totalAtsReports,
      totalCoverLettersGenerated: totalCoverLetters,
      premiumUsers,
      usersByRole,
      averageAtsScore: avgAtsScoreAgg[0]?.avgScore ? Math.round(avgAtsScoreAgg[0].avgScore) : null,
      mostPopularTemplates: templateUsage,
    },
  });
});

module.exports = { getUsers, updateUserRole, toggleUserActive, getAnalytics };
