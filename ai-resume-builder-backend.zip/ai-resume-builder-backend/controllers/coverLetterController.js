const asyncHandler = require('express-async-handler');
const CoverLetter = require('../models/CoverLetter');
const Resume = require('../models/Resume');
const Profile = require('../models/Profile');
const Skill = require('../models/Skill');
const aiService = require('../services/aiService');
const { notify } = require('../services/notificationService');

// @route POST /api/cover-letters/generate
// Module 11: Cover Letter Generator
const generateCoverLetter = asyncHandler(async (req, res) => {
  const { jobTitle, companyName, jobDescription, resumeId } = req.body;
  if (!jobTitle || !companyName) {
    res.status(400);
    throw new Error('jobTitle and companyName are required');
  }

  const [profile, skills, resume] = await Promise.all([
    Profile.findOne({ user: req.user._id }),
    Skill.find({ user: req.user._id }),
    resumeId ? Resume.findOne({ _id: resumeId, user: req.user._id }) : null,
  ]);

  const { text, source } = await aiService.generateCoverLetter({
    candidateName: req.user.name,
    jobTitle,
    companyName,
    jobDescription,
    summary: resume?.professionalSummary || profile?.professionalSummary,
    skills: skills.map((s) => s.name),
  });

  const coverLetter = await CoverLetter.create({
    user: req.user._id,
    resume: resume?._id,
    jobTitle,
    companyName,
    jobDescription,
    content: text,
  });

  await notify(req.user._id, 'cover_letter_generated', `Cover letter generated for ${jobTitle} at ${companyName}.`);

  res.status(201).json({ success: true, coverLetter, aiSource: source });
});

// @route GET /api/cover-letters
const getCoverLetters = asyncHandler(async (req, res) => {
  const letters = await CoverLetter.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json({ success: true, count: letters.length, coverLetters: letters });
});

// @route GET /api/cover-letters/:id
const getCoverLetterById = asyncHandler(async (req, res) => {
  const letter = await CoverLetter.findOne({ _id: req.params.id, user: req.user._id });
  if (!letter) {
    res.status(404);
    throw new Error('Cover letter not found');
  }
  res.json({ success: true, coverLetter: letter });
});

// @route PUT /api/cover-letters/:id
const updateCoverLetter = asyncHandler(async (req, res) => {
  const letter = await CoverLetter.findOne({ _id: req.params.id, user: req.user._id });
  if (!letter) {
    res.status(404);
    throw new Error('Cover letter not found');
  }
  if (req.body.content !== undefined) letter.content = req.body.content;
  await letter.save();
  res.json({ success: true, coverLetter: letter });
});

// @route DELETE /api/cover-letters/:id
const deleteCoverLetter = asyncHandler(async (req, res) => {
  const letter = await CoverLetter.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!letter) {
    res.status(404);
    throw new Error('Cover letter not found');
  }
  res.json({ success: true, message: 'Cover letter deleted' });
});

module.exports = { generateCoverLetter, getCoverLetters, getCoverLetterById, updateCoverLetter, deleteCoverLetter };
