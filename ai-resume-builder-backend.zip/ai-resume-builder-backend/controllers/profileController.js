const asyncHandler = require('express-async-handler');
const Profile = require('../models/Profile');

// @route GET /api/profile
const getProfile = asyncHandler(async (req, res) => {
  let profile = await Profile.findOne({ user: req.user._id });
  if (!profile) {
    profile = await Profile.create({ user: req.user._id });
  }
  res.json({ success: true, profile });
});

// @route PUT /api/profile
const updateProfile = asyncHandler(async (req, res) => {
  const allowedFields = [
    'phone',
    'address',
    'location',
    'linkedinUrl',
    'githubUrl',
    'portfolioUrl',
    'careerObjective',
    'professionalSummary',
    'profileImageUrl',
  ];

  let profile = await Profile.findOne({ user: req.user._id });
  if (!profile) {
    profile = new Profile({ user: req.user._id });
  }

  allowedFields.forEach((field) => {
    if (req.body[field] !== undefined) profile[field] = req.body[field];
  });

  profile.computeCompleteness();
  await profile.save();

  res.json({ success: true, profile });
});

module.exports = { getProfile, updateProfile };
