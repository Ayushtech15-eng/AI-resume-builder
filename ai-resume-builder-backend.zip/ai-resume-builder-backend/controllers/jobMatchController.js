const asyncHandler = require('express-async-handler');
const Resume = require('../models/Resume');
const { matchResumeToJob } = require('../services/jobMatchService');
const { notify } = require('../services/notificationService');

// @route POST /api/job-match/:resumeId
// Module 12: Job Matching Engine
const matchJob = asyncHandler(async (req, res) => {
  const { jobDescription } = req.body;
  if (!jobDescription) {
    res.status(400);
    throw new Error('jobDescription is required');
  }

  const resume = await Resume.findOne({ _id: req.params.resumeId, user: req.user._id }).populate([
    'skills',
    'experience',
    'education',
  ]);
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }

  const result = matchResumeToJob(resume.toObject(), jobDescription);

  if (result.matchPercentage >= 75) {
    await notify(req.user._id, 'job_match_found', `Strong job match found (${result.matchPercentage}%) for "${resume.title}".`);
  }

  res.json({ success: true, resumeId: resume._id, ...result });
});

module.exports = { matchJob };
