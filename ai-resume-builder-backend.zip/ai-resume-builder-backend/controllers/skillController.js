const asyncHandler = require('express-async-handler');
const Skill = require('../models/Skill');
const { SKILL_CATEGORIES } = require('../models/Skill');
const aiService = require('../services/aiService');

// @route GET /api/skills
const getSkills = asyncHandler(async (req, res) => {
  const records = await Skill.find({ user: req.user._id }).sort({ category: 1, name: 1 });
  res.json({ success: true, count: records.length, categories: SKILL_CATEGORIES, skills: records });
});

// @route POST /api/skills
const createSkill = asyncHandler(async (req, res) => {
  const { name, category, proficiency } = req.body;
  if (!name) {
    res.status(400);
    throw new Error('Skill name is required');
  }

  const existing = await Skill.findOne({ user: req.user._id, name: name.trim() });
  if (existing) {
    res.status(400);
    throw new Error('This skill is already in your list');
  }

  const record = await Skill.create({ user: req.user._id, name: name.trim(), category, proficiency });
  res.status(201).json({ success: true, skill: record });
});

// @route POST /api/skills/bulk
const createSkillsBulk = asyncHandler(async (req, res) => {
  const { skills } = req.body; // array of { name, category?, proficiency? }
  if (!Array.isArray(skills) || skills.length === 0) {
    res.status(400);
    throw new Error('skills must be a non-empty array');
  }

  const existingNames = new Set((await Skill.find({ user: req.user._id }).select('name')).map((s) => s.name));
  const toInsert = skills
    .filter((s) => s && s.name && !existingNames.has(s.name.trim()))
    .map((s) => ({ user: req.user._id, name: s.name.trim(), category: s.category, proficiency: s.proficiency }));

  const inserted = toInsert.length ? await Skill.insertMany(toInsert) : [];
  res.status(201).json({ success: true, inserted: inserted.length, skills: inserted });
});

// @route DELETE /api/skills/:id
const deleteSkill = asyncHandler(async (req, res) => {
  const record = await Skill.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Skill not found');
  }
  res.json({ success: true, message: 'Skill deleted' });
});

// @route POST /api/skills/ai-recommend
// AI Feature: "Skill Recommendations" / "Industry Skill Suggestions"
const recommendSkills = asyncHandler(async (req, res) => {
  const { targetRole } = req.body;
  const currentSkills = (await Skill.find({ user: req.user._id }).select('name')).map((s) => s.name);

  const { text, source } = await aiService.recommendSkills({ currentSkills, targetRole: targetRole || '' });
  const recommended = text
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .filter((s) => !currentSkills.includes(s));

  res.json({ success: true, currentSkills, recommendedSkills: recommended, aiSource: source });
});

// @route GET /api/skills/gap-analysis
// AI Feature: "Skill Gap Analysis" (vs a target role - simple heuristic + AI suggestion list)
const skillGapAnalysis = asyncHandler(async (req, res) => {
  const { targetRole } = req.query;
  const currentSkills = (await Skill.find({ user: req.user._id }).select('name category')).map((s) => s.name);

  const { text, source } = await aiService.recommendSkills({ currentSkills, targetRole: targetRole || 'Software Engineer' });
  const gaps = text.split(',').map((s) => s.trim()).filter(Boolean);

  res.json({
    success: true,
    targetRole: targetRole || 'Software Engineer',
    currentSkillCount: currentSkills.length,
    suggestedGaps: gaps,
    aiSource: source,
  });
});

module.exports = { getSkills, createSkill, createSkillsBulk, deleteSkill, recommendSkills, skillGapAnalysis };
