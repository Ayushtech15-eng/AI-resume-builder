const asyncHandler = require('express-async-handler');
const Resume = require('../models/Resume');
const Profile = require('../models/Profile');
const Education = require('../models/Education');
const Experience = require('../models/Experience');
const Project = require('../models/Project');
const Skill = require('../models/Skill');
const Template = require('../models/Template');
const aiService = require('../services/aiService');
const { notify } = require('../services/notificationService');

const POPULATE = ['education', 'experience', 'projects', 'skills', 'template'];

// @route GET /api/resumes
// Module 10: Resume Version Management - list every resume "version" a user owns
const getResumes = asyncHandler(async (req, res) => {
  const resumes = await Resume.find({ user: req.user._id }).populate(POPULATE).sort({ updatedAt: -1 });
  res.json({ success: true, count: resumes.length, resumes });
});

// @route GET /api/resumes/:id
const getResumeById = asyncHandler(async (req, res) => {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id }).populate(POPULATE);
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }
  res.json({ success: true, resume });
});

// @route POST /api/resumes
// Creates a new resume "version". Caller picks which Education/Experience/
// Project/Skill records to attach (or omit to auto-include everything).
const createResume = asyncHandler(async (req, res) => {
  const { title, templateId, education, experience, projects, skills, careerObjective, professionalSummary } =
    req.body;

  const [profile, allEducation, allExperience, allProjects, allSkills] = await Promise.all([
    Profile.findOne({ user: req.user._id }),
    Education.find({ user: req.user._id }),
    Experience.find({ user: req.user._id }),
    Project.find({ user: req.user._id }),
    Skill.find({ user: req.user._id }),
  ]);

  const resume = await Resume.create({
    user: req.user._id,
    title: title || 'Untitled Resume',
    template: templateId || undefined,
    careerObjective: careerObjective ?? profile?.careerObjective,
    professionalSummary: professionalSummary ?? profile?.professionalSummary,
    education: education || allEducation.map((e) => e._id),
    experience: experience || allExperience.map((e) => e._id),
    projects: projects || allProjects.map((p) => p._id),
    skills: skills || allSkills.map((s) => s._id),
  });

  const populated = await Resume.findById(resume._id).populate(POPULATE);

  await notify(req.user._id, 'resume_generated', `Your resume "${resume.title}" was created.`, `/resumes/${resume._id}`);

  res.status(201).json({ success: true, resume: populated });
});

// @route PUT /api/resumes/:id
const updateResume = asyncHandler(async (req, res) => {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }

  const allowed = [
    'title',
    'template',
    'careerObjective',
    'professionalSummary',
    'education',
    'experience',
    'projects',
    'skills',
    'status',
  ];
  allowed.forEach((field) => {
    if (req.body[field] !== undefined) resume[field] = req.body[field];
  });

  await resume.save();
  const populated = await Resume.findById(resume._id).populate(POPULATE);
  res.json({ success: true, resume: populated });
});

// @route DELETE /api/resumes/:id
const deleteResume = asyncHandler(async (req, res) => {
  const resume = await Resume.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }
  res.json({ success: true, message: 'Resume deleted' });
});

// @route POST /api/resumes/:id/duplicate
// Module 10 feature: "Duplicate Resume"
const duplicateResume = asyncHandler(async (req, res) => {
  const original = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!original) {
    res.status(404);
    throw new Error('Resume not found');
  }

  const copy = await Resume.create({
    user: req.user._id,
    title: `${original.title} (Copy)`,
    template: original.template,
    careerObjective: original.careerObjective,
    professionalSummary: original.professionalSummary,
    education: original.education,
    experience: original.experience,
    projects: original.projects,
    skills: original.skills,
  });

  const populated = await Resume.findById(copy._id).populate(POPULATE);
  res.status(201).json({ success: true, resume: populated });
});

// @route GET /api/resumes/compare?ids=id1,id2
// Module 10 feature: "Compare Versions"
const compareResumes = asyncHandler(async (req, res) => {
  const ids = (req.query.ids || '').split(',').filter(Boolean);
  if (ids.length < 2) {
    res.status(400);
    throw new Error('Provide at least 2 resume ids via ?ids=id1,id2');
  }

  const resumes = await Resume.find({ _id: { $in: ids }, user: req.user._id }).populate(POPULATE);

  const comparison = resumes.map((r) => ({
    id: r._id,
    title: r.title,
    lastAtsScore: r.lastAtsScore,
    educationCount: r.education.length,
    experienceCount: r.experience.length,
    projectsCount: r.projects.length,
    skillsCount: r.skills.length,
    status: r.status,
    updatedAt: r.updatedAt,
  }));

  res.json({ success: true, comparison });
});

// @route POST /api/resumes/:id/set-primary
const setPrimaryResume = asyncHandler(async (req, res) => {
  await Resume.updateMany({ user: req.user._id }, { $set: { isPrimary: false } });
  const resume = await Resume.findOneAndUpdate(
    { _id: req.params.id, user: req.user._id },
    { isPrimary: true },
    { new: true }
  ).populate(POPULATE);

  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }

  res.json({ success: true, resume });
});

// @route POST /api/resumes/:id/ai-generate
// Module 7 (heart of the system): regenerate summary/objective for this resume
// from its currently attached experience/skills/projects.
const generateResumeContent = asyncHandler(async (req, res) => {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id }).populate([
    'experience',
    'skills',
    'projects',
  ]);
  if (!resume) {
    res.status(404);
    throw new Error('Resume not found');
  }

  const { targetRole } = req.body;
  const skills = resume.skills.map((s) => s.name);
  const mostRecentRole = resume.experience[0]?.role || targetRole || 'Software Engineer';
  const achievements = resume.experience.flatMap((e) => e.achievements || []);
  // Approximation: we don't track precise start/end dates reliably here, so we
  // use role count as a rough proxy for the "with X of experience" phrase.
  const yearsOfExperience = resume.experience.length ? `${resume.experience.length}+ years` : 'entry-level';

  const [summaryResult, objectiveResult] = await Promise.all([
    aiService.generateProfessionalSummary({ role: mostRecentRole, yearsOfExperience, skills, achievements }),
    aiService.generateCareerObjective({ targetRole: targetRole || mostRecentRole, skills }),
  ]);

  resume.professionalSummary = summaryResult.text;
  resume.careerObjective = objectiveResult.text;
  await resume.save();

  await notify(req.user._id, 'resume_generated', `AI content generated for "${resume.title}".`, `/resumes/${resume._id}`);

  res.json({
    success: true,
    resume,
    aiSource: { summary: summaryResult.source, objective: objectiveResult.source },
  });
});

module.exports = {
  getResumes,
  getResumeById,
  createResume,
  updateResume,
  deleteResume,
  duplicateResume,
  compareResumes,
  setPrimaryResume,
  generateResumeContent,
};
