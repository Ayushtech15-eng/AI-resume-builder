const asyncHandler = require('express-async-handler');
const Project = require('../models/Project');
const aiService = require('../services/aiService');

// @route GET /api/projects
const getProjects = asyncHandler(async (req, res) => {
  const records = await Project.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json({ success: true, count: records.length, projects: records });
});

// @route POST /api/projects
const createProject = asyncHandler(async (req, res) => {
  const { name, description, techStack, githubUrl, liveUrl } = req.body;

  if (!name) {
    res.status(400);
    throw new Error('Project name is required');
  }

  const record = await Project.create({ user: req.user._id, name, description, techStack, githubUrl, liveUrl });
  res.status(201).json({ success: true, project: record });
});

// @route PUT /api/projects/:id
const updateProject = asyncHandler(async (req, res) => {
  const record = await Project.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Project not found');
  }

  Object.assign(record, req.body);
  await record.save();

  res.json({ success: true, project: record });
});

// @route DELETE /api/projects/:id
const deleteProject = asyncHandler(async (req, res) => {
  const record = await Project.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Project not found');
  }
  res.json({ success: true, message: 'Project deleted' });
});

// @route POST /api/projects/:id/ai-description
// AI Feature: "Generate Project Description" / "Generate Resume Bullet Points"
const generateProjectDescription = asyncHandler(async (req, res) => {
  const record = await Project.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Project not found');
  }

  const { text, source } = await aiService.generateProjectDescription({
    name: record.name,
    techStack: record.techStack,
    rawDescription: record.description,
  });

  const descMatch = text.match(/DESCRIPTION:\s*([\s\S]*?)\nBULLETS:/i);
  const bulletsMatch = text.match(/BULLETS:\s*([\s\S]*)/i);

  record.description = descMatch ? descMatch[1].trim() : text.trim();
  if (bulletsMatch) {
    record.bulletPoints = bulletsMatch[1]
      .split('\n')
      .map((b) => b.replace(/^[-•\d.\s]+/, '').trim())
      .filter(Boolean);
  }
  record.aiGenerated = true;
  await record.save();

  res.json({ success: true, project: record, aiSource: source });
});

// @route POST /api/projects/:id/ai-technical-summary
// AI Feature: "Generate Technical Summary"
const generateTechnicalSummary = asyncHandler(async (req, res) => {
  const record = await Project.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Project not found');
  }

  const { text, source } = await aiService.generateTechnicalSummary({ techStack: record.techStack });
  res.json({ success: true, technicalSummary: text, aiSource: source });
});

module.exports = {
  getProjects,
  createProject,
  updateProject,
  deleteProject,
  generateProjectDescription,
  generateTechnicalSummary,
};
