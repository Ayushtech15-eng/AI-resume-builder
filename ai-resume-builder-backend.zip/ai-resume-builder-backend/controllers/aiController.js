const asyncHandler = require('express-async-handler');
const aiService = require('../services/aiService');
const Profile = require('../models/Profile');
const Skill = require('../models/Skill');
const Experience = require('../models/Experience');

// @route POST /api/ai/generate-summary
// Module 7 AI Feature: "AI Professional Summary Generator"
const generateSummary = asyncHandler(async (req, res) => {
  const { role, yearsOfExperience, skills, achievements } = req.body;
  const { text, source } = await aiService.generateProfessionalSummary({
    role,
    yearsOfExperience,
    skills: skills || [],
    achievements: achievements || [],
  });
  res.json({ success: true, summary: text, aiSource: source });
});

// @route POST /api/ai/generate-objective
const generateObjective = asyncHandler(async (req, res) => {
  const { targetRole, skills } = req.body;
  const { text, source } = await aiService.generateCareerObjective({ targetRole, skills: skills || [] });
  res.json({ success: true, careerObjective: text, aiSource: source });
});

// @route POST /api/ai/generate-project
const generateProject = asyncHandler(async (req, res) => {
  const { name, techStack, rawDescription } = req.body;
  const { text, source } = await aiService.generateProjectDescription({ name, techStack: techStack || [], rawDescription });
  res.json({ success: true, result: text, aiSource: source });
});

// @route POST /api/ai/enhance-experience
const enhanceExperience = asyncHandler(async (req, res) => {
  const { company, role, responsibilities } = req.body;
  const { text, source } = await aiService.enhanceExperienceDescription({ company, role, responsibilities: responsibilities || [] });
  res.json({ success: true, result: text, aiSource: source });
});

// @route POST /api/ai/recommend-skills
const recommendSkills = asyncHandler(async (req, res) => {
  const { currentSkills, targetRole } = req.body;
  const { text, source } = await aiService.recommendSkills({ currentSkills: currentSkills || [], targetRole });
  res.json({ success: true, recommendations: text, aiSource: source });
});

// @route POST /api/ai/review-resume
// Module 11 AI Feature: "AI Resume Reviewer"
const reviewResume = asyncHandler(async (req, res) => {
  const profile = await Profile.findOne({ user: req.user._id });
  const skills = (await Skill.find({ user: req.user._id })).map((s) => s.name);
  const experience = await Experience.find({ user: req.user._id });

  const resumeText = [
    profile?.professionalSummary,
    profile?.careerObjective,
    `Skills: ${skills.join(', ')}`,
    ...experience.map((e) => `${e.role} at ${e.company}: ${(e.responsibilities || []).join('; ')}`),
  ]
    .filter(Boolean)
    .join('\n');

  const { text, source } = await aiService.reviewResume({ resumeText: req.body.resumeText || resumeText });
  res.json({ success: true, feedback: text, aiSource: source });
});

module.exports = {
  generateSummary,
  generateObjective,
  generateProject,
  enhanceExperience,
  recommendSkills,
  reviewResume,
};
