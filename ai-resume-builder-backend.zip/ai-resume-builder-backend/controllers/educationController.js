const asyncHandler = require('express-async-handler');
const Education = require('../models/Education');

// @route GET /api/education
const getEducation = asyncHandler(async (req, res) => {
  const records = await Education.find({ user: req.user._id }).sort({ startYear: -1 });
  res.json({ success: true, count: records.length, education: records });
});

// @route POST /api/education
const createEducation = asyncHandler(async (req, res) => {
  const { university, degree, branch, cgpa, percentage, startYear, endYear, isOngoing } = req.body;

  if (!university || !degree || !startYear) {
    res.status(400);
    throw new Error('university, degree, and startYear are required');
  }

  const record = await Education.create({
    user: req.user._id,
    university,
    degree,
    branch,
    cgpa,
    percentage,
    startYear,
    endYear,
    isOngoing,
  });

  res.status(201).json({ success: true, education: record });
});

// @route PUT /api/education/:id
const updateEducation = asyncHandler(async (req, res) => {
  const record = await Education.findOne({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Education record not found');
  }

  Object.assign(record, req.body);
  await record.save();

  res.json({ success: true, education: record });
});

// @route DELETE /api/education/:id
const deleteEducation = asyncHandler(async (req, res) => {
  const record = await Education.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!record) {
    res.status(404);
    throw new Error('Education record not found');
  }
  res.json({ success: true, message: 'Education record deleted' });
});

module.exports = { getEducation, createEducation, updateEducation, deleteEducation };
