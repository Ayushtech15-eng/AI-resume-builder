# AI Resume Builder — Backend API

Node.js + Express + MongoDB backend for the AI Resume Builder platform described
in the project spec. Covers authentication, profile/education/experience/project/
skill management, the AI resume generator, ATS analysis, cover letter generation,
job matching, resume templates & versioning, PDF export, subscriptions, in-app
notifications, and an admin analytics dashboard.

## Stack

- **Runtime:** Node.js 18+, Express 4
- **Database:** MongoDB via Mongoose
- **Auth:** JWT (Bearer token or httpOnly cookie) + bcrypt
- **AI:** OpenAI API, with a built-in offline fallback generator (see below)
- **PDF:** pdfkit (no headless browser needed)
- **Email:** nodemailer (logs to console if SMTP isn't configured)

## Why it still works without an OpenAI key

Every AI feature in `services/aiService.js` is wrapped in a fallback: if
`OPENAI_API_KEY` is not set, or the OpenAI call fails for any reason, the
service returns a deterministic, template-based result instead of throwing.
This means you can run and demo the **entire** API — including resume
generation, cover letters, ATS suggestions, and skill recommendations —
with zero API cost while you build out the frontend, then drop in a real
key later for higher-quality output. Every AI response includes an
`aiSource` field (`"openai"` or `"fallback"`) so the frontend can show this.

## Getting started

```bash
cd ai-resume-builder-backend
npm install
cp .env.example .env        # then fill in MONGO_URI, JWT_SECRET, etc.

# optional one-time setup
npm run seed:templates       # adds the 5 default resume templates
npm run seed:admin           # creates an admin user from ADMIN_* env vars

npm run dev                  # nodemon, http://localhost:5000
# or
npm start
```

`GET /api/health` should return `{ success: true, message: "AI Resume Builder API is running" }`
once MongoDB is connected.

## Project structure

```
config/         MongoDB connection
models/         Mongoose schemas (User, Profile, Education, Experience,
                 Project, Skill, Resume, Template, AtsReport, CoverLetter,
                 Subscription, Notification)
middleware/      JWT auth (protect/authorize), error handler, validation,
                 subscription/usage guards (free-tier limits)
services/        Pure business logic - aiService (OpenAI + fallback),
                 atsService (scoring algorithm), pdfService (PDFKit),
                 jobMatchService, emailService, notificationService
controllers/     Route handlers, one file per module
routes/          Express routers, one file per module
seed/            seedTemplates.js, seedAdmin.js
server.js        App entrypoint
```

## Auth model

- `POST /api/auth/register` / `login` return a JWT in the response body **and**
  set it as an httpOnly cookie. Send it back either via
  `Authorization: Bearer <token>` or let the cookie do it automatically.
- Roles: `jobseeker` (default), `recruiter`, `admin`. Admin-only routes use
  `authorize('admin')`.
- A `Profile` and `Subscription` document are auto-created for every new user.

## Subscription / free-tier limits

`middleware/subscriptionGuard.js` enforces two simple limits for `plan: 'free'`
accounts (configurable per-user on the `Subscription` model):

- **`resumeLimit`** (default `1`) — blocks creating/duplicating more resumes
- **`aiUsageLimit`** (default `10`/day) — blocks AI routes once exceeded, reset
  on a rolling 24h window

`POST /api/subscriptions/upgrade` flips a user to `premium` and bypasses both
limits. Wire your payment gateway's webhook to call this once payment is
confirmed (the `paymentRef` field is a placeholder for that confirmation id —
swap in real Razorpay/Stripe verification before going to production).

## API reference

All routes are prefixed with `/api`. 🔒 = requires `Authorization: Bearer <token>`.

### Auth — `/auth`
| Method | Path | Notes |
|---|---|---|
| POST | `/register` | name, email, password, role? |
| POST | `/login` | email, password |
| POST | `/google` | googleId, email, name (frontend verifies with Google first) |
| POST | `/logout` | clears cookie |
| POST | `/verify-email` | email, token |
| POST | `/forgot-password` | email |
| POST | `/reset-password` | email, token, newPassword |
| 🔒 GET | `/me` | current user |
| 🔒 PUT | `/change-password` | currentPassword, newPassword |

### Profile — 🔒 `/profile`
`GET /` · `PUT /`

### Education / Experience / Projects / Skills — 🔒
Standard CRUD at `/education`, `/experience`, `/projects`, `/skills`
(`GET /`, `POST /`, `PUT /:id`, `DELETE /:id`). Plus AI add-ons:

| Method | Path | AI Feature |
|---|---|---|
| POST | `/experience/:id/ai-enhance` | Improve/rewrite responsibilities |
| POST | `/experience/:id/ai-achievements` | Generate achievements |
| POST | `/projects/:id/ai-description` | Generate description + bullet points |
| POST | `/projects/:id/ai-technical-summary` | One-line tech summary |
| POST | `/skills/ai-recommend` | Skill recommendations |
| GET | `/skills/gap-analysis?targetRole=` | Skill gap analysis |
| POST | `/skills/bulk` | Bulk-insert skills |

### Resumes — 🔒 `/resumes` (Resume Builder + Version Management)
| Method | Path |
|---|---|
| GET | `/` — list all versions |
| GET | `/compare?ids=id1,id2` |
| POST | `/` — create (subject to free-tier limit) |
| GET / PUT / DELETE | `/:id` |
| POST | `/:id/duplicate` |
| POST | `/:id/set-primary` |
| POST | `/:id/ai-generate` — regenerate summary/objective from attached data |

### Templates — `/templates` (public read, 🔒admin write)
`GET /`, `GET /:id`, `POST /`, `PUT /:id`, `DELETE /:id`

### General AI — 🔒 `/ai`
`generate-summary`, `generate-objective`, `generate-project`,
`enhance-experience`, `recommend-skills`, `review-resume`

### ATS Analyzer — 🔒 `/ats`
`POST /analyze/:resumeId` (body: `jobDescription?`), `GET /reports`, `GET /reports/:resumeId`

### Cover Letters — 🔒 `/cover-letters`
`POST /generate` (jobTitle, companyName, jobDescription?, resumeId?), full CRUD on `/:id`

### Job Matching — 🔒 `/job-match/:resumeId`
`POST` with `{ jobDescription }` → match %, matched/missing skills, verdict

### Subscriptions — 🔒 `/subscriptions`
`GET /me`, `POST /upgrade`, `POST /cancel`

### Notifications — 🔒 `/notifications`
`GET /`, `PUT /:id/read`, `PUT /read-all`, `DELETE /:id`

### PDF — 🔒 `GET /pdf/resume/:resumeId`
Streams a generated PDF download.

### Admin — 🔒admin `/admin`
`GET /users`, `PUT /users/:id/role`, `PUT /users/:id/deactivate`, `GET /analytics`

## Notes & next steps

- **Portfolio Generator (Module 13)** and **deep Cloudinary/Razorpay/Firebase
  integrations** from the original spec aren't wired up yet — the architecture
  (services/ + controllers/ split) makes them straightforward to bolt on:
  add a `services/portfolioService.js` + `controllers/portfolioController.js`
  following the same pattern as the others.
- Swap `OPENAI_MODEL` in `.env` for any chat-completions-compatible model.
- For production, put a reverse proxy (nginx) or platform (Render/Railway/EC2)
  in front of this, set `NODE_ENV=production`, and use a managed MongoDB
  (Atlas) — the same way you've set up BroCoachMe and TTG Talent Grid.
