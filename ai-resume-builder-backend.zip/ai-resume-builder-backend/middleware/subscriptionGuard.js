const asyncHandler = require('express-async-handler');
const Subscription = require('../models/Subscription');
const Resume = require('../models/Resume');

// Ensures every authenticated user has a subscription doc (created lazily)
const getOrCreateSubscription = async (userId) => {
  let sub = await Subscription.findOne({ user: userId });
  if (!sub) {
    sub = await Subscription.create({ user: userId });
  }
  return sub;
};

// Blocks AI generation calls once a free-tier user exceeds their daily quota
const enforceAiUsageLimit = asyncHandler(async (req, res, next) => {
  const sub = await getOrCreateSubscription(req.user._id);
  sub.refreshUsageWindowIfNeeded();

  if (!sub.isPremiumActive() && sub.aiUsageCount >= sub.aiUsageLimit) {
    await sub.save();
    res.status(429);
    throw new Error(
      `Free plan AI usage limit reached (${sub.aiUsageLimit}/day). Upgrade to Premium for unlimited AI generation.`
    );
  }

  sub.aiUsageCount += 1;
  await sub.save();
  req.subscription = sub;
  next();
});

// Blocks creating a new resume once a free-tier user hits their resume cap
const enforceResumeLimit = asyncHandler(async (req, res, next) => {
  const sub = await getOrCreateSubscription(req.user._id);

  if (!sub.isPremiumActive()) {
    const count = await Resume.countDocuments({ user: req.user._id });
    if (count >= sub.resumeLimit) {
      res.status(429);
      throw new Error(
        `Free plan allows only ${sub.resumeLimit} resume(s). Upgrade to Premium for unlimited resumes.`
      );
    }
  }
  next();
});

module.exports = { enforceAiUsageLimit, enforceResumeLimit, getOrCreateSubscription };
