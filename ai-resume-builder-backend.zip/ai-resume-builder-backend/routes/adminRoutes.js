const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const { getUsers, updateUserRole, toggleUserActive, getAnalytics } = require('../controllers/adminController');

router.use(protect, authorize('admin'));
router.get('/users', getUsers);
router.put('/users/:id/role', updateUserRole);
router.put('/users/:id/deactivate', toggleUserActive);
router.get('/analytics', getAnalytics);

module.exports = router;
