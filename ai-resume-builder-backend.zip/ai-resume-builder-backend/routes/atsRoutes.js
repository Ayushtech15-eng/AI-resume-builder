const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit } = require('../middleware/subscriptionGuard');
const { analyzeResume, getReportsForResume, getAllReports } = require('../controllers/atsController');

router.use(protect);
router.get('/reports', getAllReports);
router.get('/reports/:resumeId', getReportsForResume);
router.post('/analyze/:resumeId', enforceAiUsageLimit, analyzeResume);

module.exports = router;
