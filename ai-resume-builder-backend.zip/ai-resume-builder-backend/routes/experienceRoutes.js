const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit } = require('../middleware/subscriptionGuard');
const {
  getExperience,
  createExperience,
  updateExperience,
  deleteExperience,
  enhanceExperience,
  generateAchievementsForExperience,
} = require('../controllers/experienceController');

router.use(protect);
router.route('/').get(getExperience).post(createExperience);
router.route('/:id').put(updateExperience).delete(deleteExperience);
router.post('/:id/ai-enhance', enforceAiUsageLimit, enhanceExperience);
router.post('/:id/ai-achievements', enforceAiUsageLimit, generateAchievementsForExperience);

module.exports = router;
