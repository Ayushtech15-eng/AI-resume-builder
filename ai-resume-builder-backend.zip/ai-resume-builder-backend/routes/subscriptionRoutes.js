const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { getMySubscription, upgradeToPremium, cancelSubscription } = require('../controllers/subscriptionController');

router.use(protect);
router.get('/me', getMySubscription);
router.post('/upgrade', upgradeToPremium);
router.post('/cancel', cancelSubscription);

module.exports = router;
