const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit } = require('../middleware/subscriptionGuard');
const {
  getProjects,
  createProject,
  updateProject,
  deleteProject,
  generateProjectDescription,
  generateTechnicalSummary,
} = require('../controllers/projectController');

router.use(protect);
router.route('/').get(getProjects).post(createProject);
router.route('/:id').put(updateProject).delete(deleteProject);
router.post('/:id/ai-description', enforceAiUsageLimit, generateProjectDescription);
router.post('/:id/ai-technical-summary', enforceAiUsageLimit, generateTechnicalSummary);

module.exports = router;
