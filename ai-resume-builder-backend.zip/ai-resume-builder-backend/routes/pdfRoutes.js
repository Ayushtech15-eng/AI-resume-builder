const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { downloadResumePdf } = require('../controllers/pdfController');

router.use(protect);
router.get('/resume/:resumeId', downloadResumePdf);

module.exports = router;
