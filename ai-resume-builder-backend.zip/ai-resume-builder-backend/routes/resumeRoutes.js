const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit, enforceResumeLimit } = require('../middleware/subscriptionGuard');
const {
  getResumes,
  getResumeById,
  createResume,
  updateResume,
  deleteResume,
  duplicateResume,
  compareResumes,
  setPrimaryResume,
  generateResumeContent,
} = require('../controllers/resumeController');

router.use(protect);

// Static sub-paths must be declared before the generic '/:id' route below
router.get('/compare', compareResumes);

router.route('/').get(getResumes).post(enforceResumeLimit, createResume);
router.route('/:id').get(getResumeById).put(updateResume).delete(deleteResume);

router.post('/:id/duplicate', enforceResumeLimit, duplicateResume);
router.post('/:id/set-primary', setPrimaryResume);
router.post('/:id/ai-generate', enforceAiUsageLimit, generateResumeContent);

module.exports = router;
