const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit } = require('../middleware/subscriptionGuard');
const {
  generateCoverLetter,
  getCoverLetters,
  getCoverLetterById,
  updateCoverLetter,
  deleteCoverLetter,
} = require('../controllers/coverLetterController');

router.use(protect);
router.post('/generate', enforceAiUsageLimit, generateCoverLetter);
router.get('/', getCoverLetters);
router.route('/:id').get(getCoverLetterById).put(updateCoverLetter).delete(deleteCoverLetter);

module.exports = router;
