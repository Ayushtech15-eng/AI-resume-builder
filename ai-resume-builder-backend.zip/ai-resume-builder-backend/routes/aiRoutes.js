const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit } = require('../middleware/subscriptionGuard');
const {
  generateSummary,
  generateObjective,
  generateProject,
  enhanceExperience,
  recommendSkills,
  reviewResume,
} = require('../controllers/aiController');

router.use(protect);
router.post('/generate-summary', enforceAiUsageLimit, generateSummary);
router.post('/generate-objective', enforceAiUsageLimit, generateObjective);
router.post('/generate-project', enforceAiUsageLimit, generateProject);
router.post('/enhance-experience', enforceAiUsageLimit, enhanceExperience);
router.post('/recommend-skills', enforceAiUsageLimit, recommendSkills);
router.post('/review-resume', enforceAiUsageLimit, reviewResume);

module.exports = router;
