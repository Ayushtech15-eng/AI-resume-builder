const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { matchJob } = require('../controllers/jobMatchController');

router.use(protect);
router.post('/:resumeId', matchJob);

module.exports = router;
