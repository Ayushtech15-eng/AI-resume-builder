const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getTemplates,
  getTemplateById,
  createTemplate,
  updateTemplate,
  deleteTemplate,
} = require('../controllers/templateController');

// Browsing templates is public so the marketing "Pricing"/"Features" pages can show previews
router.get('/', getTemplates);
router.get('/:id', getTemplateById);

router.post('/', protect, authorize('admin'), createTemplate);
router.put('/:id', protect, authorize('admin'), updateTemplate);
router.delete('/:id', protect, authorize('admin'), deleteTemplate);

module.exports = router;
