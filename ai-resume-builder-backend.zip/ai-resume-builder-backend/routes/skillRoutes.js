const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { enforceAiUsageLimit } = require('../middleware/subscriptionGuard');
const {
  getSkills,
  createSkill,
  createSkillsBulk,
  deleteSkill,
  recommendSkills,
  skillGapAnalysis,
} = require('../controllers/skillController');

router.use(protect);
router.route('/').get(getSkills).post(createSkill);
router.post('/bulk', createSkillsBulk);
router.delete('/:id', deleteSkill);
router.post('/ai-recommend', enforceAiUsageLimit, recommendSkills);
router.get('/gap-analysis', enforceAiUsageLimit, skillGapAnalysis);

module.exports = router;
