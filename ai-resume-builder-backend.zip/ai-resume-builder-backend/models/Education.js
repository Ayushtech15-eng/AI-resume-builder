const mongoose = require('mongoose');

const EducationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    university: { type: String, required: true, trim: true },
    degree: { type: String, required: true, trim: true },
    branch: { type: String, trim: true },
    cgpa: { type: Number, min: 0, max: 10 },
    percentage: { type: Number, min: 0, max: 100 },
    startYear: { type: Number, required: true },
    endYear: { type: Number },
    isOngoing: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Education', EducationSchema);
