const mongoose = require('mongoose');

const ResumeSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    title: { type: String, required: true, trim: true, default: 'Untitled Resume' },
    template: { type: mongoose.Schema.Types.ObjectId, ref: 'Template' },

    // Snapshot fields so a resume version is independent of later profile edits
    careerObjective: { type: String, trim: true, maxlength: 1000 },
    professionalSummary: { type: String, trim: true, maxlength: 1500 },

    education: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Education' }],
    experience: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Experience' }],
    projects: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Project' }],
    skills: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Skill' }],

    isPrimary: { type: Boolean, default: false },
    lastAtsScore: { type: Number, min: 0, max: 100, default: null },
    pdfUrl: { type: String, default: null },
    status: { type: String, enum: ['draft', 'finalized'], default: 'draft' },
  },
  { timestamps: true }
);

ResumeSchema.index({ user: 1, title: 1 });

module.exports = mongoose.model('Resume', ResumeSchema);
