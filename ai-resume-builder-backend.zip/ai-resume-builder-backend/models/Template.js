const mongoose = require('mongoose');

const TemplateSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    type: {
      type: String,
      enum: ['Modern', 'Professional', 'Corporate', 'Creative', 'Minimal'],
      required: true,
    },
    description: { type: String, trim: true },
    previewImageUrl: { type: String, trim: true },
    isPremium: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
    accentColor: { type: String, default: '#2563EB' },
    usageCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Template', TemplateSchema);
