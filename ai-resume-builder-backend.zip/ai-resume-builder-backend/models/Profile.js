const mongoose = require('mongoose');

const ProfileSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    phone: { type: String, trim: true },
    address: { type: String, trim: true },
    location: { type: String, trim: true },
    linkedinUrl: { type: String, trim: true },
    githubUrl: { type: String, trim: true },
    portfolioUrl: { type: String, trim: true },
    careerObjective: { type: String, trim: true, maxlength: 1000 },
    professionalSummary: { type: String, trim: true, maxlength: 1500 },
    profileImageUrl: { type: String, trim: true },
    profileCompleteness: { type: Number, default: 0, min: 0, max: 100 },
  },
  { timestamps: true }
);

// Crude completeness score used by the dashboard
ProfileSchema.methods.computeCompleteness = function () {
  const fields = [
    this.phone,
    this.location,
    this.linkedinUrl,
    this.githubUrl,
    this.careerObjective,
    this.professionalSummary,
  ];
  const filled = fields.filter(Boolean).length;
  this.profileCompleteness = Math.round((filled / fields.length) * 100);
  return this.profileCompleteness;
};

module.exports = mongoose.model('Profile', ProfileSchema);
