const mongoose = require('mongoose');

const SubscriptionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
    plan: { type: String, enum: ['free', 'premium'], default: 'free' },
    status: { type: String, enum: ['active', 'expired', 'cancelled'], default: 'active' },
    startDate: { type: Date, default: Date.now },
    endDate: { type: Date },
    paymentRef: { type: String },

    // Simple usage metering for the free tier
    aiUsageCount: { type: Number, default: 0 },
    aiUsageLimit: { type: Number, default: 10 }, // free tier: 10 AI calls / day
    aiUsageResetAt: { type: Date, default: () => new Date(Date.now() + 24 * 60 * 60 * 1000) },
    resumeLimit: { type: Number, default: 1 }, // free tier: 1 resume
  },
  { timestamps: true }
);

SubscriptionSchema.methods.refreshUsageWindowIfNeeded = function () {
  if (this.aiUsageResetAt && this.aiUsageResetAt < new Date()) {
    this.aiUsageCount = 0;
    this.aiUsageResetAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  }
};

SubscriptionSchema.methods.isPremiumActive = function () {
  return this.plan === 'premium' && this.status === 'active' && (!this.endDate || this.endDate > new Date());
};

module.exports = mongoose.model('Subscription', SubscriptionSchema);
