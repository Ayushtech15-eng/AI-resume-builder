const mongoose = require('mongoose');

const AtsReportSchema = new mongoose.Schema(
  {
    resume: { type: mongoose.Schema.Types.ObjectId, ref: 'Resume', required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    jobDescription: { type: String, trim: true },
    score: { type: Number, required: true, min: 0, max: 100 },
    matchedKeywords: [{ type: String }],
    missingKeywords: [{ type: String }],
    suggestions: [{ type: String }],
    breakdown: {
      keywordScore: Number,
      skillsScore: Number,
      formattingScore: Number,
      experienceScore: Number,
      readabilityScore: Number,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('AtsReport', AtsReportSchema);
