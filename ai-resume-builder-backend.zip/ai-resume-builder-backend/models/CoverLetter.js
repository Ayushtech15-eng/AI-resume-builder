const mongoose = require('mongoose');

const CoverLetterSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    resume: { type: mongoose.Schema.Types.ObjectId, ref: 'Resume' },
    jobTitle: { type: String, required: true, trim: true },
    companyName: { type: String, required: true, trim: true },
    jobDescription: { type: String, trim: true },
    content: { type: String, required: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('CoverLetter', CoverLetterSchema);
