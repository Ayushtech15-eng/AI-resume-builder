const mongoose = require('mongoose');

const ExperienceSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    company: { type: String, required: true, trim: true },
    role: { type: String, required: true, trim: true },
    startDate: { type: Date },
    endDate: { type: Date },
    isCurrent: { type: Boolean, default: false },
    durationText: { type: String, trim: true }, // e.g. "2 Years" - free text fallback
    responsibilities: [{ type: String, trim: true }],
    achievements: [{ type: String, trim: true }],
    aiEnhanced: { type: Boolean, default: false },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Experience', ExperienceSchema);
