const mongoose = require('mongoose');

const SKILL_CATEGORIES = ['Frontend', 'Backend', 'Database', 'Cloud', 'Programming Languages', 'DevOps', 'Other'];

const SkillSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    name: { type: String, required: true, trim: true },
    category: { type: String, enum: SKILL_CATEGORIES, default: 'Other' },
    proficiency: { type: String, enum: ['Beginner', 'Intermediate', 'Advanced', 'Expert'], default: 'Intermediate' },
  },
  { timestamps: true }
);

SkillSchema.index({ user: 1, name: 1 }, { unique: true });

module.exports = mongoose.model('Skill', SkillSchema);
module.exports.SKILL_CATEGORIES = SKILL_CATEGORIES;
